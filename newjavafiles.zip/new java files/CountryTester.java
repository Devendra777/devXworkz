class CountryTester{

public static void main(String a[])
{
  Country cty=  new Country("India",30,1300000000L, 9);
cty.printCountryDetails();
 Country ct=  new Country("West Indies",0,44000000,0);
ct.printCountryDetails();
Country country=  new Country("Philippines",81,4632359L,0);
country.printCountryDetails();
Country.country();
Country.develop();

}


}