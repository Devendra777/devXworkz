class Gmail extends Google{

@Override
void sendMail(){

System.out.println("Sending mail  from Gmail");
}
}