class GoogleTester{

public static void main(String a[]){
   Laptop top  = new Laptop();
     Google gmail = new Gmail();
     Google gDrive = new GoogleDrive();
    top.browse(gmail);
}

}