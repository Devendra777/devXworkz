public class FactoryDTO     {

private  int factoryId;
private String factoryName ;

public void setFactoryName(String name)
{
factoryName = name;
}

public String getFactoryName()
{
 return factoryName;
}

public void setFactoryId(int id)
{
        factoryId =id;
}

public int getFactoryId()
{
return factoryId;
}
}