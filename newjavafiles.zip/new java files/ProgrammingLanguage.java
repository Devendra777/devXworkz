class ProgrammingLanguage{

public static void main(String a[])
{
developApplication();
developApplication("Java");

}

    public static void developApplication(){

System.out.println("Developing netflix Application");
}

 static void developApplication(String type){

System.out.println("Developing netflix Application using " + type);
}



}