class  DellUtil{
public static void main(String a[])
{
    
       String  price1 =  a[0];
      String screen = a[1];
     Dell dell = new Dell();
      dell.modelNo="DELL-90";
      dell.price = Double.parseDouble(price1) ;
      dell.isTouchScreen= Boolean.parseBoolean(screen);
System.out.println(dell.modelNo + "   "+  dell.price + "   "+ dell.isTouchScreen);
dell.storeData();



  HP hp = new HP();
     hp.modelNo="HP-420";
     hp.price = 70000;
      hp.isTouchScreen= false;
System.out.println(hp.modelNo + "   "+  hp.price + "   "+ hp.isTouchScreen);
hp.storeData();

}


}