package com.legato.reports.service;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.aspose.cells.Cells;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.License;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.legato.common.constants.Constants;
import com.legato.persistence.dto.ConfigDetailsDTO;
import com.legato.persistence.dto.ExecutionCommandDTO;
import com.legato.persistence.dto.JobMetaDataDTO;
import com.legato.persistence.dto.VulcanMetaDataDTO;
import com.legato.web.view.request.RequestView;

@Service
public class ExporterService {

	@Autowired
	ExportFileHelper exportHelper;
	
		
	@SuppressWarnings("deprecation")
	public void generateSTGSqlReport(RequestView req) throws Exception {
	//	JSONObject json = new JSONObject(req.getTargetColumns());
	//	Object obj=json.get("columns");
	//	String data=(String)obj.toString();
		String data = "Hello , it's a new file generated";
		ByteArrayOutputStream ms = new ByteArrayOutputStream();
		byte[] array = data.getBytes();
		ms.write(array);
		byte[] b = ms.toByteArray();
		exportHelper.writeFile(b, req.getTableName(), Constants.SQL); 
		
	}
	@SuppressWarnings("deprecation")
	public void generateJobMetadataReport(List<JobMetaDataDTO> dtoList,RequestView req) throws Exception {
		License license = new License();
		if (!License.isLicenseSet()) {
			ClassPathResource cpr = new ClassPathResource("Aspose.Cells.lic");
			license.setLicense(cpr.getInputStream());
		}
	
		Workbook wb = new Workbook();
		Worksheet worksheet = wb.getWorksheets().get(0);
		int count=req.getTableName().length();
		String fileName ="";
		if(count<22) {
		worksheet.setName("Job_Meta_"+req.getTableName());
		fileName="Job_Meta_"+req.getTableName();
		}else {
		 worksheet.setName("Job_Meta_"+req.getTableName().substring(0,22));	
		 fileName="Job_Meta_"+req.getTableName();
		}
		int filterSheetRow = 0;
		int row;
		Cells cells = worksheet.getCells();
		for(row = 0; row < dtoList.size(); row++) {
			JobMetaDataDTO dto = dtoList.get(row);
			int column = 0;
			cells.get(row, column++).setValue(dto.getAppCode());
			cells.get(row, column++).setValue(dto.getS3bucketKey());
			cells.get(row, column++).setValue(dto.getDomainCode());
			cells.get(row, column++).setValue(dto.getSorCode());
			cells.get(row, column++).setValue(dto.getTargetTblName());
			cells.get(row, column++).setValue(dto.getTargetSchema());
			cells.get(row, column++).setValue(dto.getPrcsngType());
			cells.get(row, column++).setValue(dto.getJobName());
			cells.get(row, column++).setValue(dto.getLoadType());
			cells.get(row, column++).setValue(dto.getS3InboundBucket());
			cells.get(row, column++).setValue(dto.getS3InboundKey());
			cells.get(row, column++).setValue(dto.getS3ArchiveBucket());
			cells.get(row, column++).setValue(dto.getS3ArchieveKey());
			cells.get(row, column++).setValue(dto.getS3AppBucket());
			cells.get(row, column++).setValue(dto.getS3AppKey());
			cells.get(row, column++).setValue(dto.getS3CnsmptionBucket());
			cells.get(row, column++).setValue(dto.getS3CnsmptionKey());
			
			cells.get(row, column++).setValue(dto.getTargetPlatForm());
			cells.get(row, column++).setValue(dto.getDelTableName());
			cells.get(row, column++).setValue(dto.getStgTableName());
			cells.get(row, column++).setValue(dto.getStgSchema());
			cells.get(row, column++).setValue(dto.getKeyList());
			cells.get(row, column++).setValue(dto.getDelKeyList());
			cells.get(row, column++).setValue(dto.getSrcFileType());
			cells.get(row, column++).setValue(dto.getUnldFileType());
			cells.get(row, column++).setValue(dto.getUnldPartnKey());
			cells.get(row, column++).setValue(dto.getUnldFrequency());
			cells.get(row, column++).setValue(dto.getUnldType());
			cells.get(row, column++).setValue(dto.getUnldTargetPlatform());
			
			cells.get(row, column++).setValue(dto.getDlmtr());
			cells.get(row, column++).setValue(dto.getVrncAlwdPct());
			cells.get(row, column++).setValue(dto.getPostLoadMethod());
			cells.get(row, column++).setValue(dto.getJobType());
			cells.get(row, column++).setValue(dto.getEtlJobParams());
			cells.get(row, column++).setValue(dto.getLoadFrequency());
			cells.get(row, column++).setValue(dto.getDscverSchemaFlag());
			cells.get(row, column++).setValue(dto.getReqId());
			cells.get(row, column++).setValue(dto.getOwnershipTeam());
			cells.get(row, column++).setValue(dto.getUnloadBukcetSet());
			cells.get(row, column++).setValue(dto.getWareHouseSuffix());
			}
		worksheet.autoFitColumns();
		ByteArrayOutputStream ms = new ByteArrayOutputStream();
		wb.save(ms, FileFormatType.CSV);
		byte[] b = ms.toByteArray();
		exportHelper.writeFile(b, fileName, Constants.CSV_XTN); 
		
	}
	@SuppressWarnings("deprecation")
	public void generateVulcanMetadataReport(List<VulcanMetaDataDTO> dtoList,RequestView req) throws Exception {
		License license = new License();
		if (!License.isLicenseSet()) {
			ClassPathResource cpr = new ClassPathResource("Aspose.Cells.lic");
			license.setLicense(cpr.getInputStream());
		}
		Workbook wb = new Workbook();
		Worksheet worksheet = wb.getWorksheets().get(0);
		int count=req.getTableName().length();
		String fileName="";
		if(count<17) {
		worksheet.setName("Vulcan_Meta_"+req.getTableName());
		fileName="Vulcan_Meta_"+req.getTableName();
		}else {
		worksheet.setName("Vulcan_Meta_"+req.getTableName().substring(0, 16));
		fileName="Vulcan_Meta_"+req.getTableName().substring(0, 16);
		}
		int row;
		Cells cells = worksheet.getCells();
		for(row = 0; row < dtoList.size(); row++) {
			VulcanMetaDataDTO dto = dtoList.get(row);
			int column = 0;
			cells.get(row, column++).setValue(dto.getAppCode());
			cells.get(row, column++).setValue(dto.getDbType());
			cells.get(row, column++).setValue(dto.getSrcSystemName());
			cells.get(row, column++).setValue(dto.getCatalogName());
			cells.get(row, column++).setValue(dto.getSchemaName());
			cells.get(row, column++).setValue(dto.getSrcTableName());
			cells.get(row, column++).setValue(dto.getSrcClaimListFile());
			cells.get(row, column++).setValue(dto.getDeltaTableName());
			cells.get(row, column++).setValue(dto.getDeltaTableClaim());
			cells.get(row, column++).setValue(dto.getDeleteTableName());
			cells.get(row, column++).setValue(dto.getDeleteTableClaim());
			cells.get(row, column++).setValue(dto.getHdfsDeltaTablePath());
			cells.get(row, column++).setValue(dto.getHdfcDeleteTablePath());
			cells.get(row, column++).setValue(dto.getDestS3ObjectKey());
			cells.get(row, column++).setValue(dto.getDestS3BucketName());
			cells.get(row, column++).setValue(dto.getDestTypeDesc());
			cells.get(row, column++).setValue(dto.getTptInstCount());
			
			cells.get(row, column++).setValue(dto.getTargetTableRefresh());
			cells.get(row, column++).setValue(dto.getReqId());
			cells.get(row, column++).setValue(dto.getOwnershipTeam());
			
			}
		worksheet.autoFitColumns();
		ByteArrayOutputStream ms = new ByteArrayOutputStream();
		wb.save(ms, FileFormatType.CSV);
		byte[] b = ms.toByteArray();
		exportHelper.writeFile(b, fileName, Constants.CSV_XTN); 
		
	}
	@SuppressWarnings("deprecation")
	public void generateTargetScriptReport(RequestView req) throws Exception {
		String data = "CREATE TABLE"+" "+req.getSchemaName()+"."+req.getTableName()+"("+req.getTargetColumns()+"); \r\n\n CREATE OR REPLACE VIEW "+req.getSchemaName()+"_NOGBD."+req.getTableName()+""+" AS \r\n"    + 
				 " SELECT * FROM  "+req.getSchemaName()+"."+req.getTableName()+""; 
		ByteArrayOutputStream ms = new ByteArrayOutputStream();
		byte[] array = data.getBytes();
		ms.write(array);
		byte[] b = ms.toByteArray();
		exportHelper.writeFile(b, req.getTableName()+"_Snowflake_DDL", Constants.SQL); 
		
	}
	@SuppressWarnings("deprecation")
	public void generateConfigReport(ConfigDetailsDTO cnfdetails,RequestView req) throws Exception {
		
		//String data1 = "new file";
		
		StringBuffer data = new StringBuffer("# TEST CLUSTER SPARK ETL JOB CONFIGURATION \n");
		data.append("--- !!com.anthem.etl.dao.DataSourceConfig \n")
		.append(cnfdetails.getEnv()+"\n")
		.append(cnfdetails.getRelease()+"\n")
		.append(cnfdetails.getLayer()+"\n")
		.append(cnfdetails.getAudittDBschema()+"\n")
		.append(cnfdetails.getAuditTablePassword()+"\n")
		.append(cnfdetails.getAuditTableDBDriver()+"\n")
		.append(cnfdetails.getCredentialProviderURL()+"\n")
		.append(cnfdetails.getUserName()+"\n")
		.append(cnfdetails.getPassword()+"\n")
		.append(cnfdetails.getSrcformat()+"\n")
		.append(cnfdetails.getSrcDbServerUrl()+"\n")
		.append(cnfdetails.getSrcJdbcDriver()+"\n")
		.append(cnfdetails.getAncillarysrcformat()+"\n")
		.append(cnfdetails.getAncillarysrcdbserverurl()+"\n")
		.append(cnfdetails.getAncillarysrcjdbcdriver()+"\n")
		.append(cnfdetails.getTgtformat()+"\n")
		.append(cnfdetails.getTgtdbserverurl()+"\n")
		.append(cnfdetails.getTgtjdbcdriver()+"\n")
		.append(cnfdetails.getAuditTable()+"\n")
		.append(cnfdetails.getRdsConfigPath()+"\n")
		.append(cnfdetails.getSystemname()+"\n")
		.append(cnfdetails.getDatasets()+"\n")
		.append(cnfdetails.getQueryMap()+"\n");
		
		ByteArrayOutputStream ms = new ByteArrayOutputStream();
		byte[] array = data.toString().getBytes();/*data1.getBytes();*/
		ms.write(array);
		byte[] b = ms.toByteArray();
		exportHelper.writeFile(b, "phd_td_to_stg_"+req.getTableName(), Constants.CONF); 
		
	}
	
	

	@SuppressWarnings("deprecation")
	public void generateLstReport (ExecutionCommandDTO command,RequestView req) throws Exception {
		StringBuffer data = new StringBuffer();
	data.append(command.getServerPath()+"\n");
	data.append(command.getLocalPath()+"\n");
		ByteArrayOutputStream ms = new ByteArrayOutputStream();
		byte[] array = data.toString().getBytes();
		ms.write(array);
		byte[] b = ms.toByteArray();
		exportHelper.writeFile(b, "phd_td_to_stg_"+req.getTableName(), Constants.LST); 
		
	}
}
