class  BankTester{

public static void main(String a[]){
    Bank sbi1 = new  Bank ();   
   sbi1.bankId = 678;
  sbi1.address = "Rajajinagar";
  sbi1.noOfBranches = 5;

  Bank sbi =new Bank();
  sbi.bankId = 678;
 sbi.address = "Nagarbhavi";
  sbi.noOfBranches = 89;
 
boolean type = sbi1.equals(sbi);
System.out.println(type );

}

}