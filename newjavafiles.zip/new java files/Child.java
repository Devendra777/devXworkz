class Child     extends Parent2  implements  Parent1{

public static  void main(String a[]){

System.out.println("Example for Multiple inheritance");
}


}