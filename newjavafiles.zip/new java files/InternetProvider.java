public class  InternetProvider{

 static String name = "ACT"; 
String address ; 
String plan ; 
double cost;

 static  void serve()
{
System.out.println("serving the customers with the best plan");
}

}