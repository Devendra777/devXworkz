package com.wellpoint.pc2dash.action.careOpportunitiesTrending;

import java.io.Serializable;

public class CareOpportunitiesRateJson implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6688278641444793022L;
	/**
	 * @return the measureName
	 */
	public String getMeasureName() {
		return measureName;
	}
	/**
	 * @param measureName the measureName to set
	 */
	public void setMeasureName(String measureName) {
		this.measureName = measureName;
	}
	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}
	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}
	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}
	/**
	 * @return the month2
	 */
	public String getMonth2() {
		return month2;
	}
	/**
	 * @param month2 the month2 to set
	 */
	public void setMonth2(String month2) {
		this.month2 = month2;
	}
	/**
	 * @return the month3
	 */
	public String getMonth3() {
		return month3;
	}
	/**
	 * @param month3 the month3 to set
	 */
	public void setMonth3(String month3) {
		this.month3 = month3;
	}
	/**
	 * @return the month4
	 */
	public String getMonth4() {
		return month4;
	}
	/**
	 * @param month4 the month4 to set
	 */
	public void setMonth4(String month4) {
		this.month4 = month4;
	}
	/**
	 * @return the month5
	 */
	public String getMonth5() {
		return month5;
	}
	/**
	 * @param month5 the month5 to set
	 */
	public void setMonth5(String month5) {
		this.month5 = month5;
	}
	/**
	 * @return the month6
	 */
	public String getMonth6() {
		return month6;
	}
	/**
	 * @param month6 the month6 to set
	 */
	public void setMonth6(String month6) {
		this.month6 = month6;
	}
	/**
	 * @return the month7
	 */
	public String getMonth7() {
		return month7;
	}
	/**
	 * @param month7 the month7 to set
	 */
	public void setMonth7(String month7) {
		this.month7 = month7;
	}
	/**
	 * @return the month8
	 */
	public String getMonth8() {
		return month8;
	}
	/**
	 * @param month8 the month8 to set
	 */
	public void setMonth8(String month8) {
		this.month8 = month8;
	}
	/**
	 * @return the month9
	 */
	public String getMonth9() {
		return month9;
	}
	/**
	 * @param month9 the month9 to set
	 */
	public void setMonth9(String month9) {
		this.month9 = month9;
	}
	/**
	 * @return the month10
	 */
	public String getMonth10() {
		return month10;
	}
	/**
	 * @param month10 the month10 to set
	 */
	public void setMonth10(String month10) {
		this.month10 = month10;
	}
	/**
	 * @return the month11
	 */
	public String getMonth11() {
		return month11;
	}
	/**
	 * @param month11 the month11 to set
	 */
	public void setMonth11(String month11) {
		this.month11 = month11;
	}
	/**
	 * @return the month12
	 */
	public String getMonth12() {
		return month12;
	}
	/**
	 * @param month12 the month12 to set
	 */
	public void setMonth12(String month12) {
		this.month12 = month12;
	}
	/**
	 * @return the rowClass
	 */
	public String getRowClass() {
		return rowClass;
	}
	/**
	 * @param rowClass the rowClass to set
	 */
	public void setRowClass(String rowClass) {
		this.rowClass = rowClass;
	}
	private String measureName;
	private String year;
	private String lob;
	private String month1;
	/**
	 * @return the month1
	 */
	public String getMonth1() {
		return month1;
	}
	/**
	 * @param month1 the month1 to set
	 */
	public void setMonth1(String month1) {
		this.month1 = month1;
	}
	private String month2;
	private String month3;
	private String month4;
	private String month5;
	private String month6;
	private String month7;
	private String month8;
	private String month9;
	private String month10;
	private String month11;
	private String month12;
	private String rowClass; 

}
