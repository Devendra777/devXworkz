class Flights{
static String[]    flightNames= {"KingFisher" , "Deccan" , "SpiceJet" ,"AirAsia"};
static double price=9000.00;


public static void main(String a[])
{
getAllFlights();

}

public static void getFlightNames()
{
for(int i=0;  i < flightNames.length ; i++)
{
System.out.println(flightNames[i] );
}
}

}