package com.wellpoint.pc2dash.service.stars;

import static com.wellpoint.pc2dash.service.dashboard.Constants.COMMA;
import static com.wellpoint.pc2dash.service.dashboard.ErrorMessages.SQL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.wellpoint.pc2dash.action.stars.GetAVCompletionRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dao.AbstractDao;
import com.wellpoint.pc2dash.dto.stars.AVCompletionJson;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;
import static com.wellpoint.pc2dash.util.Constants.CLOSE_BRACKET;

public class AVCompletionServiceImpl extends AbstractDao{
	
	private static final String CMPLNC_RT_PCT = "CMPLNC_RT_PCT";
	private static final String MSR_DIM_KEY = "MSR_DIM_KEY";
	private static final String MIN_GOAL = "MIN_GOAL";
	private static final String MAX_GOAL = "MAX_GOAL";
	private static final String UNABLE_TO_GET_AV_COMPLETION_DAO = "Unable to get AVCompletionDao (";
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AVCompletionServiceImpl.class);
	private static final String ANNUAL_VISIT_COMPLETION = "Annual Visit Completion";
	
	public List<AVCompletionJson> getAVCompletionTicker(GetAVCompletionRequest request) throws PC2Exception {
		
		List<AVCompletionJson> results= new ArrayList<AVCompletionJson>();
		
		StringBuilder sql = getAVCompletionTickerQuery(request);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(request, sql.toString());
			executeQuery(logger, sql.toString());
			getResult(results);
		}
		catch (Exception e) {
			throw new PC2Exception(UNABLE_TO_GET_AV_COMPLETION_DAO + request.getEntitlementId() + ", " + request.getMemberKey() + ")." + request.toString() + SQL + sql.toString(), e);
		}
		finally {
			close();
		}
		return results;

	}
	
	/** 
	 * This method is to generate query for AVCompletion port-let
	 * @param request
	 * @return
	 */
	private StringBuilder getAVCompletionTickerQuery(GetAVCompletionRequest request) {

		StringBuilder sql = new StringBuilder()
				.append("SELECT ")
				.append("MDCR_STAR.MSR_DIM_KEY AS MSR_DIM_KEY, ")
				.append("RFRNC.MSR_NM AS MSR_DSPLY_NM , ")
				.append("MDCR_STAR.CMPLNC_RT_PCT AS CMPLNC_RT_PCT, ")
				.append("RFRNC.MIN_CUT_PCT AS MIN_GOAL, ")
				.append("RFRNC.MAX_CUT_PCT AS MAX_GOAL ")
				.append("FROM ( ")
				.append("SELECT  ")
				.append("MSSF.MSR_DIM_KEY, ")
				.append("MD.MSR_DSPLY_NM, ")
				.append("MD.RULE_ID, ")
				.append("MSSF.MSR_YEAR_NBR, ")
				.append("SUM(NMRTR_NBR) AS NMRTR_NBR, ")
				.append("SUM(DNMNTR_NBR) AS DNMNTR_NBR, ")
				.append("CAST(ROUND(CAST(SUM(NMRTR_NBR)*100 AS DECIMAL(18,2))/SUM(DNMNTR_NBR),2)AS DECIMAL(18,2)) AS CMPLNC_RT_PCT  ")
				.append("FROM  ")
				.append("MDCR_STAR_SMRY_FACT MSSF ")
				.append("INNER JOIN PROV_GRP_DIM PGD ")
				.append("ON MSSF.PROV_GRP_DIM_KEY=PGD.PROV_GRP_DIM_KEY ")
				.append("AND PGD.RCRD_STTS_CD='ACT' ")
				.append("INNER JOIN PROV_ORG_DIM POD ")
				.append("ON MSSF.PROV_ORG_DIM_KEY=POD.PROV_ORG_DIM_KEY ")
				.append("AND POD.RCRD_STTS_CD='ACT' ")
				.append("INNER JOIN PGM_DIM PD ")
				.append("ON MSSF.PGM_DIM_KEY=PD.PGM_DIM_KEY ")
				.append("AND PD.RCRD_STTS_CD='ACT' ")
				.append("INNER JOIN MSR_DIM MD ")
				.append("ON MSSF.MSR_DIM_KEY=MD.MSR_DIM_KEY ")
				.append("AND MD.RCRD_STTS_CD='ACT' ")
				.append("INNER JOIN PSL_DIM PSLD ")
				.append("ON MSSF.PSL_DIM_KEY=PSLD.PSL_DIM_KEY ")
				.append("  join poit_user_scrty_acs PUSA on ( ")
				.append("    pgd.prov_grp_id = PUSA.prov_grp_id ")
				.append("    and case ")
				.append("        when PUSA.prov_org_tax_id = '0' then pod.prov_org_tax_id ")
				.append("        else PUSA.prov_org_tax_id ")
				.append("      end = pod.prov_org_tax_id ")
				.append("  ) ")		
			 	.append("WHERE PRTLT_ID='1001' AND ")
				.append(buildWhereClause(request))
				.append("GROUP BY ")
				.append("MSSF.MSR_DIM_KEY,")
				.append("MD.MSR_DSPLY_NM,")
				.append("MD.RULE_ID,")
				.append("MSSF.MSR_YEAR_NBR ")
				.append("WITH UR ")
				.append(") MDCR_STAR ")
				.append("INNER JOIN MDCR_STARS_CUT_PCT_RFRNC RFRNC ")
				.append("ON MDCR_STAR.RULE_ID=RFRNC.RULE_ID ")
				.append("AND MDCR_STAR.MSR_YEAR_NBR=RFRNC.MSR_YEAR_NBR ")
				.append("AND RFRNC.STAR_LVL_CD='Level3' WITH UR");

		return sql;
	}

	/**
	 * This methods builds the where clause for the above query
	 * @param request
	 * @return
	 */
	private String buildWhereClause(GetAVCompletionRequest request) {
		
		StringBuilder sql = new StringBuilder()
				.append("PUSA.sesn_id = ? ")
				.append("and PUSA.enttlmnt_hash_key = ? ");

			if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
				sql.append("and pgd.prov_grp_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + CLOSE_BRACKET);
			}

			if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
				sql.append("and MSSF.pgm_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + CLOSE_BRACKET);
			}
	
			if (StringUtil.isNotBlankOrFalse(request.getPslIds())) {
				sql.append("and PSLD.psl_desc in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPslIds()) + CLOSE_BRACKET);
			}

		    if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
	        	sql.append("and MSSF.prov_org_dim_key in ("
		  		+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys()) + CLOSE_BRACKET);
			}

			return sql.toString();
	}

	

	/**
	 * This method is to build prepared statement(populate values) in the where clause of AVCompletion port-let query 
	 * @param request
	 * @param query
	 * @throws SQLException
	 */
	protected void buildPreparedStatement(GetAVCompletionRequest request, String query) throws SQLException {
		int i = 1;
		prepareStatement(logger, query);

		ps.setString(i++, request.getSessionId());

		ps.setString(i++, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
			String[] array = request.getProvGrpIds().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
			String[] array = request.getProgramIds().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getPslIds())) {
			String[] array = request.getPslIds().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}

	
		 if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) { 
			 String[] array = request.getOrgDimKeys().split(COMMA);
			 for (String item : array) {
				 ps.setString(i++, item); 
			 } 
		 }	  		
	}

	/**
	 * This method populates the JSON object based on the values fetched from the query result
	 * @param results
	 * @throws SQLException
	 */
	private List<AVCompletionJson> getResult(List<AVCompletionJson> results) throws SQLException {
			
			while (rs.next()) {
				AVCompletionJson jsonResult = new AVCompletionJson();		
				jsonResult.setMaxGoal(StringUtil.getValueOrDashes(rs.getString(MAX_GOAL)));
				jsonResult.setMinGoal(StringUtil.getValueOrDashes(rs.getString(MIN_GOAL)));
				jsonResult.setCareopId(StringUtil.getValueOrDashes(rs.getString(MSR_DIM_KEY)));
				jsonResult.setValue(StringUtil.getValueOrDashes(rs.getString(CMPLNC_RT_PCT)));
				jsonResult.setMeasure(ANNUAL_VISIT_COMPLETION);			
				results.add(jsonResult);
			}
			return results;
		}
	
	@Override
	public boolean read(Dto o) throws Exception {
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {}

	@Override
	public void update(Dto o) throws Exception {}

	@Override
	public void delete(Dto o) throws Exception {}
	
}
