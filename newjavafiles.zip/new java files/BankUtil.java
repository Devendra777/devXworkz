class BankUtil{

public static void main (String a[])
{
 Bank bank  = new Bank("ICICI","JP nagar","ICICo456781");   
System.out.println(bank.bankName+ " "+ bank.branchName  + " "+ bank.ifscCode);


Bank bank1 = new Bank("SBI","MahaLakshmi Layout","SBIN6667890");
  System.out.println(bank1.bankName+ " "+ bank1.branchName + " "+ bank1.ifscCode);


Bank bank2 = new Bank("Bandhan","RR Nagar","BANDo456781");
  System.out.println(bank2.bankName+ " "+ bank2.branchName + " "+ bank2.ifscCode);

}
}