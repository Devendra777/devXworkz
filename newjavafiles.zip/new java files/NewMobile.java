class  NewMobile extends MidMobile{

public void doCall(){
System.out.println("calling from new mobile");
}


 void camera(){

}
void videoCall(){

}
void bluetooth(){

}

}