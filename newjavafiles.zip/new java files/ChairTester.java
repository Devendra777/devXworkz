class ChairTester{


public static void main(String a[])
{

    
 Chair chair = new Chair();

  chair.chairId=34;
       chair.name = "Nilkamal";        
      chair.type = "plastic";
     chair.sit();
   
}



}