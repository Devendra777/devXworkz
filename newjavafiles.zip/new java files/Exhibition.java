class   Exhibition
{

static String type="house";
static int total=100;
  public static void main(String a[])
{
String finalType=exhibit(type);
System.out.println(finalType);
String finalTotal=exhibit(total);
System.out.println(finalTotal);
}

static String  exhibit(String type)
{
return type;
}


static int exhibit(int total)
{
return total;
}
}