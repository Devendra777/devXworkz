package com.wellpoint.pc2dash.dto.stars;

import java.io.Serializable;
import java.util.*;

public class PCVCompletionJson implements Serializable {

	
	private static final long serialVersionUID = 2855132403479654483L; 
	
	private String measure;
	private String value;
	private String minGoal;
	private String maxGoal;

	

	public String getMeasure() {
		return measure;
	}

	public void setMeasure(String measure) {
		this.measure = measure;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getMinGoal() {
		return minGoal;
	}

	public void setMinGoal(String minGoal) {
		this.minGoal = minGoal;
	}

	public String getMaxGoal() {
		return maxGoal;
	}

	public void setMaxGoal(String maxGoal) {
		this.maxGoal = maxGoal;
	}
	
	
}