class BarUtil{
public static void main(String a[])
{
  Bar bar = new Bar();

}


}