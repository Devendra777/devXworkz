class Nature
{
  static String place = "Leh-ladakh";
   public static void main(String a[])
{ 
 System.out.println(place);
}
}