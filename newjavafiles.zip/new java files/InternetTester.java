class InternetTester
{
public static void main(String a[])
{
   InternetProvider internet = new  InternetProvider();
  
  internet.address = "Rajajinagar";
  internet.plan = "1month/1000GB";  
internet.cost  = 1100.00;
System.out.println( internet.address + " "+  internet.plan + " "+ internet.cost  );
   InternetProvider internet1 = new  InternetProvider();

  internet1.address = "ITPL";
  internet1.plan = "1year/2000GB";  
internet1.cost  = 8000.00 ;
System.out.println( internet1.address + " "+  internet1.plan + " "+ internet1.cost);
   InternetProvider internet2 = new  InternetProvider();

  internet2.address = "Marathalli";
  internet2.plan = "6months / 1500GB";  
internet2.cost  = 4000.00;
System.out.println( internet2.address + " "+  internet2.plan + " "+ internet2.cost);
System.out.println(InternetProvider.name);
InternetProvider.serve();
}

}