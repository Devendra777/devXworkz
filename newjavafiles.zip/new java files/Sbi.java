class Sbi implements Atm{

void createAccount(){
System.out.println("customer account is created");
}



@Override
public void connectBankDB(){

System.out.println("connect to Sbi-DB");
}
}