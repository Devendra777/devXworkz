	package com.wellpoint.pc2dash.web;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wellpoint.pc2dash.data.dto.User;
import com.wellpoint.pc2dash.data.dto.UserSessionInfo;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.FeedService;
import com.wellpoint.pc2dash.util.ApplicationConfig;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;

/**
 * Application initialization servlet.
 */
public class FeedApp extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(FeedApp.class);

	protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = authenticateSession(request);
		ErrorProperties err = ErrorProperties.getInstance();
		String sessnId = null;//UUID.randomUUID().toString()

		/*
		 * 2.0 Prep: Clean up login parameters. Introduce future parameter names, fall back on existing.
		 *
		 * https://<server>/<context-root>/<servlet>?id=<entitlement>
		 * 
		 * Optional Parameters:
		 *    auth:		Same as existing provGrpId parm. Default is Constants.LOGIN_EXTERNAL.
		 *    showAll:	Same as existing showAll parm. Default is N.
		 * 
		*/
		String entId = request.getParameter("id");
		if (request.getParameter("prov_grp_id") != null) {
			entId = request.getParameter("prov_grp_id");
		}

		String mode = request.getParameter("auth");
		if (request.getParameter("provGrpId") != null) {
			mode = request.getParameter("provGrpId");
		}

		if (mode == null) {
			mode = Constants.LOGIN_EXTERNAL;
		}

		String showAll = request.getParameter("showAll");

		try {

			FeedService service = new FeedService();
			User user = this.getUser(request);
			user.setUserId("AG60756");//temporary change, please put your user id here
			sessnId = service.getLatestUserSessionForProvGrpId(entId, user.getUserId());
			int resultCnt = 0;

			if (!isValidSession(request)) {
				throw new Exception("Not a secure session.");
			}

			if (null == entId || entId.trim().length() == 0) {
				throw new Exception(err.getProperty("entitlementKeyNull"));
			}

			if (mode.equals(Constants.LOGIN_LOCAL)) {
				resultCnt = service.readFromTempTable(sessnId, entId, user.getUserId());
			}
			else if (mode.equals(Constants.LOGIN_INTERNAL) && (user.hasBusinessRole() || user.hasAdminRole())) {
				resultCnt = service.readFromProvTable(sessnId, entId, user.getUserId());
			}
			else if (mode.equals(Constants.LOGIN_EXTERNAL)) {
				resultCnt = service.readFromPoitView(sessnId, entId, user.getUserId());
			}

			if (resultCnt == 0) {
				throw new Exception(err.getProperty("poitNoResults"));
			}

			UserSessionInfo usi = service.getUserSessionInfo();
			usi.setUserId(user.getUserId());
			usi.setFirstName(user.getFirstName());
			usi.setLastName(user.getLastName());
			usi.setIpAddress(user.getIpAddress());
			usi.setAuthMethod(mode);
			usi.setShowAll("N");

			if ("Y".equals(showAll) && (user.hasBusinessRole() || user.hasAdminRole())) {
				usi.setShowAll("Y");
			}

			session.setAttribute("userSessionInfo", usi);
			session.setAttribute("sessnId", sessnId);

			RequestDispatcher requestDispatcher = request.getRequestDispatcher("index.jsp");
			requestDispatcher.forward(request, response);
		}
		catch (Exception e) {

			logger.error("An error in FeedApp has occured", e);

			RequestDispatcher requestDispatcher = request.getRequestDispatcher("unprotected/landing.jsp");
			requestDispatcher.forward(request, response);
		}
	}

	/**
	 * Used to prevent session fixation attacks
	 * @param request
	 * @return
	 */
	private HttpSession authenticateSession(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		return request.getSession();
	}

	/**
	 * Check headers for valid security session.
	 * 
	 * @param request
	 * @return
	 */
	private boolean isValidSession(HttpServletRequest request) {

		Cookie[] cookies = request.getCookies();
		ApplicationConfig cfg = ApplicationConfig.getInstance();

		if ("false".equals(cfg.getProperty("validateSession"))) {
			return true;
		}

		if (cookies != null) {
			for (Cookie c : cookies) {
				if ("SMSESSION".equals(c.getName())) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Get user profile from request headers.
	 * 
	 * @param request
	 * @return
	 */
	private User getUser(HttpServletRequest request) {

		User user = new User();
		ApplicationConfig cfg = ApplicationConfig.getInstance();

		String userId = request.getHeader("SM_USER");
		String firstNm = request.getHeader("FirstName");
		String lastNm = request.getHeader("LastName");

		String mbrshpList = request.getHeader("GroupName");
		String ipAdrs = request.getHeader("X-Forwarded-For");

		if (userId != null) {
			user.setUserId(userId.toUpperCase());
		}

		if (firstNm != null && lastNm != null) {
			user.setFirstName(firstNm);
			user.setLastName(lastNm);
		}

		if (mbrshpList != null &&
			"true".equals(cfg.getProperty("validateSession"))) {

			user.setHasAdminRole(
				mbrshpList.indexOf("CN=PCMS-IT-ADMIN,") >= 0
					|| mbrshpList.indexOf("CN=PCMS-BUSINESS-ADMIN,") >= 0
				);

			user.setHasBusinessRole(
				mbrshpList.indexOf("CN=PCMS-BUSINESS-USER,") >= 0
					|| mbrshpList.indexOf("CN=PCMS-BUSINESS-ADMIN,") >= 0
				);
		}
		else {

			user.setHasAdminRole(true);
			user.setHasBusinessRole(true);
		}

		if (ipAdrs != null) {
			user.setIpAddress(ipAdrs);
		}
		else {
			user.setIpAddress(parseIpAddress(request.getRemoteAddr()));
		}

		try {
			//user.save();
		}
		catch (Exception e) {
			logger.error("Unable to save user info.", e);
		}

		return user;
	}

	/**
	 * Checks validity of address. Returns default IPV4 address if invalid.
	 * 
	 * @param ip
	 * @return
	 */
	private String parseIpAddress(String ip) {

		String ipPattern =
			"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
				"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
				"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
				"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";

		if (ip.matches(ipPattern))
			return ip;

		return "0.0.0.0";
	}
}
