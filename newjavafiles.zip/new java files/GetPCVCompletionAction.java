package com.wellpoint.pc2dash.action.stars;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.service.stars.PCVCompletionServiceImpl;
import com.wellpoint.pc2dash.action.stars.GetPCVCompletionRequest;
import com.wellpoint.pc2dash.dto.stars.PCVCompletionJson;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;

public class GetPCVCompletionAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
	
		PCVCompletionServiceImpl srvc = new PCVCompletionServiceImpl();
		GetPCVCompletionRequest request = (GetPCVCompletionRequest) actionRequest;
		ActionResponse response = new ActionResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		
		
		List<PCVCompletionJson> results = new ArrayList<PCVCompletionJson>();
		
		List<String> grps = null;
		try {

			
			if (null != request) {

				removeLobPgmPrefixes(request);
				
				if (StringUtils.isNotBlank(request.getCmpId())) {
					grps = filterProvGrpsByKillSwitch(request);
				}

				if (null != grps && grps.size() > 0) {

					grps = filterProvGrpsByCmpScrtyLvl(request, grps);
					request.setProvGrpIds(StringUtils.join(grps, ','));
				}

				if (null != grps && !grps.isEmpty()) {

					results = srvc.getPCVTicker(request);
				}
			}

			response.setData(results);
			response.setTotal(srvc.getRowCount());
			response.setSuccess(true);

			if (null == results || (null != results && results.isEmpty())) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
			}

			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
	}
