class  Novel{

int novelId;
String author;
int noOfPages;
double price;

public Novel(){
System.out.println("Novel Object is created");
}

   public void gainingKnowledge(){
        System.out.println("Gaining knowledge...");
}


}