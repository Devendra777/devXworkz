class Danger
{


}