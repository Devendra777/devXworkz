package com.wellpoint.pc2dash.export.population;
import static net.sf.dynamicreports.report.builder.DynamicReports.cmp;
import static net.sf.dynamicreports.report.builder.DynamicReports.col;
import static net.sf.dynamicreports.report.builder.DynamicReports.grid;
import static net.sf.dynamicreports.report.builder.DynamicReports.stl;
import static net.sf.dynamicreports.report.builder.DynamicReports.type;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.sf.dynamicreports.jasper.builder.JasperReportBuilder;
import net.sf.dynamicreports.jasper.constant.JasperProperty;
import net.sf.dynamicreports.report.base.expression.AbstractSimpleExpression;
import net.sf.dynamicreports.report.builder.DynamicReports;
import net.sf.dynamicreports.report.builder.column.TextColumnBuilder;
import net.sf.dynamicreports.report.builder.grid.ColumnGridComponentBuilder;
import net.sf.dynamicreports.report.builder.grid.ColumnTitleGroupBuilder;
import net.sf.dynamicreports.report.builder.style.ConditionalStyleBuilder;
import net.sf.dynamicreports.report.builder.style.SimpleStyleBuilder;
import net.sf.dynamicreports.report.builder.style.StyleBuilder;
import net.sf.dynamicreports.report.constant.HorizontalImageAlignment;
import net.sf.dynamicreports.report.constant.HorizontalTextAlignment;
import net.sf.dynamicreports.report.constant.SplitType;
import net.sf.dynamicreports.report.constant.VerticalTextAlignment;
import net.sf.dynamicreports.report.definition.ReportParameters;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import com.wellpoint.pc2dash.export.DynamicTitle;
import com.wellpoint.pc2dash.export.ExportReporter;
import com.wellpoint.pc2dash.util.StringUtil;


import com.wellpoint.pc2dash.action.careOpportunities.GetCareopportunityTrendRateRequest;

import com.wellpoint.pc2dash.dto.careOpportunities.CareOppTrendRateBeanJson;
import com.wellpoint.pc2dash.dto.patient.CareOpportunitiesFilterJson;

import net.sf.jasperreports.engine.export.tabulator.Column;
import net.sf.jasperreports.engine.export.tabulator.Row;

public class CareOpportunitiesTrendViewRateReporter extends ExportReporter{
	
	
	
	public static JasperReportBuilder buildReportBean(List<CareOppTrendRateBeanJson> resultList,
			GetCareopportunityTrendRateRequest request,
			List<CareOpportunitiesFilterJson> careOpps,
			Map<String, String> riskDriverMap,
			Map<String, String> chronicCareGapMap,
			Map<String, String> referralOutcomeStatusMap,
			Map<String, Map<String, String>> globalFilterMap,
			List<String> statusList) {

			DynamicTitle titleObject = new DynamicTitle();
			String[] opFinal = titleObject.loadTitle(request, careOpps, null, riskDriverMap, chronicCareGapMap,
				null, referralOutcomeStatusMap, globalFilterMap, 9);

			StyleBuilder boldStyle = stl.style().bold();
			StyleBuilder boldCenteredStyle = stl.style(boldStyle)
				.setHorizontalTextAlignment(HorizontalTextAlignment.CENTER);
			StyleBuilder columnTitleStyle = stl.style(boldCenteredStyle)
				.setBorder(stl.pen1Point())
				.setBackgroundColor(new Color(197, 217, 241)).setFontSize(9).setPadding(2);
			SimpleStyleBuilder oddRowStyle = stl.simpleStyle()
				.setBackgroundColor(new Color(248, 251, 252)).setFontSize(8);
			SimpleStyleBuilder evenRowStyle = stl.simpleStyle()
				.setBackgroundColor(new Color(255, 255, 255)).setFontSize(8);

			ConditionalStyleBuilder colorCond01 = stl.conditionalStyle(new Header()).setBackgroundColor(new Color(22, 54, 92)).setForegroundColor(Color.WHITE).bold();
			ConditionalStyleBuilder colorCond02 = stl.conditionalStyle(new Footer(resultList.size())).setBackgroundColor(new Color(22, 54, 92)).setForegroundColor(Color.WHITE).bold();
			StyleBuilder columnStyle = stl.style().setBorder(stl.pen()).conditionalStyles(colorCond01, colorCond02).setFontSize(8).setPadding(2);
			StyleBuilder columnStyle2 =
				stl.style().setBorder(stl.pen()).conditionalStyles(colorCond01, colorCond02).setFontSize(8).setPadding(2).setHorizontalTextAlignment(HorizontalTextAlignment.RIGHT);

			StyleBuilder titleStyle1 = stl.style(boldCenteredStyle).setVerticalTextAlignment(VerticalTextAlignment.MIDDLE).setFontSize(12);
			StyleBuilder titleStyle2 = stl.style(boldCenteredStyle).setVerticalTextAlignment(VerticalTextAlignment.MIDDLE).setFontSize(10);

			JasperReportBuilder report = DynamicReports.report();// a new report


			JRBeanCollectionDataSource beanColDataSource = new JRBeanCollectionDataSource(resultList);

			if (null != beanColDataSource) {
						
				List<ColumnGridComponentBuilder> finalHorizontalColumnsGrid = new ArrayList<ColumnGridComponentBuilder>();
				List<TextColumnBuilder<String>> columns = new ArrayList<TextColumnBuilder<String>>();
				TextColumnBuilder<String> measureName =
					col.column("Measures", "measureName", type.stringType()).setStretchWithOverflow(true).setFixedWidth(350).setStyle(columnStyle).setFixedHeight(14);
				TextColumnBuilder<String> currentYearValue =
					col.column("currentYearValue", "currentYearValue", type.stringType()).setStretchWithOverflow(true).setStyle(columnStyle2).setFixedHeight(14);
				TextColumnBuilder<String> previousYearValue =
					col.column("previousYearValue", "previousYearValue", type.stringType()).setStretchWithOverflow(true).setStyle(columnStyle2).setFixedHeight(14);
				TextColumnBuilder<String> medicareValue =
					col.column("medicareValue", "medicareValue", type.stringType()).setStretchWithOverflow(true).setStyle(columnStyle2).setFixedHeight(14);
				TextColumnBuilder<String> allLobsValue =
						col.column("allLobsValue", "allLobsValue", type.stringType()).setStretchWithOverflow(true).setStyle(columnStyle2).setFixedHeight(14);
				TextColumnBuilder<String> commercialValue =
						col.column("commercialValue", "commercialValue", type.stringType()).setStretchWithOverflow(true).setStyle(columnStyle2).setFixedHeight(14);
				TextColumnBuilder<String> medicaidValue =
						col.column("medicaidValue", "medicaidValue", type.stringType()).setStretchWithOverflow(true).setStyle(columnStyle2).setFixedHeight(14);
				TextColumnBuilder<String> month =
						col.column("month", "month", type.stringType()).setStretchWithOverflow(true).setStyle(columnStyle2).setFixedHeight(14);

				//			export columns
				columns.add(measureName);
				columns.add(month);
				columns.add(currentYearValue);
				columns.add(previousYearValue);
				columns.add(medicareValue);
				columns.add(allLobsValue);
				columns.add(commercialValue);
				columns.add(medicaidValue);

				//			final layout
				finalHorizontalColumnsGrid.add(measureName);
				finalHorizontalColumnsGrid.add(month);
				finalHorizontalColumnsGrid.add(currentYearValue);
				finalHorizontalColumnsGrid.add(previousYearValue);
				finalHorizontalColumnsGrid.add(medicareValue);
				finalHorizontalColumnsGrid.add(allLobsValue);
				finalHorizontalColumnsGrid.add(commercialValue);
				finalHorizontalColumnsGrid.add(medicaidValue);

				report.columns(columns.toArray(new TextColumnBuilder[columns.size()]))
					.columnGrid(finalHorizontalColumnsGrid.toArray(new ColumnGridComponentBuilder[finalHorizontalColumnsGrid.size()]));

				report
					.title(
						cmp.horizontalList()
							.add(cmp.image("Images/app-name.png")
								.setFixedDimension(500, 44)
								.setHorizontalImageAlignment(
									HorizontalImageAlignment.LEFT))
							.newRow()
							.add(cmp.text(request.getGrpName())
								.setStyle(titleStyle1)
								.setHorizontalTextAlignment(
									HorizontalTextAlignment.LEFT))
							.newRow()
							.add(cmp.text(opFinal[0])
								.setStyle(titleStyle1)
								.setHorizontalTextAlignment(
									HorizontalTextAlignment.LEFT))
							.newRow()
							.add(cmp.text(opFinal[1])
								.setStyle(titleStyle2)
								.setHorizontalTextAlignment(
									HorizontalTextAlignment.LEFT))
							.newRow()
							.add(cmp.text(""))
							.newRow()
							.add(cmp.filler()
								.setStyle(stl.style().setTopBorder(stl.pen2Point()))
								.setFixedHeight(10))
					)
					.setDataSource(beanColDataSource)
					.addProperty(JasperProperty.PRINT_KEEP_FULL_TEXT, "true")
					.addProperty(JasperProperty.EXPORT_XLS_WHITE_PAGE_BACKGROUND, "false").setIgnorePageWidth(true)
					.highlightDetailOddRows().setDetailOddRowStyle(oddRowStyle)
					.highlightDetailEvenRows()
					.setDetailEvenRowStyle(evenRowStyle)
					.setColumnTitleStyle(columnTitleStyle);

				if (StringUtil.isXlsxDest(request.getDest())) {
					report.setPageMargin(DynamicReports.margin(0)).setIgnorePagination(true)
						.summary(cmp.horizontalList()
							.add(cmp.filler().setFixedHeight(10))
							.newRow().add(cmp.filler().setFixedHeight(10))
							.newRow().add(StringUtil.getMszComponent(request.getExportDisclaimer(), HorizontalTextAlignment.LEFT))
							.newRow().add(StringUtil.getMszComponent(request.getCopyRightMsg(), HorizontalTextAlignment.RIGHT)));
				}
				else {
					report.setPageMargin(DynamicReports.margin(10))
						.pageFooter(cmp.horizontalList().newRow().add(StringUtil.getMszComponent(request.getExportDisclaimer(), HorizontalTextAlignment.LEFT))
							.newRow().add(StringUtil.getMszComponent(request.getCopyRightMsg(), HorizontalTextAlignment.RIGHT))
							.newRow().add(cmp.pageXofY())).setDetailSplitType(SplitType.PREVENT);
				}
			}


			return report;
		}


	}


