class ScientificCalculator extends Calculator{

void sin(int angle){

System.out.println("sin is" + angle);
}
void cos(int angle){
System.out.println("cos is" + angle);
}


}