package com.hiring.trackr.service;

import com.hiring.trackr.dto.CreatePositionDTO;

public interface CreatePositionService {

	public void savePosition(CreatePositionDTO createPositionDTO);

	public CreatePositionDTO getPositionById(int posId);

}
