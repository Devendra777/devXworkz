class   Biryani{



public static void main(String a[]){
  
   int a = 56 + 89;
System.out.println(a);

}


}