package com.legato.persistence.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.legato.persistence.dto.EnvDTO;

public interface EnvironmentRepository extends JpaRepository<EnvDTO, String>{
	
	

}
