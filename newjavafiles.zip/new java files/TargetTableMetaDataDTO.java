package com.legato.persistence.dto;

public class TargetTableMetaDataDTO {
	
	private int  position;
	private String targetColNm;
	private String targetColDtType;
	private String targetColDtTypeSize;
	private String dataType;
	private int length;
	private String sourceTableNmWDB;
	private String sourceColNm;
	private String sourceDataType;
	private String sourceLength;
	private String transformationLogic;
	private String mergeCmpInd;
	private String release;
	private String comments;
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getTargetColNm() {
		return targetColNm;
	}
	public void setTargetColNm(String targetColNm) {
		this.targetColNm = targetColNm;
	}
	public String getTargetColDtType() {
		return targetColDtType;
	}
	public void setTargetColDtType(String targetColDtType) {
		this.targetColDtType = targetColDtType;
	}
	public String getTargetColDtTypeSize() {
		return targetColDtTypeSize;
	}
	public void setTargetColDtTypeSize(String targetColDtTypeSize) {
		this.targetColDtTypeSize = targetColDtTypeSize;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public String getSourceTableNmWDB() {
		return sourceTableNmWDB;
	}
	public void setSourceTableNmWDB(String sourceTableNmWDB) {
		this.sourceTableNmWDB = sourceTableNmWDB;
	}
	public String getSourceColNm() {
		return sourceColNm;
	}
	public void setSourceColNm(String sourceColNm) {
		this.sourceColNm = sourceColNm;
	}
	public String getSourceDataType() {
		return sourceDataType;
	}
	public void setSourceDataType(String sourceDataType) {
		this.sourceDataType = sourceDataType;
	}
	public String getSourceLength() {
		return sourceLength;
	}
	public void setSourceLength(String sourceLength) {
		this.sourceLength = sourceLength;
	}
	public String getTransformationLogic() {
		return transformationLogic;
	}
	public void setTransformationLogic(String transformationLogic) {
		this.transformationLogic = transformationLogic;
	}
	public String getMergeCmpInd() {
		return mergeCmpInd;
	}
	public void setMergeCmpInd(String mergeCmpInd) {
		this.mergeCmpInd = mergeCmpInd;
	}
	public String getRelease() {
		return release;
	}
	public void setRelease(String release) {
		this.release = release;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
	
}
