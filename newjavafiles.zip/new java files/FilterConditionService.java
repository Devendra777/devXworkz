package com.legato.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.legato.persistence.dto.FilterConditionsDTO;
import com.legato.persistence.repository.FilterConditionRepository;

@Service
public class FilterConditionService {

	@Autowired
	FilterConditionRepository filterConditionRepository;

	public FilterConditionService() {
		// TODO Auto-generated constructor stub
	}

	public void validateAndSaveFilterConditions(FilterConditionsDTO dto) {
		try {
			if (dto != null) {
				filterConditionRepository.save(dto);
			} else {

			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}

		// TODO Auto-generated method stub

	}

}
