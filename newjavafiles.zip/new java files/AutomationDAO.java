package com.legato.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.legato.persistence.dto.EnvDTO;
import com.legato.persistence.dto.EnvironmentDetailsDTO;
import com.legato.persistence.dto.TableColumnsDTO;
import com.legato.persistence.dto.TableNameDTO;
import com.legato.web.view.request.RequestView;

@Repository
public class AutomationDAO extends AbstractDAO{ 
	@Autowired
	private Environment env;

	public List<TableNameDTO> getAllStgTablesDAO(RequestView request) {
		String selectQuery = "select TABNAME from syscat.tables where tabschema = ? ";
		 List<TableNameDTO> list = new ArrayList<>();	
		 TableNameDTO dto = null;
		 try (Connection connObj = stgDataSource.getConnection()) { 
			 try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery)) {
				 pstmt.setString(1, request.getSchemaName());
				try (ResultSet rs = pstmt.executeQuery()) {
					if (rs != null) {
						while(rs.next()) {
							dto = new TableNameDTO();
							dto.setName(rs.getString("TABNAME"));
							list.add(dto);
							}
						}	
					}
			 }
		}catch(Exception e) {
			e.printStackTrace();
		}
	return	 list ;
}
	public List<TableColumnsDTO> getStgTablesColumnsDAO(RequestView request) {
		String selectQuery = "select colno as position,KEYSEQ,\r\n" + 
				"       colname as column_name,\r\n" + 
				"       typename as data_type,\r\n" + 
				"       length,\r\n" + 
				"       scale,\r\n" + 
				"       default,\r\n" + 
				"       remarks as description, \r\n" + 
				"       case when nulls='Y' then 1 else 0 end as nullable,\r\n" + 
				"       case when identity ='Y' then 1 else 0 end as is_identity,\r\n" + 
				"       case when generated ='' then 0 else 1 end as  is_computed,\r\n" + 
				"       text as computed_formula\r\n" + 
				" from syscat.columns\r\n" + 
				" where tabname = ? \r\n" + 
				" and tabschema = ? \r\n" + 
				"order by colno ";
		 List<TableColumnsDTO> list = new ArrayList<>();	
		 TableColumnsDTO dto = null;
		 try (Connection connObj = stgDataSource.getConnection()) { 
			 try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery)) {
				 pstmt.setString(1, request.getTableName());
				 pstmt.setString(2, request.getSchemaName());
				try (ResultSet rs = pstmt.executeQuery()) {
					if (rs != null) {
						while(rs.next()) {
							dto = new TableColumnsDTO();
							dto.setPosition(rs.getInt("position"));
							dto.setColumnName(rs.getString("column_name"));
							dto.setKeySeq(rs.getString("KEYSEQ"));
							dto.setDataType(rs.getString("data_type"));
							dto.setLength(rs.getInt("length"));
							dto.setNullable(rs.getInt("nullable"));
							list.add(dto);
							}
						}	
					}
			 }
		}catch(Exception e) {
			e.printStackTrace();
		}
	return	 list ;
}	
	public List<TableNameDTO> getStgSchemasDAO() {
		String selectQuery = "select schemaname from syscat.schemata";
		 List<TableNameDTO> list = new ArrayList<>();	
		 TableNameDTO dto = null;
		 try (Connection connObj = stgDataSource.getConnection()) { 
			 try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery)) {
				try (ResultSet rs = pstmt.executeQuery()) {
					if (rs != null) {
						while(rs.next()) {
							dto = new TableNameDTO();
							dto.setName(rs.getString("schemaname"));
							list.add(dto);
							}
						}	
					}
			 }
		}catch(Exception e) {
			e.printStackTrace();
		}
	return	 list ;
}
	
	
	public EnvironmentDetailsDTO getEnvDetails(RequestView request){
		EnvironmentDetailsDTO envDetails = new EnvironmentDetailsDTO();
		try{
		envDetails.setTgtDBSF(env.getProperty("sf.sit.servername"));
		envDetails.setTgtTableName("abc_stg"); // need to get it from request
		envDetails.setPrimaryKeyColumns(null);
		envDetails.setQuery(null);
		envDetails.setSrcDBTeradata(env.getProperty("teradata.sit.db"));
		envDetails.setTgtDBHadoop(env.getProperty("hadoop.sit.stgdb"));
		envDetails.setAwsS3InboundFilePath(env.getProperty("aws.incr.etl"));
		envDetails.setHadoopSQLFile("abc_stg.sql");// need to check
		envDetails.setHadoopConfFile(null);// need to check
		envDetails.setNumberOfBigTablePartition(null);
		envDetails.setPartitionColumnName(null);
		envDetails.setInformaticaWorkflowLoadingDB2STGtable(null);
		envDetails.setAwsS3InboundFilePath(null);
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return envDetails;
		
	}

}