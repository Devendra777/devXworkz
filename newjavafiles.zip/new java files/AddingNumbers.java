class  Addition
{
   public static void main(String a[])
  {
       int baba=129;
     int mama=234;
double kk=456;
double zz=420;
 int ans=addNumbers(baba,mama);
System.out.println(ans);

double totl=addNumbers(kk,zz);
System.out.println(totl);
  }
static int   addNumbers(int a,int b)
    {
            int c= a+b;
      return c;
    }


static double  addNumbers(double a,double b)
    {
           double c= a+b;
      return c;
    }





}