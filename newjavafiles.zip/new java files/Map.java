class Map{

public static void main(String a[])
{
System.out.println("Bangalore to Delhi");
}

}