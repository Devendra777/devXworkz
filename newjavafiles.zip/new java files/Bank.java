class Bank  {

    public  int bankId;
    public  String address;
    public String ifscCode;
   public int noOfBranches ;

   public Bank(){
    System.out.println();
  }

public Number giveLoanOnRateOfInterest(){
return 5;
}

@Override
public int hashCode(){
return this.bankId;
}

@Override
public boolean equals(Object  bank){
if( bank  instanceof  Bank){
     Bank bank1 =  (Bank)bank;
  if(this.hashCode() == bank.hashCode()){
        return true;
   }
   if(this.address.equals(bank1.address)){
           return true;
   }
if(this.noOfBranches  == bank1.noOfBranches)
{
return true;
}
if()
  
}
else {
System.out.println("Not a same type");
return false;
         }

return false;
}

}