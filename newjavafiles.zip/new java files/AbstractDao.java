package com.legato.persistence.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@Service
public class AbstractDAO {
	
	@Autowired
	@Qualifier("snowflakeDataSource")
	DataSource db1DataSource;
	
	
	@Autowired
	@Qualifier("snowflakeNamedParameterJdbcTemplate")
	NamedParameterJdbcTemplate db1DataSourceNamedParameterJdbcTemplate;
	
	
//	@Autowired
//	@Qualifier("teradataDataSource")
//	DataSource db2DataSource;
//	
//	@Autowired
//	@Qualifier("teradataNamedParameterJdbcTemplate")
//	NamedParameterJdbcTemplate db2DataSourceNamedParameterJdbcTemplate;
	
	@Autowired
	@Qualifier("db2DataSource")
	DataSource stgDataSource;
	
	@Autowired
	@Qualifier("db2NamedParameterJdbcTemplate")
	NamedParameterJdbcTemplate stgDataSourceNamedParameterJdbcTemplate;
	
}
