package com.wellpoint.pc2dash.action.stars;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetPCVCompletionRequest extends PCMSRequest{

}
