

class Mobile{

private AppsDTO[]    apps;
private  int ind;

public Mobile(int size){
     apps   =  new AppsDTO[size];
}


public boolean createApps(AppsDTO apps){
boolean dataCreated =  false;
     System.out.println("invoked createApps");
if(apps != null){
                        if(apps.getName() != null && apps.getAppsId() > 0){
       this.apps[ind++] = apps;
         dataCreated  =  true;
               }
         else{ 
                  System.out.println("Id must be greater than zero");
               }
   
   }
else{
  System.out.println("Apps DTO object not found");
}
 System.out.println(" createApps ended");
return dataCreated;
}



public void  getApps(){
     System.out.println("invoked getApps");
for(AppsDTO appDTO :   apps){
   if(appDTO != null){
  System.out.println( appDTO.getAppsId() + "  "+ appDTO.getName() +  "  "+  appDTO.getType() + "  "+ appDTO.getSizeInMb()+ "  "+ appDTO.getInternetRequired());
  }
else{
System.out.println("Apps DTO object not found");
   }


}
}



public boolean updateAppSizeByName(String size , String name){
boolean sizeUpdated  = false;
  System.out.println("invoked updateAppSizeByName");
for(AppsDTO dto :  apps){
      if(size != null && name != null){
                    if(name.equals(dto.getName())){
                               dto.setSizeInMb(size); 
 
                              sizeUpdated = true;
                      }
                  else{
                        System.out.println(  name + "    not found");
                    }

            }
      else{
      System.out.println("size and name are empty   cannot proceed to update");
        }
}
return  sizeUpdated ;
}





















}