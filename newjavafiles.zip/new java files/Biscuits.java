class Biscuits{
public static void main(String a[]){
     
   String       biscuitsName = "HideAndSeek" ; 
        int              amount  =10;
      String mfgDate =  "Jun 2021";
        String   expiryDate = "Jul 2022" ;
  String color = "DarkBrown";
     
            System.out.println(biscuitsName);
            System.out.println(amount);
System.out.println(mfgDate);
System.out.println(expiryDate);
System.out.println(color);



}
public static  void killHinger(){
System.out.println("Hmmmmmm......");

 public static void m(){
}
}
}