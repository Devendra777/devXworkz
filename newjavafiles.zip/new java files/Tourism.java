class Tourism
{
    static short bangaloreTourism=20000;
   static int shimlaTourism= 50000;
  static long rajasthanTourism=100000000000l;
static short telanganaTourism=30000;
    public static void main(String a[])
      {
    System.out.println(bangaloreTourism);
 System.out.println(rajasthanTourism);
 System.out.println(telanganaTourism);
 System.out.println(shimlaTourism);
     }
}