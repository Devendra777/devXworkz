interface Parent1{


    String name = "Gagan";


}