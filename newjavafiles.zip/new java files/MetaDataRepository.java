package com.legato.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.legato.persistence.dto.MetaDataDTO;

public interface MetaDataRepository extends JpaRepository<MetaDataDTO, String>{

}
