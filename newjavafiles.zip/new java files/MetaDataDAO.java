package com.legato.persistence.dao;

import org.springframework.stereotype.Repository;

@Repository
public class MetaDataDAO extends AbstractDAO{
	
	
	public MetaDataDAO() {
		// TODO Auto-generated constructor stub
	}

}
