class GoogleDrive extends Google{

void sendMail(){
System.out.println("sending mail from drive");
}

}