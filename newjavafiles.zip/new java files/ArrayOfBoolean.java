class ArrayOfBoolean
{

  public static void main(String a[])
{
  char ch[]={'B','U','T','T','E','R','F','L','Y'};

for(int i=0;i<ch.length;i++)
{
System.out.print(ch[i]);
}
}
}