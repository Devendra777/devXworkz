class Chair{
      
   static int chairId;
  static  String name ; 
  static  String type;

public  void sit(){
System.out.println(chairId + "  "+ name + "  "+type);
System.out.println("seating purpose");
}

}