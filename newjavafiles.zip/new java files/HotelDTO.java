public class HotelDTO
{
   public static String type="5 star";
   private  String name ;
   private String address; 

                                        
public void  setName(String nm)
{
         name=nm;
}
public String  getName()
{
           return  name;
}
public void  setAddress(String ad)
{
         address=ad;
}
public String  getAddress()
{
           return  address;
}


}