class Tester
{

public static  void main(String a[])
{
  explode(34);
explode("atom");
}

static void explode(int number)
{
System.out.println(number);
}

static void explode(String name)
{
System.out.println(name);

}
}