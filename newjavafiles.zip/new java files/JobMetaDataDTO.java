package com.legato.persistence.dto;

public class JobMetaDataDTO {
	
	private String appCode;
	private String s3bucketKey;
	private String domainCode;
	private String sorCode;
	private String targetTblName;
	private String targetSchema;
	private String prcsngType;
	private String jobName;
	private String loadType;
	private String s3InboundBucket;
	private String s3InboundKey;
	private String s3ArchiveBucket;
	private String s3ArchieveKey;
	private String s3AppBucket;
	private String s3AppKey;
	private String s3CnsmptionBucket;
	private String s3CnsmptionKey;
	private String targetPlatForm;
	private String delTableName;
	private String stgTableName;
	private String stgSchema;
	private String keyList;
	private String delKeyList;
	private String srcFileType;
	private String unldFileType;
	private String unldPartnKey;
	private String unldFrequency;
	private String unldType;
	private String unldTargetPlatform;
	private String dlmtr;
	private String vrncAlwdPct;
	private String postLoadMethod;
	private String jobType;
	private String etlJobParams;
	private String loadFrequency;
	private String dscverSchemaFlag;
	private String reqId;
	private String ownershipTeam;
	private String unloadBukcetSet;
	private String wareHouseSuffix;
	public String getAppCode() {
		return appCode;
	}
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	public String getS3bucketKey() {
		return s3bucketKey;
	}
	public void setS3bucketKey(String s3bucketKey) {
		this.s3bucketKey = s3bucketKey;
	}
	public String getDomainCode() {
		return domainCode;
	}
	public void setDomainCode(String domainCode) {
		this.domainCode = domainCode;
	}
	public String getSorCode() {
		return sorCode;
	}
	public void setSorCode(String sorCode) {
		this.sorCode = sorCode;
	}
	public String getTargetTblName() {
		return targetTblName;
	}
	public void setTargetTblName(String targetTblName) {
		this.targetTblName = targetTblName;
	}
	public String getTargetSchema() {
		return targetSchema;
	}
	public void setTargetSchema(String targetSchema) {
		this.targetSchema = targetSchema;
	}
	public String getPrcsngType() {
		return prcsngType;
	}
	public void setPrcsngType(String prcsngType) {
		this.prcsngType = prcsngType;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getLoadType() {
		return loadType;
	}
	public void setLoadType(String loadType) {
		this.loadType = loadType;
	}
	public String getS3InboundBucket() {
		return s3InboundBucket;
	}
	public void setS3InboundBucket(String s3InboundBucket) {
		this.s3InboundBucket = s3InboundBucket;
	}
	public String getS3InboundKey() {
		return s3InboundKey;
	}
	public void setS3InboundKey(String s3InboundKey) {
		this.s3InboundKey = s3InboundKey;
	}
	public String getS3ArchiveBucket() {
		return s3ArchiveBucket;
	}
	public void setS3ArchiveBucket(String s3ArchiveBucket) {
		this.s3ArchiveBucket = s3ArchiveBucket;
	}
	public String getS3ArchieveKey() {
		return s3ArchieveKey;
	}
	public void setS3ArchieveKey(String s3ArchieveKey) {
		this.s3ArchieveKey = s3ArchieveKey;
	}
	public String getS3AppBucket() {
		return s3AppBucket;
	}
	public void setS3AppBucket(String s3AppBucket) {
		this.s3AppBucket = s3AppBucket;
	}
	public String getS3AppKey() {
		return s3AppKey;
	}
	public void setS3AppKey(String s3AppKey) {
		this.s3AppKey = s3AppKey;
	}
	public String getS3CnsmptionKey() {
		return s3CnsmptionKey;
	}
	public void setS3CnsmptionKey(String s3CnsmptionKey) {
		this.s3CnsmptionKey = s3CnsmptionKey;
	}
	public String getTargetPlatForm() {
		return targetPlatForm;
	}
	public void setTargetPlatForm(String targetPlatForm) {
		this.targetPlatForm = targetPlatForm;
	}
	public String getDelTableName() {
		return delTableName;
	}
	public void setDelTableName(String delTableName) {
		this.delTableName = delTableName;
	}
	public String getStgTableName() {
		return stgTableName;
	}
	public void setStgTableName(String stgTableName) {
		this.stgTableName = stgTableName;
	}
	public String getStgSchema() {
		return stgSchema;
	}
	public void setStgSchema(String stgSchema) {
		this.stgSchema = stgSchema;
	}
	public String getKeyList() {
		return keyList;
	}
	public void setKeyList(String keyList) {
		this.keyList = keyList;
	}
	public String getDelKeyList() {
		return delKeyList;
	}
	public void setDelKeyList(String delKeyList) {
		this.delKeyList = delKeyList;
	}
	public String getSrcFileType() {
		return srcFileType;
	}
	public void setSrcFileType(String srcFileType) {
		this.srcFileType = srcFileType;
	}
	public String getUnldFileType() {
		return unldFileType;
	}
	public void setUnldFileType(String unldFileType) {
		this.unldFileType = unldFileType;
	}
	public String getUnldPartnKey() {
		return unldPartnKey;
	}
	public void setUnldPartnKey(String unldPartnKey) {
		this.unldPartnKey = unldPartnKey;
	}
	public String getUnldFrequency() {
		return unldFrequency;
	}
	public void setUnldFrequency(String unldFrequency) {
		this.unldFrequency = unldFrequency;
	}
	public String getUnldType() {
		return unldType;
	}
	public void setUnldType(String unldType) {
		this.unldType = unldType;
	}
	public String getUnldTargetPlatform() {
		return unldTargetPlatform;
	}
	public void setUnldTargetPlatform(String unldTargetPlatform) {
		this.unldTargetPlatform = unldTargetPlatform;
	}
	public String getDlmtr() {
		return dlmtr;
	}
	public void setDlmtr(String dlmtr) {
		this.dlmtr = dlmtr;
	}
	public String getVrncAlwdPct() {
		return vrncAlwdPct;
	}
	public void setVrncAlwdPct(String vrncAlwdPct) {
		this.vrncAlwdPct = vrncAlwdPct;
	}
	public String getPostLoadMethod() {
		return postLoadMethod;
	}
	public void setPostLoadMethod(String postLoadMethod) {
		this.postLoadMethod = postLoadMethod;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getEtlJobParams() {
		return etlJobParams;
	}
	public void setEtlJobParams(String etlJobParams) {
		this.etlJobParams = etlJobParams;
	}
	public String getLoadFrequency() {
		return loadFrequency;
	}
	public void setLoadFrequency(String loadFrequency) {
		this.loadFrequency = loadFrequency;
	}
	public String getDscverSchemaFlag() {
		return dscverSchemaFlag;
	}
	public void setDscverSchemaFlag(String dscverSchemaFlag) {
		this.dscverSchemaFlag = dscverSchemaFlag;
	}
	public String getReqId() {
		return reqId;
	}
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}
	public String getOwnershipTeam() {
		return ownershipTeam;
	}
	public void setOwnershipTeam(String ownershipTeam) {
		this.ownershipTeam = ownershipTeam;
	}
	public String getUnloadBukcetSet() {
		return unloadBukcetSet;
	}
	public void setUnloadBukcetSet(String unloadBukcetSet) {
		this.unloadBukcetSet = unloadBukcetSet;
	}
	public String getWareHouseSuffix() {
		return wareHouseSuffix;
	}
	public void setWareHouseSuffix(String wareHouseSuffix) {
		this.wareHouseSuffix = wareHouseSuffix;
	}
	public String getS3CnsmptionBucket() {
		return s3CnsmptionBucket;
	}
	public void setS3CnsmptionBucket(String s3CnsmptionBucket) {
		this.s3CnsmptionBucket = s3CnsmptionBucket;
	}
	
	
	
	

}
