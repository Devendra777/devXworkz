class Baba_{

public static void main(String a[]){
System.out.println("baba is a great guy");
}
}