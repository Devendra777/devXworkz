class Browser{

   String name;


public static void main(String a[])
{
 Browser browser = new Browser();
browser.name = "Firefox";
browser.browse();
System.out.println(browser.name);

}
void browse()
{

System.out.println("Browsing about github");
}


}