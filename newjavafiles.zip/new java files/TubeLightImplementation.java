class TubeLightImplementation implements Switch{
//Implementation Logic
@Override
 public void    sOn(){
 System.out.println("providing implmentation for TubeLight");
System.out.println("Tube Light is turned Onn");
}

@Override
  public void   sOff(){
 System.out.println("providing implmentation for TubeLight");
System.out.println("Tube Light is turned Off");
}


}