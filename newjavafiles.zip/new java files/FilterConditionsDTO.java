package com.legato.persistence.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="filter_condtn_and_grp_dtl")
public class FilterConditionsDTO {
	
	public FilterConditionsDTO() {
		// TODO Auto-generated constructor stub
	}
	
	@Id
	@Column(name="tbl_nm")
	private String tblName;
	
	@Column(name="filter_condtn_and_grp_txt")
	private String filterConditionAndGroupText;

	public String getTblName() {
		return tblName;
	}

	public void setTblName(String tblName) {
		this.tblName = tblName;
	}

	public String getFilterConditionAndGroupText() {
		return filterConditionAndGroupText;
	}

	public void setFilterConditionAndGroupText(String filterConditionAndGroupText) {
		this.filterConditionAndGroupText = filterConditionAndGroupText;
	}
	
	

}
