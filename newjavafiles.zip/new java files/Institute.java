class Institute
{
  static String name="x-workz";
  static String address= "Rajajinagar";
    
}