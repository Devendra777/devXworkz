class Sweety{

public static void main(String a[])
{
 System.out.println("Hi Sweety");
}




}