package com.wellpoint.pc2dash.service.careOpportunitiesTrending;

import static com.wellpoint.pc2dash.util.Constants.CLOSE_BRACKET;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.wellpoint.pc2dash.action.careOpportunities.GetCareOpportunityCurrentTrendRequest;
import com.wellpoint.pc2dash.action.careOpportunitiesTrending.CareOpportunitiesRateJson;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.dto.careOpportunities.CareOpportunitiesTrendBean;
import com.wellpoint.pc2dash.dto.careOpportunities.CareOpportunitiesTrendJson;
import com.wellpoint.pc2dash.dto.careOpportunities.TrendMetadata;
import com.wellpoint.pc2dash.dto.patient.CareOpportunitiesFilterJson;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;
import com.wellpoint.pc2dash.util.TrendMonthComparator;
import com.wellpoint.pc2dash.util.CommonQueries;

public class CareOpportunityTrendRateServiceImpl extends ServiceImpl {

	private static final String PM_CO_TRENDINGCHART = "pm-co-trendingchart";
	private static final String ROOT = "root";
	private static final String QUOTES_TWELVE = "12";
	private static final String QUOTES_ZERO_ONE = "01";
	private static final String UNICARE = "UniCare";
	private static final String MEDICAID_VALUE = "medicaidValue";
	private static final String ALL_LOBS = "ALL LOBs";
	private static final String MEDICARE_VALUE = "medicareValue";
	private static final String COMMERCIAL_VALUE = "commercialValue";
	private static final String ALL_LOBS_VALUE = "allLobsValue";
	private static final String PREVIOUS_YEAR = "Previous Year";
	private static final String CURRENT_YEAR = "Current Year";
	private static final String PREVIOUS_YEAR_VALUE = "previousYearValue";
	private static final String CURRENT_YEAR_VALUE = "currentYearValue";
	private static final String UNABLE_TO_GET_MAX_MONTH_FOR_CARE_OPPORTUNITY_TREND = "Unable to get max_month for Care Opportunity Trend.";
	private static final int HUNDRED = 100;
	private static final long ZEROL = 0L;
	private static final String HYPHEN = "-";
	private static final int TWELVE = 12;
	private static final String HYPEN_ZERO_ONE = "-01";
	private static final String MEDICAID = "Medicaid";
	private static final String MEDICARE = "Medicare";
	private static final String ONE_TWO = "/12";
	private static final String ZERO_ONE = "/01";
	private static final int FOUR = 4;
	private static final String COMMERCIAL = "Commercial";
	private static final int ZERO = 0;
	private static final int ONE = 1;
	private static final int TWO = 2;
	private static final String FIFTHPERCENTILE = "5th Percentile";
	private static final String TWENTYFIFTHPERCENTILE = "25th Percentile";
	private static final String SEVENTYFIFTHPERCENTILE = "75th Percentile";
	private static final String NINTYFIFTHPERCENTILE = "95th Percentile";
	private static final String FIFTHPERCENTILEBENCHMARK = "percentileBenchmark5th";
	private static final String TWENTYFIFTHPERCENTILEBENCHMARK = "percentileBenchmark25th";
	private static final String SEVENTYFIFTHPERCENTILEBENCHMARK = "percentileBenchmark75th";
	private static final String NINTYFIFTHPERCENTILEBENCHMARK = "percentileBenchmark95th";
	private static final String ONESTAR = "1 Star";
	private static final String TWOSTAR = "2 Star";
	private static final String THREESTAR = "3 Star";
	private static final String FOURSTAR = "4 Star";
	private static final String FIVESTAR = "5 Star";
	private static final String ONESTARBENCHMARK = "benchmark1Star";
	private static final String TWOSTARBENCHMARK = "benchmark2Star";
	private static final String THREESTARBENCHMARK = "benchmark3Star";
	private static final String FOURSTARBENCHMARK = "benchmark4Star";
	private static final String FIVESTARBENCHMARK = "benchmark5Star";
	private static final String LEVELONEBENCHMARK = "benchmarkLevel1";
	private static final String LEVELTWOBENCHMARK = "benchmarkLevel2";
	private static final String LEVELTHREEBENCHMARK = "benchmarkLevel3";
	private static final String LEVELFOURBENCHMARK = "benchmarkLevel4";
	private static final String LEVELONE = "Level 1";
	private static final String LEVELTWO = "Level 2";
	private static final String LEVELTHREE = "Level 3";
	private static final String LEVELFOUR = "Level 4";
	private static final String STAR = "1Star";
	private static final String LEVEL1 = "Level1";
	private static final String LEVEL2 = "Level2";

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CareOpportunityTrendRateServiceImpl.class);

	/**
	 * This method is to generate query and fetch data from CARE_OPP_TRND_SMRY_FACT
	 * based on Single / Mixed LOB
	 * 
	 * @param request
	 * @param max_month
	 * @param lobvalue
	 * @param previousyears
	 * @param currentyears
	 * @return
	 * @throws Exception
	 */
	public List<CareOpportunitiesTrendBean> getdata(GetCareOpportunityCurrentTrendRequest request, String max_month,
			int lobvalue, boolean previousyears, boolean currentyears) throws Exception {

		List<CareOpportunitiesTrendBean> resultList = new ArrayList<CareOpportunitiesTrendBean>();
		StringBuilder query = new StringBuilder()
		.append("select ")
        .append("SUM(CASE WHEN CARE_OPRTNTY_STTS_CD='0' THEN NMRTR_NBR ELSE 0 END) as NMRTR_NBR, ")
        .append("SUM(DNMNTR_NBR) as DNMNTR_NBR,  ")
        .append("CASE WHEN SUM(DNMNTR_NBR)=0 then 0 ")
        .append(" else CAST(ROUND(CAST(SUM(CASE WHEN CARE_OPRTNTY_STTS_CD='0' THEN NMRTR_NBR ELSE 0 END)*100 AS DECIMAL(18,4))/SUM(DNMNTR_NBR),2) AS DECIMAL(6,2)) end AS CLOSE_RATIO, ")
        .append("MNTH_ID,(CASE WHEN LOB_CTGRY_NM='UniCare' THEN 'Commercial' ELSE LOB_CTGRY_NM END) as LOB_CTGRY_NM ")
        .append("FROM CARE_OPP_TRND_SMRY_FACT CTSF ")
        .append("JOIN MSR_DIM MD1 ON CTSF.MSR_DIM_KEY = MD1.MSR_DIM_KEY AND MD1.MSR_SRC_CD='CAREOPP' ")
        .append("JOIN MSR_DIM MD2 ON MD1.RULE_ID = MD2.RULE_ID AND MD2.MSR_SRC_CD='CAREOPP' ")
        .append("JOIN CLNCL_MSR_HRCHY_DIM CMHD ON CMHD.MSR_DIM_KEY = MD2.MSR_DIM_KEY ")
        .append("JOIN PGM_CLNCL_MSR_HRCHY_FACT PGMCLNL ON PGMCLNL.MSR_DIM_KEY = MD2.MSR_DIM_KEY AND PGMCLNL.PGM_DIM_KEY = CTSF.PGM_DIM_KEY ")
        .append("join poit_user_scrty_acs pusa on ( ")
        .append("           CTSF.prov_grp_id = pusa.prov_grp_id ")
        .append("           and case ")
        .append("                                           when pusa.prov_org_tax_id = '0' then CTSF.prov_org_tax_id ")
        .append("                                           else CTSF.prov_org_tax_id ")
        .append("                           end = CTSF.prov_org_tax_id ")
        .append(") ");    
        query.append("where ")
        .append(createWhereClause(request, lobvalue))
        .append("group by ")
        .append("MNTH_ID ")
        .append("(CASE WHEN LOB_CTGRY_NM='UniCare' THEN 'Commercial' ELSE LOB_CTGRY_NM END) ")
        .append("with ur ")
        .append(" UNION ALL ")
        .append(" select ")
        .append(" CNDTN_NM ")
        .append("SUM(CASE  WHEN  CARE_OPRTNTY_STTS_CD='0' THEN NMRTR_NBR ELSE  0 END) as NMRTR_NBR, ")
        .append("SUM(DNMNTR_NBR) as DNMNTR_NBR, ")
        .append("CASE WHEN SUM(DNMNTR_NBR)=0 then 0 ")
        .append(" else CAST(ROUND(CAST(SUM(CASE CARE_OPRTNTY_STTS_CD='0' THEN NMRTR_NBR ELSE 0 END*100 AS DECIMAL(18,4))/SUM(DNMNTR_NBR),2) AS DECIMAL(6,2)) end AS CLOSE_RATIO, ")
        .append("MNTH_ID,(CASE WHEN LOB_CTGRY_NM='UniCare' THEN  'Commercial' ELSE LOB_CTGRY_NM END) as LOB_CTGRY_NM ")
        .append("from  CARE_OPP_TRND_SMRY_FACT CTSF ")
        .append("JOIN  MSR_DIM MD1 ON CTSF.MSR_DIM_KEY = MD1.MSR_DIM_KEY AND MD1.MSR_SRC_CD='CAREOPP' ")
        .append("JOIN MSR_DIM MD2 ON MD1.RULE_ID = MD2.RULE_ID AND MD2.MSR_SRC_CD='CAREOPP' ")
        .append("JOIN  CLNCL_MSR_HRCHY_DIM CMHD ON CMHD.MSR_DIM_KEY = MD2.MSR_DIM_KEY ")
        .append("JOIN PGM_CLNCL_MSR_HRCHY_FACT PGMCLNL ON PGMCLNL.MSR_DIM_KEY = MD2.MSR_DIM_KEY AND PGMCLNL.PGM_DIM_KEY = CTSF.PGM_DIM_KEY ")
        .append("join  poit_user_scrty_acs pusa on ( ")
        .append("          CTSF.prov_grp_id = pusa.prov_grp_id ")
        .append("          and case ")
        .append("                                         when  pusa.prov_org_tax_id = '0' then  CTSF.prov_org_tax_id ")
        .append("                                        else  CTSF.prov_org_tax_id ")
        .append("                                        end = CTSF.prov_org_tax_id ")
        .append(") ");
        query.append("where ")
        .append(createWhereClause(request, lobvalue))
        .append(" group by ")
         .append("CNDTN_NM, ")
         .append("MNTH_ID  ")
         .append("(CASE LOB_CTGRY_NM='UniCare' THEN  'Commercial' ELSE LOB_CTGRY_NM END) ")
         .append("with ur ");

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(request, lobvalue, query.toString(), max_month, previousyears, currentyears);
			executeQuery(logger, query.toString());
			resultList = convertSelectedRowsToObjects(rs);
		} catch (Exception e) {
			StringBuilder builder = new StringBuilder();
			builder.append("Exception during getData in Trend Service (").append(request.toString()).append(").\nSQL: ")
					.append(query);
			throw new PC2Exception(builder.toString(), e);
		} finally {
			close();
		}

		return resultList;

	}

	/**
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private StringBuilder createWhereClause(GetCareOpportunityCurrentTrendRequest request, int lobvalue)
			throws Exception {

		StringBuilder query = new StringBuilder()

				.append(" pusa.sesn_id = ? ").append("and pusa.enttlmnt_hash_key = ? ");

		if (lobvalue == 1
				&& (request.getLobCtgryNm().contains(MEDICAID) || request.getLobCtgryNm().contains(MEDICARE))) {
			query.append(" and MNTH_ID >= ? AND MNTH_ID <= ? ");
		} else if ((lobvalue == 1
				&& (request.getLobCtgryNm().contains(COMMERCIAL) || request.getLobCtgryNm().contains(UNICARE)))
				|| lobvalue >= 2) {
			query.append(" and MNTH_ID > ? AND MNTH_ID <= ? ");
		}

		query.append("AND CMHD.MSR_SPRS_IND_CD = 'N' ")
				.append("AND  CTSF.CARE_OPRTNTY_STTS_CD IN ('1','2','3','4','0')  ")
				.append("AND  CURRENT_DATE BETWEEN PGMCLNL.PGM_CLNCL_MSR_HRCHY_EFCTV_DT AND PGMCLNL.PGM_CLNCL_MSR_HRCHY_TRMNTN_DT ");

		if (!request.getMeasureId().equalsIgnoreCase(ROOT) && request.getCareOppsFilter() != null
				&& request.getCmpId().equalsIgnoreCase(PM_CO_TRENDINGCHART)) {
			query.append("AND md2.msr_dim_key = ? ");
		} else if (!request.getMeasureId().equalsIgnoreCase(ROOT) && request.getCareOppsFilter() != null
				&& !request.getCmpId().equalsIgnoreCase(PM_CO_TRENDINGCHART)) {
			buildCareOppsFilterWhereClauseTrend(request, query);
		} else if (!request.getMeasureId().equalsIgnoreCase(ROOT) && request.getCareOppsFilter() == null) {
			query.append("AND CNDTN_NM = ? ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
			query.append("and CTSF.prov_grp_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + CLOSE_BRACKET);
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and CTSF.ip_dim_key in (")
					.append(StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys())).append(") ");
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and CTSF.prov_org_dim_key in (")
					.append(StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())).append(") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getLobIds())) {
			query.append(" and CTSF.lob_desc in (")
					.append(StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds())).append(") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getPslIds())) {
			query.append(" and CTSF.psl_desc in (")
					.append(StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPslIds())).append(") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
			query.append(" and CTSF.pgm_dim_key in (")
					.append(StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds())).append(") ");
		}
		return query;
	}

	/**
	 * @param request
	 * @param query
	 */
	private void buildCareOppsFilterWhereClauseTrend(PCMSRequest request, StringBuilder query) {

		List<String> careOppsKeys = new ArrayList<String>();

		for (CareOpportunitiesFilterJson careOpp : request.getCareOppsFilter()) {
			for (CareOpportunitiesFilterJson child : careOpp.getChildren()) {
				careOppsKeys.add(child.getId());
			}
		}

		query.append(" and ");
		query.append(" md2.msr_dim_key in ( ").append(StringUtil.buildPlaceholders(careOppsKeys.size()))
				.append("	) ");

		request.setCareOppsKeysString(careOppsKeys);
	}

	/**
	 * @param request
	 * @param query
	 * @param max_month
	 * @param previousyears
	 * @param currentyears
	 * @throws Exception
	 */
	private void buildPreparedStatement(GetCareOpportunityCurrentTrendRequest request, int lobvalue, String query,
			String max_month, boolean previousyears, boolean currentyears) throws Exception {

		int i = ZERO;
		prepareStatement(logger, query);
		
		 i=buildprepareStatements(request,  lobvalue,  query,
				 max_month,  previousyears,  currentyears, i);
		 
		 i=buildprepareStatements(request,  lobvalue,  query,
				 max_month,  previousyears,  currentyears, i);

		
	}

	private int buildprepareStatements(GetCareOpportunityCurrentTrendRequest request, int lobvalue, String query,
			String max_month, boolean previousyears, boolean currentyears, int i) throws SQLException, ParseException {
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (lobvalue == ONE
				&& (request.getLobCtgryNm().contains(MEDICARE) || request.getLobCtgryNm().contains(MEDICAID))
				&& previousyears == true) {
			int fromdate = Integer.parseInt(max_month.substring(ZERO, FOUR)) - 1;
			ps.setString(++i, fromdate + QUOTES_ZERO_ONE);
			ps.setString(++i, fromdate + QUOTES_TWELVE);
		} else if (lobvalue == ONE
				&& (request.getLobCtgryNm().contains(MEDICARE) || request.getLobCtgryNm().contains(MEDICAID))
				&& currentyears == true) {
			int fromdate = Integer.parseInt(max_month.substring(ZERO, FOUR));
			ps.setString(++i, String.valueOf(fromdate) + QUOTES_ZERO_ONE);
			ps.setString(++i, max_month);
		} else if (lobvalue == ONE
				&& (request.getLobCtgryNm().contains(COMMERCIAL) || request.getLobCtgryNm().contains(UNICARE))
				&& previousyears == true) {
			String defaultFromDate = null;
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
			CommonQueries cq = new CommonQueries();
			int fromdate = Integer.parseInt(max_month.substring(ZERO, FOUR)) - ONE;
			String created_date = Integer.toString(fromdate) + HYPHEN + max_month.substring(max_month.length() - TWO)
					+ HYPEN_ZERO_ONE;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date convertedCurrentDate = sdf.parse(created_date);
			Date fromDate = cq.getDefaultFromDate(convertedCurrentDate, TWELVE);
			defaultFromDate = dateFormat.format(fromDate);
			ps.setString(++i, defaultFromDate);
			ps.setString(++i, Integer.toString(fromdate) + max_month.substring(max_month.length() - TWO));
		} else if (lobvalue == ONE
				&& (request.getLobCtgryNm().contains(COMMERCIAL) || request.getLobCtgryNm().contains(UNICARE))
				&& currentyears == true) {
			String defaultFromDate = null;
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
			CommonQueries cq = new CommonQueries();
			String created_date = max_month.substring(ZERO, FOUR) + HYPHEN
					+ max_month.substring(max_month.length() - TWO) + HYPEN_ZERO_ONE;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date convertedCurrentDate = sdf.parse(created_date);
			Date fromDate = cq.getDefaultFromDate(convertedCurrentDate, TWELVE);
			defaultFromDate = dateFormat.format(fromDate);
			ps.setString(++i, defaultFromDate);
			ps.setString(++i, max_month);
		} else if (lobvalue >= TWO) {
			String defaultFromDate = null;
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
			CommonQueries cq = new CommonQueries();
			String created_date = max_month.substring(ZERO, FOUR) + HYPHEN
					+ max_month.substring(max_month.length() - TWO) + HYPEN_ZERO_ONE;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date convertedCurrentDate = sdf.parse(created_date);
			Date fromDate = cq.getDefaultFromDate(convertedCurrentDate, TWELVE);
			defaultFromDate = dateFormat.format(fromDate);

			ps.setString(++i, defaultFromDate);
			ps.setString(++i, max_month);
		}

		if (StringUtil.isNotBlankOrFalse(request.getMeasureId()) && !request.getMeasureId().equalsIgnoreCase(ROOT)
				&& request.getCareOppsFilter() != null && request.getCmpId().equalsIgnoreCase(PM_CO_TRENDINGCHART)) {
			String[] array = request.getMeasureId().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		} else if (StringUtil.isNotBlankOrFalse(request.getMeasureId())
				&& !request.getMeasureId().equalsIgnoreCase(ROOT) && request.getCareOppsFilter() != null
				&& !request.getCmpId().equalsIgnoreCase(PM_CO_TRENDINGCHART)) {
			i = buildCareOppsFilterPreparedStatement(request, i);
		} else if (!request.getMeasureId().equalsIgnoreCase(ROOT) && request.getCareOppsFilter() == null) {
			String[] array = request.getMeasureName().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
			String[] array = request.getProvGrpIds().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getLobIds())) {
			String[] array = request.getLobIds().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getPslIds())) {
			String[] array = request.getPslIds().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
			String[] array = request.getProgramIds().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		return i;
		
		
	}

	/**
	 * This method is to populate data into bean for further processing in Single /
	 * Mixed LOB
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private List<CareOpportunitiesTrendBean> convertSelectedRowsToObjects(ResultSet rs) throws SQLException {

		List<CareOpportunitiesTrendBean> results = new ArrayList<CareOpportunitiesTrendBean>();

		while (rs.next()) {
			CareOpportunitiesTrendBean bean = new CareOpportunitiesTrendBean();
			bean.setNumerator(rs.getLong("NMRTR_NBR"));
			bean.setDenominator(rs.getLong("DNMNTR_NBR"));
			bean.setCloseRatio(rs.getString("CLOSE_RATIO"));
			bean.setMonth(rs.getString("MNTH_ID"));
			bean.setLobCategoryNm(rs.getString("LOB_CTGRY_NM"));
			results.add(bean);
		}
		return results;
	}

	/**
	 * This method populates data for Single LOB to generate trending portlet on
	 * trending and executive summary template of care opp's The data will be
	 * populated as YTD for Medicare/Medicaid, Rolling 12 months(YOY) for
	 * Commercial/Unicare LOB'S
	 * 
	 * @param resultListpreviousyear
	 * @param resultListcurrentyear
	 * @param max_month
	 * @param lobtype
	 * @param measureid
	 * @param measureName
	 * @return
	 * @throws Exception
	 */
	public List<CareOpportunitiesTrendJson> SingleLOB(List<CareOpportunitiesTrendBean> resultListpreviousyear,
			List<CareOpportunitiesTrendBean> resultListcurrentyear, String max_month, String lobtype, String measureid,
			String measureName) throws Exception {

		List<CareOpportunitiesTrendBean> careOpportunitiesTrendBeanspy = resultListpreviousyear;
		List<CareOpportunitiesTrendBean> careOpportunitiesTrendBeanscy = resultListcurrentyear;
		List<CareOpportunitiesTrendJson> careOpportunitiesTrendJsons = new ArrayList<CareOpportunitiesTrendJson>();
		List<String> allmonths = null;

		allmonths = getAllmonths(max_month, lobtype);

		Map<String, CareOpportunitiesTrendJson> childMap = new HashMap<String, CareOpportunitiesTrendJson>();

		if (careOpportunitiesTrendBeanscy.size() > ZERO) {

			for (CareOpportunitiesTrendBean trendbean : careOpportunitiesTrendBeanscy) {
				if (trendbean.getMonth() != null) {
					CareOpportunitiesTrendJson careOpportunitiesTrendJson = new CareOpportunitiesTrendJson();
					careOpportunitiesTrendJson.setMonth(trendbean.getMonth());
					careOpportunitiesTrendJson.setCurrentYearValue(trendbean.getCloseRatio());
					careOpportunitiesTrendJson.setMeasureName(measureid);
					careOpportunitiesTrendJson.setMeasureId(measureName);
					childMap.put(careOpportunitiesTrendJson.getMonth().substring(
							careOpportunitiesTrendJson.getMonth().length() - TWO), careOpportunitiesTrendJson);
					careOpportunitiesTrendJsons.add(careOpportunitiesTrendJson);
				}
			}
		}

		if (careOpportunitiesTrendBeanspy.size() > ZERO) {
			for (CareOpportunitiesTrendBean trendbean : careOpportunitiesTrendBeanspy) {
				if (trendbean.getMonth() != null
						&& childMap.containsKey(trendbean.getMonth().substring(trendbean.getMonth().length() - TWO))) {
					CareOpportunitiesTrendJson careOpportunitiesTrendJson = childMap
							.get(trendbean.getMonth().substring(trendbean.getMonth().length() - 2));
					careOpportunitiesTrendJson.setPreviousYearValue(trendbean.getCloseRatio());
				} else {
					CareOpportunitiesTrendJson careOpportunitiesTrendJson = new CareOpportunitiesTrendJson();
					careOpportunitiesTrendJson.setPreviousYearValue(trendbean.getCloseRatio());
					careOpportunitiesTrendJson.setMeasureName(measureid);
					careOpportunitiesTrendJson.setMeasureId(measureName);
					childMap.put(trendbean.getMonth().substring(trendbean.getMonth().length() - TWO),
							careOpportunitiesTrendJson);
					careOpportunitiesTrendJsons.add(careOpportunitiesTrendJson);
				}
			}
		}

		if (allmonths.size() > ONE) {
			for (int i = ZERO; i <= allmonths.size() - ONE; i++) {
				if (childMap.containsKey(allmonths.get(i).substring(allmonths.get(i).length() - TWO))) {
					CareOpportunitiesTrendJson careOpportunitiesTrendJson = childMap
							.get(allmonths.get(i).substring(allmonths.get(i).length() - TWO));
					careOpportunitiesTrendJson.setMonth(allmonths.get(i));
					careOpportunitiesTrendJson.setMeasureName(measureid);
					careOpportunitiesTrendJson.setMeasureId(measureName);
				} else {
					CareOpportunitiesTrendJson careOpportunitiesTrendJson = new CareOpportunitiesTrendJson();
					careOpportunitiesTrendJson.setMonth(allmonths.get(i));
					careOpportunitiesTrendJson.setMeasureName(measureid);
					careOpportunitiesTrendJson.setMeasureId(measureName);
					careOpportunitiesTrendJsons.add(careOpportunitiesTrendJson);
				}
			}
		}

		return sortMonth(careOpportunitiesTrendJsons);
	}

	/**
	 * This method is to populate data for Mixed LOB to generate trending portlet on
	 * trending and executive summary template of care opp's The data will be
	 * populated as Rolling 12 months
	 * 
	 * @param resultList
	 * @param lobCtgryNm
	 * @param measureid
	 * @param measureName
	 * @param max_month
	 * @return
	 * @throws Exception
	 */
	public List<CareOpportunitiesTrendJson> MixedLOB(List<CareOpportunitiesTrendBean> resultList, String lobCtgryNm,
			String measureid, String measureName, String max_month) throws Exception {
		
		boolean commercial = false;
		boolean medicare = false;
		boolean medicaid = false;

		List<String> allmonths = getAllmonths(max_month, lobCtgryNm);

		List<CareOpportunitiesTrendBean> careOpportunitiesTrendBeans = resultList;
		List<CareOpportunitiesTrendJson> careOpportunitiesTrendJsons = new ArrayList<CareOpportunitiesTrendJson>();

		Map<String, CareOpportunitiesTrendJson> childMap = new HashMap<String, CareOpportunitiesTrendJson>();

		if (careOpportunitiesTrendBeans.size() > 0) {

			for (CareOpportunitiesTrendBean trendbean : careOpportunitiesTrendBeans) {
				
				if(!childMap.containsKey(trendbean.getMonth())){
					commercial = false; medicare=false; medicaid=false;
				}
				
				if (trendbean.getMonth() != null && childMap.containsKey(trendbean.getMonth())) {
					CareOpportunitiesTrendJson careOpportunitiesTrendJson = childMap.get(trendbean.getMonth());

					Long numerator_count = ZEROL;
					numerator_count = careOpportunitiesTrendJson.getNumerator() + trendbean.getNumerator();

					careOpportunitiesTrendJson.setNumerator(numerator_count);

					Long denominator_count = ZEROL;
					denominator_count = careOpportunitiesTrendJson.getDenominator() + trendbean.getDenominator();
					careOpportunitiesTrendJson.setDenominator(denominator_count);

					if ((trendbean.getLobCategoryNm().contains(COMMERCIAL) && commercial == false)
							|| (trendbean.getLobCategoryNm().contains(UNICARE) && commercial == false)) {
						careOpportunitiesTrendJson.setCommercialValue(trendbean.getCloseRatio());
					} else if (trendbean.getLobCategoryNm().contains(MEDICARE) && medicare == false) {
						careOpportunitiesTrendJson.setMedicareValue(trendbean.getCloseRatio());
					} else if (trendbean.getLobCategoryNm().contains(MEDICAID) && medicaid == false) {
						careOpportunitiesTrendJson.setMedicaidValue(trendbean.getCloseRatio());
					}
				} else {
					CareOpportunitiesTrendJson careOpportunitiesTrendJson = new CareOpportunitiesTrendJson();
					careOpportunitiesTrendJson.setMonth(trendbean.getMonth());

					if (trendbean.getLobCategoryNm().contains(COMMERCIAL)
							|| trendbean.getLobCategoryNm().contains(UNICARE)) {
						commercial = true;
						careOpportunitiesTrendJson.setCommercialValue(trendbean.getCloseRatio());
					} else if (trendbean.getLobCategoryNm().contains(MEDICARE)) {
						medicare = true;
						careOpportunitiesTrendJson.setMedicareValue(trendbean.getCloseRatio());
					} else if (trendbean.getLobCategoryNm().contains(MEDICAID)) {
						medicaid = true;
						careOpportunitiesTrendJson.setMedicaidValue(trendbean.getCloseRatio());
					}

					careOpportunitiesTrendJson.setNumerator(trendbean.getNumerator());
					careOpportunitiesTrendJson.setDenominator(trendbean.getDenominator());

					careOpportunitiesTrendJson.setMeasureName(measureName);
					careOpportunitiesTrendJson.setMeasureId(measureid);

					childMap.put(careOpportunitiesTrendJson.getMonth(), careOpportunitiesTrendJson);
				}
			}
		}

		NumberFormat numberformat = NumberFormat.getInstance();
		numberformat.setMaximumFractionDigits(TWO);
		numberformat.setMinimumFractionDigits(TWO);
		for (Entry<String, CareOpportunitiesTrendJson> loop : childMap.entrySet()) {
			CareOpportunitiesTrendJson careOpportunitiesTrendJson = loop.getValue();
			if (careOpportunitiesTrendJson.getDenominator() != ZERO
					&& careOpportunitiesTrendJson.getNumerator() != ZERO) {
				Float alllobsCloseRatio = ((careOpportunitiesTrendJson.getNumerator().floatValue()
						/ careOpportunitiesTrendJson.getDenominator().floatValue()) * HUNDRED);
				careOpportunitiesTrendJson.setAllLobsValue(numberformat.format(alllobsCloseRatio));
			}

			careOpportunitiesTrendJsons.add(careOpportunitiesTrendJson);
		}

		if (allmonths.size() > ONE) {
			for (int i = ZERO; i <= allmonths.size() - ONE; i++) {
				if (!childMap.containsKey(allmonths.get(i))) {
					CareOpportunitiesTrendJson careOpportunitiesTrendJson = new CareOpportunitiesTrendJson();
					careOpportunitiesTrendJson.setMonth(allmonths.get(i));
					careOpportunitiesTrendJson.setMeasureName(measureName);
					careOpportunitiesTrendJson.setMeasureId(measureid);
					careOpportunitiesTrendJsons.add(careOpportunitiesTrendJson);
				}
			}
		}

		return sortMonth(careOpportunitiesTrendJsons);

	}

	/**
	 * This method is to sort the records based on Month ID
	 * 
	 * @param careOpportunitiesTrendJsons
	 * @return
	 * @throws ParseException
	 */
	private List<CareOpportunitiesTrendJson> sortMonth(List<CareOpportunitiesTrendJson> careOpportunitiesTrendJsons)
			throws ParseException {

		TrendMonthComparator tc = new TrendMonthComparator();
		Collections.sort(careOpportunitiesTrendJsons, tc);

		if (careOpportunitiesTrendJsons.size() > ZERO) {
			for (int i = ZERO; i <= careOpportunitiesTrendJsons.size() - ONE; i++) {
				careOpportunitiesTrendJsons.get(i).setMonth(
						StringUtil.fmtreportingperiod(careOpportunitiesTrendJsons.get(i).getMonth(), "month"));
			}
		}
		return careOpportunitiesTrendJsons;
	}

	/**
	 * This method is to fetch the max month_id from CARE_OPP_TRND_SMRY_FACT table
	 * 
	 * @return MNTH_ID (i.e., YYYYMM)
	 * @throws Exception
	 */
	public String getmaxdate() throws Exception {

		String sql = "select max(MNTH_ID) as max_month from CARE_OPP_TRND_SMRY_FACT with ur ";
		String date = "";

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, sql);
			executeQuery(logger, sql);
			while (rs.next()) {
				if (rs.getString("max_month") != null) {
					date = StringUtil.getValueOrDashes(rs.getString("max_month"));
				}
			}
		} catch (Exception e) {
			throw new Exception(UNABLE_TO_GET_MAX_MONTH_FOR_CARE_OPPORTUNITY_TREND, e);
		} finally {
			close();
		}
		return date;
	}

	/**
	 * This method is returns all previous 12months from the provided month
	 * 
	 * @param max_month (i.e. YYYYMM)
	 * @param lobtype
	 * @return List all months
	 * @throws Exception
	 */
	private List<String> getAllmonths(String max_month, String lobtype) throws Exception {

		List<String> allmonths = null;

		if ((lobtype.contains(COMMERCIAL) || lobtype.contains(UNICARE))) {
			String max_date = max_month.substring(ZERO, FOUR) + "/" + max_month.substring(max_month.length() - TWO)
					+ ZERO_ONE;
			Date date = new Date();
			date = new SimpleDateFormat("yyyy/MM/dd").parse(max_date);
			allmonths = StringUtil.retmnths(date);
		} else {
			String max_date = max_month.substring(ZERO, FOUR) + ONE_TWO + ZERO_ONE;
			Date date = new Date();
			date = new SimpleDateFormat("yyyy/MM/dd").parse(max_date);
			allmonths = StringUtil.retmnths(date);
		}
		return allmonths;
	}

	/**
	 * This method is to populate metadata based on LOB type which is used to show
	 * Legends on trending portlet
	 * 
	 * @param lobvalue
	 * @param lobCtgryNm
	 * @return
	 * @throws Exception
	 */
	public TrendMetadata metadata(int lobvalue, GetCareOpportunityCurrentTrendRequest request) throws Exception {

		TrendMetadata metadata = new TrendMetadata();
		List<String> trendyfields = new ArrayList<String>();
		List<String> trendylabels = new ArrayList<String>();

		if (lobvalue == ONE) {
			trendyfields.add(CURRENT_YEAR_VALUE);
			trendyfields.add(PREVIOUS_YEAR_VALUE);
			metadata.setyFields(trendyfields);
			trendylabels.add(CURRENT_YEAR);
			trendylabels.add(PREVIOUS_YEAR);
			metadata.setyLabels(trendylabels);

		} else if (lobvalue >= TWO) {
			if ((request.getLobCtgryNm().contains(COMMERCIAL) || request.getLobCtgryNm().contains(UNICARE))
					&& request.getLobCtgryNm().contains(MEDICARE) && request.getLobCtgryNm().contains(MEDICAID)) {
				trendyfields.add(ALL_LOBS_VALUE);
				trendyfields.add(COMMERCIAL_VALUE);
				trendyfields.add(MEDICARE_VALUE);
				trendyfields.add(MEDICAID_VALUE);
				metadata.setyFields(trendyfields);
				trendylabels.add(ALL_LOBS);
				trendylabels.add(COMMERCIAL);
				trendylabels.add(MEDICARE);
				trendylabels.add(MEDICAID);
				metadata.setyLabels(trendylabels);
			} else if ((request.getLobCtgryNm().contains(COMMERCIAL) || request.getLobCtgryNm().contains(UNICARE))
					&& request.getLobCtgryNm().contains(MEDICARE)) {
				trendyfields.add(ALL_LOBS_VALUE);
				trendyfields.add(COMMERCIAL_VALUE);
				trendyfields.add(MEDICARE_VALUE);
				metadata.setyFields(trendyfields);
				trendylabels.add(ALL_LOBS);
				trendylabels.add(COMMERCIAL);
				trendylabels.add(MEDICARE);
				metadata.setyLabels(trendylabels);
			} else if ((request.getLobCtgryNm().contains(COMMERCIAL) || request.getLobCtgryNm().contains(UNICARE))
					&& request.getLobCtgryNm().contains(MEDICAID)) {
				trendyfields.add(ALL_LOBS_VALUE);
				trendyfields.add(COMMERCIAL_VALUE);
				trendyfields.add(MEDICAID_VALUE);
				metadata.setyFields(trendyfields);
				trendylabels.add(ALL_LOBS);
				trendylabels.add(COMMERCIAL);
				trendylabels.add(MEDICAID);
				metadata.setyLabels(trendylabels);
			} else if (request.getLobCtgryNm().contains(MEDICARE) && request.getLobCtgryNm().contains(MEDICAID)) {
				trendyfields.add(ALL_LOBS_VALUE);
				trendyfields.add(MEDICARE_VALUE);
				trendyfields.add(MEDICAID_VALUE);
				metadata.setyFields(trendyfields);
				trendylabels.add(ALL_LOBS);
				trendylabels.add(MEDICARE);
				trendylabels.add(MEDICAID);
				metadata.setyLabels(trendylabels);
			}

		}
		return metadata;
	}

	public List<CareOpportunitiesRateJson> RateList(List<CareOpportunitiesTrendJson> trendList, int lobvalue) {
		boolean month1=false;boolean month2=false;boolean month3=false;boolean month4=false;boolean month5=false;boolean month6=false;
		boolean month7=false;boolean month8=false;boolean month9=false;boolean month10=false;boolean month11=false;boolean month12=false;
		
		Map<String, CareOpportunitiesRateJson> RateMap = new HashMap<String, CareOpportunitiesRateJson>();
		
			if (trendList.size() > 0) {
				for (CareOpportunitiesTrendJson trendbean : trendList) {	
					if (trendbean.getMonth() != null && RateMap.containsKey(trendbean.getMeasureName())) {
						if(month2==true) {
						
						CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
						previousyear.setMonth2(trendbean.getPreviousYearValue());
						previousyear.setMeasureName(trendbean.getMeasureName());
						previousyear.setYear(trendbean.getMonth());month3=true;
						}
						if(month3==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth3(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());month4=true;
						}
						if(month4==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth4(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());month5=true;
						}
						if(month5==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth2(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());month6=true;
					}
						if(month6==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth2(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());month7=true;
						
							
							}
						if(month7==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth2(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());month8=false;
						
					}
						if(month8==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth2(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());month9=false;
						
							}
						if(month9==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth2(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());month10=false;
						
			}
						if(month10==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth2(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());month11=false;
						
						}
						if(month11==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth2(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());month12=false;
						
					}
						if(month12==true) {
							
							CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
							previousyear.setMonth2(trendbean.getPreviousYearValue());
							previousyear.setMeasureName(trendbean.getMeasureName());
							previousyear.setYear(trendbean.getMonth());
						
						
						
						
					} else {
						
						CareOpportunitiesRateJson previousyear = new CareOpportunitiesRateJson();
						previousyear.setMonth1(trendbean.getPreviousYearValue());
						previousyear.setMeasureName(trendbean.getMeasureName());
						previousyear.setYear(trendbean.getMonth());						
						
						month2=true;
					}
				}
			}
			return null;
				
		
		
	}

	}	



	

	
	

