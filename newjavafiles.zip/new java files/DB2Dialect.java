package com.legato.persistence.snowflake.dialect;

import org.hibernate.dialect.Dialect;

public class DB2Dialect extends Dialect{

}
