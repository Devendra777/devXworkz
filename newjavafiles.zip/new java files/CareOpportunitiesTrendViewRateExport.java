package com.wellpoint.pc2dash.export.population;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import com.wellpoint.pc2dash.action.careOpportunities.GetCareopportunityTrendRateRequest;

import com.wellpoint.pc2dash.dto.careOpportunities.CareOppTrendRateBeanJson;
import com.wellpoint.pc2dash.export.AbstractExport;
import com.wellpoint.pc2dash.export.JasperPrintObjectBuilder;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.globalFilters.GlobalFilterDataFetchService;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.JSONUtils;
import com.wellpoint.pc2dash.util.StringUtil;

import net.sf.dynamicreports.jasper.builder.JasperReportBuilder;
import net.sf.jasperreports.engine.JasperPrint;

public class CareOpportunitiesTrendViewRateExport  extends AbstractExport {


	private static final Pc2DashLogger LOG = Pc2DashLogger.getLogger(CareOpportunitiesTrendViewRateExport.class);
	private static final String EXPORT_TITLE = "Care_Opportunities_Rate";
		
	private GetCareopportunityTrendRateRequest request;
	
	public CareOpportunitiesTrendViewRateExport(GetCareopportunityTrendRateRequest request) {
		this.request = request;

		try {
			init(request);
		}
		catch (Exception e) {
			LOG.error("Unable to initialize export (" + EXPORT_TITLE + ")", e);
		}
	}

	@Override
	public String getTitle() {
		
		return EXPORT_TITLE;
	}

	@Override
	public void process() throws Exception {

		JasperReportBuilder jasperReportBuilderObj = new JasperReportBuilder();

		List<CareOppTrendRateBeanJson> resultList = getExportList(request.getCareOppsTrendRatesData());


		//		Global filter information in export.
		GlobalFilterDataFetchService globalFilterDataFetchService = new GlobalFilterDataFetchService();
		Map<String, Map<String, String>> globalFilterMaps = globalFilterDataFetchService.getExportDataForGlobalFilter(
			request.getProvGrpIdsWithoutClinicalCheck(),
			request.getProgramIds(),
			request.getLobIds()
			);

		CommonQueries cq = new CommonQueries();
		request.setReportDate(cq.getReportDateForExport());

		List<String> statusList = getStatusList(request.getCareOppsStatusCds());

		if (resultList.size() > 0) {
			jasperReportBuilderObj = CareOpportunitiesTrendViewRateReporter.buildReportBean(
				resultList,
				request,
				request.getCareOppsFilter(),
				cq.getRiskDriverMap(request.getRiskDriverKeys()),
				cq.getChronicCareGapMap(request),
				cq.getReferralOutcomeStatusMap(request, false),
				globalFilterMaps,
				statusList);
		}

		JasperPrint printer = JasperPrintObjectBuilder.getPrintObject(jasperReportBuilderObj);
		writeOutput(printer, request.getDest());
	}

	private List<CareOppTrendRateBeanJson> getExportList(String careOppsTrendRatesData) {
		List<CareOppTrendRateBeanJson> rateList = new ArrayList<CareOppTrendRateBeanJson>();
		JsonArray ratesArray = new JsonArray();
		String measureName = "";
		String rowClass = "";
		String currentYearValue = "";
		String previousYearValue = "";
		String month = "";
	    String medicareValue = "";
	    String medicaidValue ="";
	    String allLobsValue = "";
	    String commercialValue = "";
		if (!StringUtils.isEmpty(careOppsTrendRatesData)) {
			ratesArray = JSONUtils.buildJsonArray(careOppsTrendRatesData);

			for (int i = 0; i < ratesArray.size(); i++) {
				JsonObject rateObj = (JsonObject) ratesArray.get(i);
							if(null != rateObj.getAsJsonPrimitive("rowClass") && !rateObj.getAsJsonPrimitive("rowClass").getAsString().equalsIgnoreCase("title")){
				if (!isNullOrEmpty(rateObj, "measureName"))
					measureName = rateObj.getAsJsonPrimitive("measureName").getAsString();
				if (!isNullOrEmpty(rateObj, "currentYearValue" ))
					previousYearValue = rateObj.getAsJsonPrimitive("currentYearValue").getAsString();
				if (!isNullOrEmpty(rateObj, "previousYearValue"))
					previousYearValue = rateObj.getAsJsonPrimitive("previousYearValue").getAsString();
				if (!isNullOrEmpty(rateObj, "medicareValue"))
					previousYearValue = rateObj.getAsJsonPrimitive("medicareValue").getAsString();
				if (!isNullOrEmpty(rateObj, "allLobsValue"))
					previousYearValue = rateObj.getAsJsonPrimitive("allLobsValue").getAsString();
				if (!isNullOrEmpty(rateObj, "commercialValue"))
					previousYearValue = rateObj.getAsJsonPrimitive("commercialValue").getAsString();
			
				if (!isNullOrEmpty(rateObj, "medicaidValue"))
					previousYearValue = rateObj.getAsJsonPrimitive("medicaidValue").getAsString();
			
			
				CareOppTrendRateBeanJson bean = new CareOppTrendRateBeanJson(measureName,
						currentYearValue,
						medicareValue,commercialValue, previousYearValue,
					month, allLobsValue, medicaidValue, month
					
					);

				rateList.add(bean);
				//				}
			}
		}
		//return rateList;
	}
		return rateList;}

	private boolean isNullOrEmpty(JsonObject rateObj, String string) {

		return null != rateObj.getAsJsonPrimitive(string) ? rateObj.getAsJsonPrimitive(string).getAsString().isEmpty() ? true : false : true;
	}

	private List<String> getStatusList(String statusString) {

		List<String> statusList = new ArrayList<String>();

		if (null != statusString && !"false".equalsIgnoreCase(statusString) && !"".equalsIgnoreCase(statusString.trim())) {
			statusList = Arrays.asList(statusString.split(","));
		}

		return statusList;
	}
	

	
	}


