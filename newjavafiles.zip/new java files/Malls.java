class  Malls
{
static  int noOfShopes =12;
public static  String[]  shopNames={"AllenSolly","1","Forever 21",
"PeterEngland"};

public static void main(String a[])
{
System.out.println(shopNames.length);

System.out.println(shopNames[3]);
}
}