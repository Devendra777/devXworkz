package com.hiring.trackr.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hiring.trackr.dto.CreatePositionDTO;
import com.hiring.trackr.service.CreatePositionService;

@RestController
public class CreatePositionController {

	@Autowired
	private CreatePositionService createPositionService;

	// creating post mapping that post the position  detail in the h2-database
	@PostMapping("/createPosition")
	private void createPosition(@RequestBody CreatePositionDTO createPositionDTO) {
		
		createPositionService.savePosition(createPositionDTO);
	}
	
	@GetMapping("/getPositions/{id}")  
	private CreatePositionDTO getPosition(@PathVariable("id") int id) {
		
		return createPositionService.getPositionById(id);
	}
	
	
}
