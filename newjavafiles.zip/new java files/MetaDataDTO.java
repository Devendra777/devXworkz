package com.legato.persistence.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "meta_data_info_dtl")
public class MetaDataDTO {

	public MetaDataDTO() {
		// TODO Auto-generated constructor stub
	}

	@Id
	@Column(name = "tbl_nm")
	private String tblName;
	@Id
	@Column(name = "col_nm")
	private String colName;
	@Column(name = "col_ordr")
	private String colOrder;
	@Column(name = "data_type")
	private String dataType;
	@Column(name = "col_not_null")
	private String colNotNull;
	@Column(name = "src_tbl_nm")
	private String srcTblName;
	@Column(name = "src_col_nm")
	private String srcColName;
	@Column(name = "transfrmtn_logic")
	private String transfrmtnLogic;
	
	public String getTblName() {
		return tblName;
	}
	public void setTblName(String tblName) {
		this.tblName = tblName;
	}
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}
	public String getColOrder() {
		return colOrder;
	}
	public void setColOrder(String colOrder) {
		this.colOrder = colOrder;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getColNotNull() {
		return colNotNull;
	}
	public void setColNotNull(String colNotNull) {
		this.colNotNull = colNotNull;
	}
	public String getSrcTblName() {
		return srcTblName;
	}
	public void setSrcTblName(String srcTblName) {
		this.srcTblName = srcTblName;
	}
	public String getSrcColName() {
		return srcColName;
	}
	public void setSrcColName(String srcColName) {
		this.srcColName = srcColName;
	}
	public String getTransfrmtnLogic() {
		return transfrmtnLogic;
	}
	public void setTransfrmtnLogic(String transfrmtnLogic) {
		this.transfrmtnLogic = transfrmtnLogic;
	}
	
	

}
