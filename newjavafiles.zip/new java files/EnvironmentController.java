package com.legato.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.common.web.view.ResponseView;
import com.legato.common.constants.Constants;
import com.legato.persistence.dao.AbstractDAO;
import com.legato.persistence.dto.EnvDTO;
import com.legato.persistence.dto.FilterConditionsDTO;
import com.legato.persistence.dto.JoinConditionsDetailsDTO;
import com.legato.persistence.dto.MetaDataDTO;
import com.legato.persistence.dto.SubQueryDetailsDTO;
import com.legato.web.service.EnvironementService;

@CrossOrigin
@RestController
@RequestMapping("/")
public class EnvironmentController extends AbstractDAO {

	@Autowired
	EnvironementService environementService;

	

	public EnvironmentController() {

	}

	@RequestMapping(method = RequestMethod.POST, value = "/createEnv")
	public ResponseView<EnvDTO> createEnv(@RequestBody(required = false) EnvDTO dto, HttpServletRequest httpRequest) {

		ResponseView<EnvDTO> responseView = new ResponseView<>();
		try {
			environementService.validateAndSaveEnv(dto);

			responseView.setData(dto);
			responseView.setTotal(1);
			responseView.setStatus(Constants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(Constants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
		}
		return responseView;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/filterConditions")
	public ResponseView<FilterConditionsDTO> createFilterConditions(
			@RequestBody(required = false) FilterConditionsDTO dto, HttpServletRequest httpRequest) {

		ResponseView<FilterConditionsDTO> responseView = new ResponseView<>();
		try {
			environementService.validateAndSaveFilterConditions(dto);

			responseView.setData(dto);
			responseView.setTotal(1);
			responseView.setStatus(Constants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(Constants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
		}
		return responseView;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/joiningConditions")
	public ResponseView<JoinConditionsDetailsDTO> createJoinConditions(
			@RequestBody(required = false) JoinConditionsDetailsDTO dto, HttpServletRequest httpRequest) {

		ResponseView<JoinConditionsDetailsDTO> responseView = new ResponseView<>();
		try {
			environementService.validateAndSaveJoinConditions(dto);

			responseView.setData(dto);
			responseView.setTotal(1);
			responseView.setStatus(Constants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(Constants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
		}
		return responseView;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/metaData")
	public ResponseView<MetaDataDTO> createMetaData(@RequestBody(required = false) MetaDataDTO dto,
			HttpServletRequest httpRequest) {
		ResponseView<MetaDataDTO> responseView = new ResponseView<>();
		try {
			environementService.validateAndSaveMetaDataDetails(dto);

			responseView.setData(dto);
			responseView.setTotal(1);
			responseView.setStatus(Constants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(Constants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
		}
		return responseView;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/subQuery")
	public ResponseView<SubQueryDetailsDTO> createsubQueryDetails(@RequestBody(required = false) SubQueryDetailsDTO dto,
			HttpServletRequest httpRequest) {

		ResponseView<SubQueryDetailsDTO> responseView = new ResponseView<>();
		try {
			environementService.validateAndSaveSubQueryDetails(dto);

			responseView.setData(dto);
			responseView.setTotal(1);
			responseView.setStatus(Constants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(Constants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
		}
		return responseView;
	}

}
