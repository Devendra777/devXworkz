import java.util.Scanner;

class  CalculatorTester{

public static void main(String a[]){

Scanner sc = new Scanner(System.in);
System.out.println("Enter the name");
String name  =sc.next();
System.out.println("Enter the model");
String model =sc.next();
 ScientificCalculator scientificCalculator =new ScientificCalculator(); 
  scientificCalculator.name = name;
scientificCalculator.model =  model;
scientificCalculator.add(1,8);
scientificCalculator.sub(1,8);
scientificCalculator.sin(90);
scientificCalculator.cos(90);

}

}