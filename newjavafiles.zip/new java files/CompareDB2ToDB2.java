package com.anthem.db2todb2.utility; 

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class CompareDB2ToDB2 {
	//private static Properties prop = null;
	public static String dbServerName;
	public static int dbPortNo;
	public static String dbName;
	public static String dbUserName;
	public static String dbPassword;
	public static String tableName;
	public static String comparisonOutput;
	public static String dataQualityResult;
	public static String inputQueryFileName;
	public int recordsMismatchRowCount=0;
	public static boolean passFlag = false;
	public static boolean scenarioPassFlag = true;
	public static List<String> querylist = new ArrayList<String>();
	public static boolean querytobeselected = false;
	public static boolean parameterFoundInList = false;
	List <String> dateColumns = new ArrayList<String>();
	public static boolean flag=false;
	public static String tablepath;	
	public static Map<String,String> teradataDBDataTypes=new HashMap<String,String>();
	FSDataOutputStream dataQualityReport;
	FSDataOutputStream comparison_output;
	public static int hiveDBNullCount;
	public static boolean sqlExceptionFlag = false;
	public static boolean flag_centralized_server = false;
	public static boolean execute_in_unix = true;
	private static int execution_id;
	private static int result_id;
	public static String directory_path;//"/tmp/bdv_pims/PIMS_FT/";
	public static volatile boolean finished = false;	
	String[] varName ;
	Statement stmt=null;
	public static void main(String[] args) throws SQLException, InterruptedException {
		CompareDB2ToDB2 obj=new CompareDB2ToDB2();
		try {
			EncryptionService encryptionService = new EncryptionService();
			if(args[0]!=null){
			flag_centralized_server = Boolean.valueOf(args[0]) ;
			}
			else{
			flag_centralized_server = false;
			}
			if(flag_centralized_server == false){
			File src=new File("db2_to_db2_input_parameters.xlsx");
			  if(src.exists()) {	
				  System.out.println("Regression suite is found, so only scenarios marked for regression will be considered");
				  FileInputStream fis=new FileInputStream(src);		   
				    XSSFWorkbook wb=new XSSFWorkbook(fis);		 
				      XSSFSheet sh1= wb.getSheetAt(0);				
				      int i=1;
				      while (i <= sh1.getLastRowNum()){	
				    	  if(sh1.getRow(i).getCell(2).getStringCellValue().equalsIgnoreCase("Y")){
				    		System.out.println("Selected scenario for Execution is: "+sh1.getRow(i).getCell(1).getStringCellValue()+"\n");
				    		dbServerName=sh1.getRow(i).getCell(3).getStringCellValue();
				    		dbPortNo=(int) sh1.getRow(i).getCell(4).getNumericCellValue();
				    		dbName=sh1.getRow(i).getCell(5).getStringCellValue();
				    		dbUserName=sh1.getRow(i).getCell(6).getStringCellValue();
				    		dbPassword=encryptionService.decrypt(sh1.getRow(i).getCell(7).getStringCellValue());
							inputQueryFileName =sh1.getRow(i).getCell(8).getStringCellValue();
							directory_path = "";
							//tableName = sh1.getRow(i).getCell(8).getStringCellValue();
							//activeHadoopClusterNode=sh1.getRow(i).getCell(6).getStringCellValue();
							//comparisonOutput=sh1.getRow(i).getCell(9).getStringCellValue();
							//dataQualityResult=sh1.getRow(i).getCell(10).getStringCellValue();
							//System.out.println("dbUserName: "+dbUserName);
							//System.out.println("inputQueryFileName: "+inputQueryFileName);
							//System.out.println("tableName: "+tableName);
							//System.out.println("activeHadoopClusterNode: "+activeHadoopClusterNode);
							//System.out.println("comparisonOutput: "+comparisonOutput);
							//System.out.println("dataQualityResult: "+dataQualityResult);
						  obj.compareContent();
				      	}
				    	  else
				    		  System.out.println(sh1.getRow(i).getCell(1).getStringCellValue() + " scenario is not selected for Execution\n");
					  i++;
					  }
			}
			}
			else{
				Statement stmt1 = null;
				Connection con1  = null;
				execution_id = Integer.valueOf(args[1]);
				result_id = Integer.valueOf(args[2]);
				directory_path = args[3];
				int connection_id=0;
				 File files = null;
				 if(flag_centralized_server == true){
					if(execute_in_unix){
					//For Unix
					 files = new File(directory_path+"Results_"+execution_id+"/");
					}
					else{
					 //For Windows
					files = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/");
					}
				    if (!files.exists()) {
				        if (files.mkdirs()) {
				        	System.out.println("\n");
				            //System.out.println("Directory is created");
				        } else {
				            //System.out.println("Directory exists");
				        }
				    }
				 }
				//String  url = "jdbc:jtds:sqlserver://"+source_db_server_name_qb+"/"+source_db_name_qb+";instance=SQLEXPRESS;useNTLMv2=true;domain=US;user="+dbUserName+";password="+dbPassword+";ssl=require";
				String  url = "jdbc:jtds:sqlserver://VA33DWVSQL003:10001/BD_AUTOMATION;useNTLMv2=true;domain=US;user=af43300;password=qwerty@90;ssl=require";
				//String  url = "jdbc:sqlserver://"+source_db_server_name_qb +";databasename="+source_db_name_qb +";user=US\\"+dbUserName+";password="+dbPassword;
				try {
					System.out.println("\n MSSql DB Connectivity: \n");
					System.out.println(" Looking for the MSSql JDBC driver... ");
					// Loading the Teradata JDBC driver
					//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
					Class.forName("net.sourceforge.jtds.jdbc.Driver");
					//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					System.out.println(" JDBC driver loaded. \n");

					// Attempting to connect to Teradata
					System.out.println(" Attempting to connect to MSSql via" +
							" the JDBC driver...");

					// Creating a connection object
					// Connection con = DriverManager.getConnection(url, sUser, sPassword);
					//Connection con = DriverManager.getConnection("jdbc:odbc:MSSQLDS1");
					//Connection con = DriverManager.getConnection(url,dbUserName,dbPassword);
					con1 = DriverManager.getConnection(url); 
					System.out.println(" User is connected.");
					System.out.println(" Connection to MSSql established. \n");
					stmt1 = con1.createStatement();
					ResultSet rset1 = stmt1.executeQuery("SELECT connection_id FROM [BD_AUTOMATION].[dbo].[execution_details] WHERE id = "+ execution_id);
					
					 while (rset1.next()) {			    	  
						 connection_id=rset1.getInt(1);
						 System.out.println("Selected connection_id: "+connection_id);
				      }
					 rset1.close();
				}
				catch(Exception e){
					e.printStackTrace();
				}
				try{
					 ResultSet rset2 = stmt1.executeQuery("SELECT server_host,database_name,username,password FROM [BD_AUTOMATION].[dbo].[database_connection] WHERE id = "+ connection_id);
					 while (rset2.next()) {			    	  
						 dbServerName=rset2.getString(1);
						 dbName=rset2.getString(2);
						 dbUserName=rset2.getString(3);
						 //dbPassword=rset2.getString(4);
						 dbPassword=encryptionService.decrypt(rset2.getString(4));
						 //System.out.println("Selected dbServerName: "+dbServerName);
						 //System.out.println("Selected dbName: "+dbName);
						 //System.out.println("Selected dbUserName: "+dbUserName);
						 //System.out.println("Selected dbPassword: "+dbPassword);
				      }
					 rset2.close();
				}catch(Exception e){
					e.printStackTrace();
				}
				try{					
					 ResultSet rset3 = stmt1.executeQuery("SELECT input_file_path FROM [BD_AUTOMATION].[dbo].[scenario_details] WHERE execution_id = "+ execution_id);
						
					 while (rset3.next()) {			    	  
						 inputQueryFileName=rset3.getString(1);
						 System.out.println("Selected inputQueryFileName: "+inputQueryFileName);
						 obj.compareContent();
				      }
					 rset3.close();
				}
				
				catch(Exception e){
					e.printStackTrace();
				}
				try{
					if(execute_in_unix){
					//FOr Unix
		             stmt1.executeUpdate("Update [BD_AUTOMATION].[dbo].[result_history] SET execution_status = 'Completed', result_details_path = '/tmp/bdv_pims/PIMS_FT/Results_"+execution_id+"/' WHERE id = "+ result_id);
					}
					else{
		             //For Windows
					stmt1.executeUpdate("Update [BD_AUTOMATION].[dbo].[result_history] SET execution_status = 'Completed', result_details_path = 'C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"\\' WHERE id = "+ result_id);
					}	
				}
				
				catch(Exception e){
					e.printStackTrace();
				}
				finally
				{
					// Close the statement
					
					stmt1.close();
					
					//con3.close();
					con1.close();
					//System.out.println("\n Statement object closed. \n");
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void executeQuery(String inputQueryFileName) throws IOException{
		

		/*		File src=new File(prop.getProperty("Input_Path")+utility_name+"\\\\Generic Query Input\\\\"+"Regression_Scenarios.xlsx");*/
				File src=new File("Regression_Scenarios.xlsx");
				  if(src.exists()) {
					  System.out.println("Execution suite is found, so only queries marked for execution will be considered");
					  querytobeselected=true;
					  FileInputStream fis=new FileInputStream(src);		   
					    XSSFWorkbook wb=new XSSFWorkbook(fis);		 
					      XSSFSheet sh1= wb.getSheetAt(0);
					
					   int i=0;
					 while (i <= sh1.getLastRowNum()){					 
						  if (sh1.getRow(i).getCell(1).getStringCellValue().equalsIgnoreCase(inputQueryFileName) ) {
							  if (sh1.getRow(i).getCell(3).getStringCellValue().equalsIgnoreCase("Y") ) {
								  querylist.add(sh1.getRow(i).getCell(2).getStringCellValue());
							  }
						  } 			 
						 i++;
				        }		 
					  //System.out.println("querylist: "+ querylist);
				  }
				  else{
					  querytobeselected=false;
				  }

			}
	
	private void compareContent() throws ClassNotFoundException, IOException, SQLException, InterruptedException{
		//System.out.println("Extraction Started: "+Calendar.getInstance());
		final ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<String>(10000);
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				recordsMismatchRowCount=0;
				scenarioPassFlag = true;
				//PrintStream out = new PrintStream(new FileOutputStream(directory_path+"ConsoleLog.txt", true));
			    //System.setOut(out);
				File files = null;
				if(execute_in_unix){
				//For Unix
				files = new File(directory_path+inputQueryFileName+"_temp/");
				}
				else{
				 //For Windows
				 files = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/");
				}
				    if (!files.exists()) {
				        if (files.mkdirs()) {
				        	System.out.println("\n");
				            //System.out.println("Directory is created");
				        } else {
				            //System.out.println("Directory exists");
				        }
				    }
				    File src=null;
				    if(execute_in_unix){
				    //For Unix
		        	src=new File(directory_path+inputQueryFileName+".txt");
				    }
				    else{
		        	 //For Windows
		        	 src=new File("C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+".txt");
				    }
					  if(src.exists()) {
						  BufferedReader inputStream =null;
						  if(execute_in_unix){
						       //For Unix
							  	inputStream = new BufferedReader(new FileReader(directory_path+inputQueryFileName+".txt"));
						       }
						       else{
						    	  inputStream = new BufferedReader(new FileReader(("C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+".txt")));
						       }
						try
						{
							String count;
					        StringBuffer str = new StringBuffer ();
					       while ((count=inputStream.readLine()) != null) {
					    	   //StringBuffer str = new StringBuffer (count);
					    	     str.append(count);
					    	     //str.append('\n');
					       }
					       
					       //System.out.println("Stringbuffer value: "+ str);
					       String summaryFile = null;
					       String summaryFile_common_result = null;
					       if(execute_in_unix){
					       //For Unix
					       summaryFile = directory_path+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
					       if(flag_centralized_server == true)
					       summaryFile_common_result = directory_path+"Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
					       }
					       else{
					       //For Windows
					       summaryFile = "C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
					       summaryFile_common_result = "C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
					       }
					    	   FileWriter fileWriter1 = new FileWriter(summaryFile);	        	 
				        	 fileWriter1.write("");
				        	 fileWriter1.close();
				        	 if(flag_centralized_server == true){
				        	 FileWriter fileWriter11 = new FileWriter(summaryFile_common_result);	        	 
				        	 fileWriter11.write("");
				        	 fileWriter11.close();
				        	 }
					       
					       /*************Splitting the Input file queries based on scenarios**************/
					       String[] scenario = str.toString().split("@");
					       System.out.println("No of Scenarios: "+ scenario.length);
					       for(int index =0;index<scenario.length;index++)
				        	 {
					    	  scenarioPassFlag = true;
					       
					       /*************Splitting the input query and output filename combination 
					        from single input file**************/
					    	  String[] var = scenario[index].toString().split(";");
					        	 System.out.println("No. of Queries present in the file: "+ var.length);
					        	 final Thread[] readerThread = new Thread[var.length];
					        	 final Thread[] writeWorker = new Thread[var.length];
					        	 			        	 
					        	 FileWriter fileWriter5 = new FileWriter(summaryFile,true);
					        	  BufferedWriter writer = new BufferedWriter(fileWriter5);
					        	  	writer.write(String.format("%-30s %-25s \r\n", "Test Case", "Status"));
					                writer.newLine();
					        	 writer.close();
					        	 if(flag_centralized_server == true){
					        	 FileWriter fileWriter51 = new FileWriter(summaryFile_common_result,true);
					        	  BufferedWriter writer51 = new BufferedWriter(fileWriter51);
					        	  writer51.write(String.format("%-30s %-25s \r\n", "Test Case", "Status"));
					        	  writer51.newLine();
					        	  writer51.close();
					        	 }
					        	//System.out.println("\n Teradata DB Connectivity: \n");
									//System.out.println(" Looking for the Teradata JDBC driver... ");
									// Loading the Teradata JDBC driver
									//Class.forName("com.teradata.jdbc.TeraDriver");
									Class.forName("com.ibm.db2.jcc.DB2Driver");
									//System.out.println(" JDBC driver loaded. \n");

									// Attempting to connect to Teradata
									//System.out.println(" Attempting to connect to Teradata via" +
											//" the JDBC driver...");
									String url ="jdbc:db2://"+dbServerName+":"+dbPortNo+"/"+dbName;
									//String url ="jdbc:teradata://"+dbServerName+"/database ="+dbName+",USER="+dbUserName+",PASSWORD="+dbPassword+",tmode=tera,charset=UTF8,LOGMECH=LDAP";
									// Creating a connection object
									// Connection con = DriverManager.getConnection(url, sUser, sPassword);
									Connection conn = DriverManager.getConnection(url, dbUserName, dbPassword);
									//Connection conn = DriverManager.getConnection(url);
									//System.out.println(" User is connected.");
									//System.out.println(" Connection to Teradata established. \n");
					            	//Connection conn = DriverManager.getConnection(url);

					            	//Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
					            	//Statement stmt = conn.createStatement();
									//stmt = conn.createStatement();
									stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
					                stmt.setFetchSize(500000);		                
					                
					                querylist.clear();
				        			 //System.out.println("File name: "+tablepath+"\n");
				        			 executeQuery(inputQueryFileName);
				        			 if(querylist.size()>0)
				        			System.out.println("No of Queries to be executed is: "+querylist.size()+" for file: "+inputQueryFileName+"\n");
					        	 
					        	 /*************Splitting the input query and output filename from each combination
					        	   Then Reading each query and Writing to specific output files executing each query**************/
					        	 for(int i =0;i<var.length;i++)
					        	 {
					        		 //sqlExceptionFlag=false;
					        		 //TimeUnit.SECONDS.sleep(1);
					        		// String[] varName =  var[i].toString().split("#");
					        		 varName =  var[i].toString().split("#");
					        		 if(querytobeselected==true){
					        			 //System.out.println("varName[0] : "+varName[0]);
					        			 //System.out.println("varName[1] : "+varName[1]);
					        			 if(querylist.contains(varName[0])){
					        				 //System.out.println("Line no 277");
					        		File targetFile2 = null;
					        		File targetFile2_common_result = null;
					        		if(execute_in_unix){
					        		//For Unix
					        		 targetFile2 = new File(directory_path+inputQueryFileName+"_temp/"+varName[0]+".txt");
					        		 if(flag_centralized_server == true)
					        		 targetFile2_common_result = new File(directory_path+"Results_"+execution_id+"/"+varName[0]+".txt");
					        		}
					        		else{
					        		 //For Windows
					        		 targetFile2 = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+varName[0]+".txt");
					        		 targetFile2_common_result = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+varName[0]+".txt");
					        		}
		     		                FileWriter fileWriter2 = new FileWriter(targetFile2);
		     		                fileWriter2.write("");
		     			        	 fileWriter2.close();
		     			        	if(flag_centralized_server == true){
		     			        	FileWriter fileWriter21 = new FileWriter(targetFile2_common_result);
		     		                fileWriter21.write("");
		     			        	 fileWriter21.close();
		     			        	}
					        			 /*******************Reading each query************************/
						        		 readerThread[i] = new Thread("ODP Reader") {
						        		        public synchronized void run() {
						        		            try {
						        		            	
						        		       		
						        		       		 try{
						        		       			/***Drop Table Query Execution***/
						        		       			 if(varName[0].contains("Drop")) {
						        		       				 StringBuffer tempTableQuery=new StringBuffer();
						        		       				 tempTableQuery.append(varName[1]);
						        		       				 stmt.executeUpdate(tempTableQuery.toString());
						        		    				 System.out.println("Volatile table dropped before creation Successfully");
						        		    				 passFlag=true;	        		    				 
						        		       			 }
						        		       			 /***Create Table Query Execution***/
						        		       			 else if(varName[0].contains("Create")) {
						        		       				 StringBuffer tempTableQuery=new StringBuffer();
						        		       				 tempTableQuery.append(varName[1]);
						        		       				 stmt.executeUpdate(tempTableQuery.toString());
						        		    				 System.out.println("Volatile table created Successfully");
						        		    				 passFlag=true;	        		    				 
						        		       			 }
						        		       			/***Insert into Table Query Execution***/
						        		       			 else if(varName[0].contains("Insert")) {
						        		       				 StringBuffer tempTableQuery=new StringBuffer();
						        		       				 tempTableQuery.append(varName[1]);
						        		    				 stmt.executeUpdate(tempTableQuery.toString());
						        		    				 System.out.println("Data Inserted Successfully");
						        		    				 passFlag=true;	        		    				 
						        		       			 }
						        		       			/***Delete Table Query Execution***/
						        		       			 else if(varName[0].contains("Delete")) {
						        		       				 StringBuffer tempTableQuery=new StringBuffer();
						        		       				 tempTableQuery.append(varName[1]);
						        		       				 stmt.executeUpdate(tempTableQuery.toString());
						        		       				 System.out.println("Data Deleted Successfully");
						        		       				 passFlag=true;	        		    				 
							        		       			 }
						        		       			/***Select Query Execution***/
						        		       			 else
						        		       			 {
							        		       			 ResultSet rs = stmt.executeQuery(varName[1]);
							        		       			 ResultSetMetaData rsmd = rs.getMetaData();
							        		       			int totalRows = 0;
							        		       			int row_count = 0;
							        		       		// Retrieve the number of columns returned
							        					int colCount = rsmd.getColumnCount();
							        		       		System.out.println("Fetching result");
							        	                System.out.println("Column 1:" +rs.getMetaData().getColumnName(1));
							        		       		StringBuilder sb = new StringBuilder();
							        		       	//	setting passFlag false before each iteration
							        		       			passFlag=true;
							        		       			boolean diff_dount_flag = false;
							        			           for(int i=1; i<= colCount; i++)   
							        		         		  {  
							        		            		sb.append(rsmd.getColumnName(i)).append(',');
							        		            		if("diff_count".equals(rsmd.getColumnName(i))){
							        		            			diff_dount_flag = true;
								        		            		}
							        		         		  }              
							        		            	sb.append(System.getProperty("line.separator"));
							        		                StringBuilder sb1 = new StringBuilder();
							        		                while(rs.next()){
							        		                	//for(int j=1; j<= colCount; j++){
							        		                	if(diff_dount_flag == true && rs.getInt("diff_count")==0 ){//when resultset fetches exactly one record we check if it's the count query that is getting executed which has "data_count" as an alias name inside the query itself
							        		                		passFlag=true;
							        		                		for(int i=1; i<= colCount; i++)   
								        		             		  {  
								        		                		//sb1.append(rstemp3.getInt(i)).append('\t');
							        		                			
								        		                		sb1.append(rs.getString(i)).append(',');
								        		             		  }
								        		                	 sb1.append(System.getProperty("line.separator"));
							        		                	 sb1.append(System.getProperty("line.separator"));
							        		                	}
							        		                	else{//when resultset fetches exactly one record we check if it's the count query that is getting executed which has "data_count" as an alias name inside the query itself
							        		                		passFlag=false;
							        		                		scenarioPassFlag=false;
							        		                		//totalRows = rs.getRow();
							        		                		for(int i=1; i<= colCount; i++)   
								        		             		  {  
								        		                		//sb1.append(rstemp3.getInt(i)).append('\t');
							        		                			
								        		                		sb1.append(rs.getString(i)).append(',');
								        		             		  }
								        		                	 sb1.append(System.getProperty("line.separator"));
							        		                	 sb1.append(System.getProperty("line.separator"));
							        		                	 row_count++;
							        		                	 if (row_count == 100) break;
							        		                	}
							        		                	//}

							        		                	 
									        		             
							        		                }
							        		                queue.put((sb.append(sb1)).toString());
							        		                rs.close();	        		                		
							        		                }
						        		       		}
						        		       		 	catch(Exception e){
						        		       		 	sqlExceptionFlag=true;
						        		       		 	scenarioPassFlag=false;
						        		       		/* 	String summaryFile1 = prop.getProperty("Output_Path")+utility_name+"\\\\Generic Query Result\\\\"+reslpath+"\\Summary_Result.txt";*/
						        		       		 	String summaryFile1 = null;
						        		       		 	String summaryFile1_common_result = null;
						        		       		 	if(execute_in_unix){
						        		       		 	//For Unix
						        		       		 	summaryFile1 =directory_path+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
						        		       		 	if(flag_centralized_server == true)
						        		       		 	summaryFile1_common_result =directory_path+"Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
						        		       		 	}
						        		       		 	else{
						        		       		 	//For Windows
						        		       		 	summaryFile1 ="C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
						        		       		 	summaryFile1_common_result ="C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
						        		       		 	}
						        		                FileWriter fileWriter3 = new FileWriter(summaryFile1,true);				        		               
						        		                BufferedWriter writer3 = new BufferedWriter(fileWriter3);
						        		                //writer3.write(varName[0]+ "," + e.getMessage() );
						        		                writer3.write(String.format("%-30s %-25s \r\n", varName[0], e.getMessage() ));
						        		                writer3.newLine();
						        		                fileWriter3.flush();
						        		                writer3.close();
						        		                if(flag_centralized_server == true){
						        		                FileWriter fileWriter31 = new FileWriter(summaryFile1_common_result,true);				        		               
						        		                BufferedWriter writer31 = new BufferedWriter(fileWriter31);
						        		                //writer3.write(varName[0]+ "," + e.getMessage() );
						        		                writer31.write(String.format("%-30s %-25s \r\n", varName[0], e.getMessage() ));
						        		                writer31.newLine();
						        		                fileWriter31.flush();
						        		                writer31.close();
						        		                }
						        		       		 	e.printStackTrace();
						        		       		 	}
						        		                finished = true; 
						        		            } catch (Throwable e) {
						        		                e.printStackTrace();
						        		                return;
						        		            }
						        		        }

											};
						        		    
						        		    if(sqlExceptionFlag==true){
						        		    	 
						        		    	break;
						        		    }
						        		    
						        		    //System.out.println("SQL Exception Flag for "+ varName[0] + "is "+sqlExceptionFlag);
						        		
						        		 /*******************Writing the result in corresponding output file************************/
						        		    
						        		  writeWorker[i] = new Thread("ODP Writer") {
						        			  
						        			  
						        		        public synchronized void run() {
						        		            try {
						        		            	File targetFile = null;
						        		            	File targetFile_common_result = null;
						        		            	if(execute_in_unix){
						        		            	//For Unix
						        		            	targetFile = new File(directory_path+inputQueryFileName+"_temp/"+varName[0]+".txt");
						        		            	if(flag_centralized_server == true)
						        		            	targetFile_common_result = new File(directory_path+"Results_"+execution_id+"/"+varName[0]+".txt");
						        		            	}
						        		            	else{
						        		            	//For Windows
						        		            	targetFile = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+varName[0]+".txt");
						        		            	targetFile_common_result = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+varName[0]+".txt");
						        		            	}
						        		                FileWriter fileWriter = new FileWriter(targetFile,true);
						        		                BufferedWriter writer = new BufferedWriter(fileWriter);
						        		                BufferedWriter writer11 = null;
						        		                if(flag_centralized_server == true){
						        		                FileWriter fileWriter11 = new FileWriter(targetFile_common_result,true);
						        		                writer11 = new BufferedWriter(fileWriter11);
						        		                }
						        		                String summaryFile = null;
						        		                String summaryFile_common_result = null;
						        		                if(execute_in_unix){
						        		                //For Unix
						        		                summaryFile = directory_path+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
						        		                if(flag_centralized_server == true)
						        		                summaryFile_common_result = directory_path+"Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
						        		                }
						        		                else{
						        		                //For Windows
						        		                summaryFile = "C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
						        		                summaryFile_common_result = "C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
						        		                }
						        		                FileWriter fileWriter1 = new FileWriter(summaryFile,true);
						        		                BufferedWriter writer1 = new BufferedWriter(fileWriter1);
						        		                BufferedWriter writer12 = null;
						        		                if(flag_centralized_server == true){
						        		                FileWriter fileWriter12 = new FileWriter(summaryFile_common_result,true);
						        		                writer12 = new BufferedWriter(fileWriter12);
						        		                }
						        		                String str;
						        		                //varName[0]
						        		                writer.newLine();
						        		                writer.write(varName[0]+" Result: ");
						        		                writer.newLine();
						        		                writer.write("Comparison Starts--");
						        		                writer.newLine();
						        		                if(flag_centralized_server == true){
						        		                writer11.newLine();
						        		                writer11.write(varName[0]+" Result: ");
						        		                writer11.newLine();
						        		                writer11.write("Comparison Starts--");
						        		                writer11.newLine();
						        		                }
						        		               // writer.write("Comparison Starts--");
						        		                //writer.newLine();
						        		                try {
						        		                    while (!finished) {
							        		                       str = queue.poll(200, TimeUnit.MILLISECONDS);
							        		                        if (str == null || str.isEmpty()) 
							        		                        {                       	
							        		                            Thread.sleep(50);
							        		                            continue;                       
							        		                        } 
							        		                        writer.write(str);
							        		                        writer.newLine();
							        		                        if(flag_centralized_server == true){
							        		                        writer11.write(str);
							        		                        writer11.newLine();
							        		                        }
							        		                    }
							        		                    
							        		                    if(sqlExceptionFlag==false){
							        		                    //writer.write("Database Tables comparison is completed and there are no/no more mismatch found");
							        		                    //writer.newLine();
							        		                    if(passFlag==true){
							        		                    	 writer1.write(String.format("%-30s %-25s \r\n", varName[0], "Pass" )); 
							        		                    	 //writer1.write(varName[0]+ "\t" + "Pass" );
							        		                    	 writer1.newLine();
							        		                    	 if(flag_centralized_server == true){
							        		                    	 writer12.write(String.format("%-30s %-25s \r\n", varName[0], "Pass" )); 
							        		                    	 //writer1.write(varName[0]+ "\t" + "Pass" );
							        		                    	 writer12.newLine();
							        		                    	 }
							        		                    	 writer.newLine();
							        		                    	 writer.write("Comparison is completed and there are no mismatch found.");
							        		                    	 writer.newLine();
							        		                    	 if(flag_centralized_server == true){
							        		                    	 writer11.newLine();
							        		                    	 writer11.write("Comparison is completed and there are no mismatch found.");
							        		                    	 writer11.newLine();
							        		                    	 }
								        		                }
								        		                else {
								        		                	writer1.write(String.format("%-30s %-25s \r\n", varName[0], "Fail" ));
								        		                	//writer1.write(varName[0]+ "\t" + "Fail");
								        		                	writer1.newLine();
								        		                	if(flag_centralized_server == true){
								        		                	writer12.write(String.format("%-30s %-25s \r\n", varName[0], "Fail" ));
								        		                	//writer1.write(varName[0]+ "\t" + "Fail");
								        		                	writer12.newLine();
								        		                	}
								        		                	writer.write("Comparison is completed--");
								        		                	writer.newLine();
								        		                	if(flag_centralized_server == true){
								        		                	writer11.write("Comparison is completed--");
								        		                	writer11.newLine();
								        		                	}
								        		                }
							        		                    writer.close();
							        		                    writer11.close();
							        		                    writer1.close();
							        		                    writer12.close();
							        		                }
							        		                    
							        		                }catch (InterruptedException e) {
						        		                   
						        		                    return;
						        		                }
						        		            }
						        		            
						        		            catch (Throwable e) {
						        		                e.printStackTrace();
						        		                return;
						        		            }
						        		        }
						        		    };
						        		    
						        		    long startTime = System.currentTimeMillis();
						        		    writeWorker[i].start();
						        		    readerThread[i].start();
						        		    //writeWorker.start();
						        		    System.out.println("Waiting for join..");
						        		    writeWorker[i].join();
						        		    writeWorker[i].sleep(1000);;
						        		    System.out.println("Exit:"+ (System.currentTimeMillis() - startTime));
			    
						        		  //-----------for next clean iteration---------------
						                    finished=false;
						                    str.setLength(0);
						                    //--------------------------
						                   // TimeUnit.SECONDS.sleep(1);
					        		 //}
					        			 }
					        		 }
					        		 else{
				        				 //System.out.println("Line no 277");
				        		File targetFile2 = null;
				        		File targetFile2_common_result = null;
				        		if(execute_in_unix){
				        		//For Unix
				        		 targetFile2 = new File(directory_path+inputQueryFileName+"_temp/"+varName[0]+".txt");
				        		 if(flag_centralized_server == true)
				        		 targetFile2_common_result = new File(directory_path+"Results_"+execution_id+"/"+varName[0]+".txt");
				        		}
				        		else{
				        		 //For Windows
				        		 targetFile2 = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+varName[0]+".txt");
				        		 targetFile2_common_result = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+varName[0]+".txt");
				        		}
	     		                FileWriter fileWriter2 = new FileWriter(targetFile2);
	     		                fileWriter2.write("");
	     			        	 fileWriter2.close();
	     			        	if(flag_centralized_server == true){
	     			        	FileWriter fileWriter21 = new FileWriter(targetFile2_common_result);
	     		                fileWriter21.write("");
	     			        	 fileWriter21.close();
	     			        	}
				        			 /*******************Reading each query************************/
					        		 readerThread[i] = new Thread("ODP Reader") {
					        		        public synchronized void run() {
					        		            try {
					        		            	
					        		       		
					        		       		 try{
					        		       			/***Drop Table Query Execution***/
					        		       			 if(varName[0].contains("Drop")) {
					        		       				 StringBuffer tempTableQuery=new StringBuffer();
					        		       				 tempTableQuery.append(varName[1]);
					        		       				 stmt.executeUpdate(tempTableQuery.toString());
					        		    				 System.out.println("Volatile table dropped before creation Successfully");
					        		    				 passFlag=true;	        		    				 
					        		       			 }
					        		       			 /***Create Table Query Execution***/
					        		       			 else if(varName[0].contains("Create")) {
					        		       				 StringBuffer tempTableQuery=new StringBuffer();
					        		       				 tempTableQuery.append(varName[1]);
					        		       				 stmt.executeUpdate(tempTableQuery.toString());
					        		    				 System.out.println("Volatile table created Successfully");
					        		    				 passFlag=true;	        		    				 
					        		       			 }
					        		       			/***Insert into Table Query Execution***/
					        		       			 else if(varName[0].contains("Insert")) {
					        		       				 StringBuffer tempTableQuery=new StringBuffer();
					        		       				 tempTableQuery.append(varName[1]);
					        		    				 stmt.executeUpdate(tempTableQuery.toString());
					        		    				 System.out.println("Data Inserted Successfully");
					        		    				 passFlag=true;	        		    				 
					        		       			 }
					        		       			/***Delete Table Query Execution***/
					        		       			 else if(varName[0].contains("Delete")) {
					        		       				 StringBuffer tempTableQuery=new StringBuffer();
					        		       				 tempTableQuery.append(varName[1]);
					        		       				 stmt.executeUpdate(tempTableQuery.toString());
					        		       				 System.out.println("Data Deleted Successfully");
					        		       				 passFlag=true;	        		    				 
						        		       			 }
					        		       			/***Select Query Execution***/
					        		       			 else
					        		       			 {
						        		       			 ResultSet rs = stmt.executeQuery(varName[1]);
						        		       			 ResultSetMetaData rsmd = rs.getMetaData();
						        		       		// Retrieve the number of columns returned
						        		       			 
						        		       			int totalRows = 0;
						        		       			int row_count = 0;
						        		       			 
						        					int colCount = rsmd.getColumnCount();
						        		       		System.out.println("Fetching result");
						        	                System.out.println("Column 1:" +rs.getMetaData().getColumnName(1));
						        		       		
						        		       	//	queue.put(rs.getMetaData().getColumnName(1));
						        		       		
						        	                StringBuilder sb = new StringBuilder();
						        		       		
						        		       	//	sb.append(rs.getMetaData().getColumnName(1) + '\n');
						        		       	//	setting passFlag false before each iteration
						        		       		
						        		       			passFlag=false;
						        		       			
						        			           for(int i=1; i<= colCount; i++)   
						        		         		  {  
						        		            		sb.append(rsmd.getColumnName(i)).append(',');
						        		         		  }              
						        		            	
						        			           sb.append(System.getProperty("line.separator"));
						        		                StringBuilder sb1 = new StringBuilder();
						        		                
						        		                
						        		                if(!rs.next()) //cursor goes to the next line of the resultSet once this condition is checked
						        		                    passFlag=true;
						        		                	
						        		                rs.beforeFirst(); //To take the cursor back to first line of the result set
						        		                	
						        		                if(rs.next())	{
						        		                	//countFlag =false;
						        		                	rs.last();
						        		                	totalRows = rs.getRow();
						        		                	//System.out.println("Total number of Mismatch records:" +totalRows);
						        		                	
						        		                	rs.beforeFirst(); //To take the cursor back to first line of the result set
						        		                
						        		                	scenarioPassFlag=false;
						        		                	
						        		                	 while (rs.next())
								        		                {
						        		                		 
								        		                	row_count++;
								        		                	   passFlag=false;        	               	
								        		                	for(int i=1; i<= colCount; i++)   
								        		             		  {  
								        		                		sb1.append(rs.getString(i)).append('\t');
								        		             		  }
								        		                
								        		                	 sb1.append(System.getProperty("line.separator"));
								        		                	if (row_count == 100) break;
								        		                	//  sb.append('\n');
								        		                    
								        		                }
								        		                
								        		                queue.put((sb.append(sb1)).toString());
								        		                rs.close();
								        		                }
								        		                
								        		            }
					        		       		}
					        		       		 	catch(Exception e){
					        		       		 	sqlExceptionFlag=true;
					        		       		 	scenarioPassFlag=false;
					        		       		/* 	String summaryFile1 = prop.getProperty("Output_Path")+utility_name+"\\\\Generic Query Result\\\\"+reslpath+"\\Summary_Result.txt";*/
					        		       		 	String summaryFile1 = null;
					        		       		 	String summaryFile1_common_result = null;
					        		       		 	if(execute_in_unix){
					        		       		 	//For Unix
					        		       		 	summaryFile1 =directory_path+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
					        		       		 	if(flag_centralized_server == true)
					        		       		 	summaryFile1_common_result =directory_path+"Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
					        		       		 	}
					        		       		 	else{
					        		       		 	//For Windows
					        		       		 	summaryFile1 ="C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
					        		       		 	summaryFile1_common_result ="C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
					        		       		 	}
					        		                FileWriter fileWriter3 = new FileWriter(summaryFile1,true);				        		               
					        		                BufferedWriter writer3 = new BufferedWriter(fileWriter3);
					        		                //writer3.write(varName[0]+ "," + e.getMessage() );
					        		                writer3.write(String.format("%-30s %-25s \r\n", varName[0], e.getMessage() ));
					        		                writer3.newLine();
					        		                fileWriter3.flush();
					        		                writer3.close();
					        		                if(flag_centralized_server == true){
					        		                FileWriter fileWriter31 = new FileWriter(summaryFile1_common_result,true);				        		               
					        		                BufferedWriter writer31 = new BufferedWriter(fileWriter31);
					        		                //writer3.write(varName[0]+ "," + e.getMessage() );
					        		                writer31.write(String.format("%-30s %-25s \r\n", varName[0], e.getMessage() ));
					        		                writer31.newLine();
					        		                fileWriter31.flush();
					        		                writer31.close();
					        		                }
					        		       		 	e.printStackTrace();
					        		       		 	}
					        		                finished = true; 
					        		            } catch (Throwable e) {
					        		                e.printStackTrace();
					        		                return;
					        		            }
					        		        }

										};
					        		    
					        		    if(sqlExceptionFlag==true){
					        		    	 
					        		    	break;
					        		    }
					        		    
					        		    //System.out.println("SQL Exception Flag for "+ varName[0] + "is "+sqlExceptionFlag);
					        		
					        		 /*******************Writing the result in corresponding output file************************/
					        		    
					        		  writeWorker[i] = new Thread("ODP Writer") {
					        			  
					        			  
					        		        public synchronized void run() {
					        		            try {
					        		            	File targetFile = null;
					        		            	File targetFile_common_result = null;
					        		            	if(execute_in_unix){
					        		            	//For Unix
					        		            	targetFile = new File(directory_path+inputQueryFileName+"_temp/"+varName[0]+".txt");
					        		            	if(flag_centralized_server == true)
					        		            	targetFile_common_result = new File(directory_path+"Results_"+execution_id+"/"+varName[0]+".txt");
					        		            	}
					        		            	else{
					        		            	//For Windows
					        		            	targetFile = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+varName[0]+".txt");
					        		            	targetFile_common_result = new File("C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+varName[0]+".txt");
					        		            	}
					        		                FileWriter fileWriter = new FileWriter(targetFile,true);
					        		                BufferedWriter writer = new BufferedWriter(fileWriter);
					        		                BufferedWriter writer11 = null;
					        		                if(flag_centralized_server == true){
					        		                FileWriter fileWriter11 = new FileWriter(targetFile_common_result,true);
					        		                writer11 = new BufferedWriter(fileWriter11);
					        		                }
					        		                String summaryFile = null;
					        		                String summaryFile_common_result = null;
					        		                if(execute_in_unix){
					        		                //For Unix
					        		                summaryFile = directory_path+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
					        		                if(flag_centralized_server == true)
					        		                summaryFile_common_result = directory_path+"Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
					        		                }
					        		                else{
					        		                //For Windows
					        		                summaryFile = "C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
					        		                summaryFile_common_result = "C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
					        		                }
					        		                FileWriter fileWriter1 = new FileWriter(summaryFile,true);
					        		                BufferedWriter writer1 = new BufferedWriter(fileWriter1);
					        		                BufferedWriter writer12 = null;
					        		                if(flag_centralized_server == true){
					        		                FileWriter fileWriter12 = new FileWriter(summaryFile_common_result,true);
					        		                writer12 = new BufferedWriter(fileWriter12);
					        		                }
					        		                String str;
					        		                //varName[0]
					        		                writer.newLine();
					        		                writer.write(varName[0]+" Result: ");
					        		                writer.newLine();
					        		                writer.write("Comparison Starts--");
					        		                writer.newLine();
					        		                if(flag_centralized_server == true){
					        		                writer11.newLine();
					        		                writer11.write(varName[0]+" Result: ");
					        		                writer11.newLine();
					        		                writer11.write("Comparison Starts--");
					        		                writer11.newLine();
					        		                }
					        		               // writer.write("Comparison Starts--");
					        		                //writer.newLine();
					        		                try {
					        		                    while (!finished) {
						        		                       str = queue.poll(200, TimeUnit.MILLISECONDS);
						        		                        if (str == null || str.isEmpty()) 
						        		                        {                       	
						        		                            Thread.sleep(50);
						        		                            continue;                       
						        		                        } 
						        		                        writer.write(str);
						        		                        writer.newLine();
						        		                        if(flag_centralized_server == true){
						        		                        writer11.write(str);
						        		                        writer11.newLine();
						        		                        }
						        		                    }
						        		                    
						        		                    if(sqlExceptionFlag==false){
						        		                    //writer.write("Database Tables comparison is completed and there are no/no more mismatch found");
						        		                    //writer.newLine();
						        		                    if(passFlag==true){
						        		                    	 writer1.write(String.format("%-30s %-25s \r\n", varName[0], "Pass" )); 
						        		                    	 //writer1.write(varName[0]+ "\t" + "Pass" );
						        		                    	 writer1.newLine();
						        		                    	 if(flag_centralized_server == true){
						        		                    	 writer12.write(String.format("%-30s %-25s \r\n", varName[0], "Pass" )); 
						        		                    	 //writer1.write(varName[0]+ "\t" + "Pass" );
						        		                    	 writer12.newLine();
						        		                    	 }
						        		                    	 writer.newLine();
						        		                    	 writer.write("Comparison is completed and there are no mismatch found.");
						        		                    	 writer.newLine();
						        		                    	 if(flag_centralized_server == true){
						        		                    	 writer11.newLine();
						        		                    	 writer11.write("Comparison is completed and there are no mismatch found.");
						        		                    	 writer11.newLine();
						        		                    	 }
							        		                }
							        		                else {
							        		                	writer1.write(String.format("%-30s %-25s \r\n", varName[0], "Fail" ));
							        		                	//writer1.write(varName[0]+ "\t" + "Fail");
							        		                	writer1.newLine();
							        		                	if(flag_centralized_server == true){
							        		                	writer12.write(String.format("%-30s %-25s \r\n", varName[0], "Fail" ));
							        		                	//writer1.write(varName[0]+ "\t" + "Fail");
							        		                	writer12.newLine();
							        		                	}
							        		                	writer.write("Comparison is completed--");
							        		                	writer.newLine();
							        		                	if(flag_centralized_server == true){
							        		                	writer11.write("Comparison is completed--");
							        		                	writer11.newLine();
							        		                	}
							        		                }
						        		                    writer.close();
						        		                    writer1.close();
						        		                    if(flag_centralized_server == true){
							        		                writer11.close();
						        		                    writer12.close();
						        		                    }
						        		                }
						        		                    
						        		                }catch (InterruptedException e) {
					        		                   
					        		                    return;
					        		                }
					        		            }
					        		            
					        		            catch (Throwable e) {
					        		                e.printStackTrace();
					        		                return;
					        		            }
					        		        }
					        		    };
					        		    
					        		    long startTime = System.currentTimeMillis();
					        		    writeWorker[i].start();
					        		    readerThread[i].start();
					        		    //writeWorker.start();
					        		    System.out.println("Waiting for join..");
					        		    writeWorker[i].join();
					        		    writeWorker[i].sleep(1000);;
					        		    System.out.println("Exit:"+ (System.currentTimeMillis() - startTime));
		    
					        		  //-----------for next clean iteration---------------
					                    finished=false;
					                    str.setLength(0);
					                    //--------------------------
					                   // TimeUnit.SECONDS.sleep(1);
				        		 //}
				        			 }
					        	 }
					        	 stmt.close();
					             conn.close();
					             String summaryFile1 = null;
					             String summaryFile1_common_result = null;
					             if(execute_in_unix){
					             //FOr Unix
					             summaryFile1 = directory_path+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
					             if(flag_centralized_server == true)
					             summaryFile1_common_result = directory_path+"Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
					             }
					             else{
					             //For Windows
					             summaryFile1 = "C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/"+inputQueryFileName+"_Summary_Result.txt";
					             summaryFile1_common_result = "C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/"+inputQueryFileName+"_Summary_Result.txt";
					             }
					                FileWriter fileWriter3 = new FileWriter(summaryFile1,true);
					                BufferedWriter writer3 = new BufferedWriter(fileWriter3);
					                FileWriter fileWriter31 = null;
					                BufferedWriter writer31 = null;
					                if(flag_centralized_server == true){
					                fileWriter31 = new FileWriter(summaryFile1_common_result,true);
					                writer31 = new BufferedWriter(fileWriter31);
					                }
					         if(scenarioPassFlag){
					        	 writer3.write(String.format("%-30s %-25s \r\n", "Overall Scenario", "Pass" ));
					        	 if(flag_centralized_server == true)
					        	 writer31.write(String.format("%-30s %-25s \r\n", "Overall Scenario", "Pass" ));
					         }
					         else{
					        	 writer3.write(String.format("%-30s %-25s \r\n", "Overall Scenario", "Fail" ));
					        	 if(flag_centralized_server == true)
					        	 writer31.write(String.format("%-30s %-25s \r\n", "Overall Scenario", "Fail" ));
					         }
			           	fileWriter3.flush();
			           	writer3.close();
			           	if(flag_centralized_server == true){
			           	fileWriter31.flush();
			           	writer31.close();
			           	}
						}
					        	 
						}
						catch (Exception ex)
						{
							ex.printStackTrace();
						}
						inputStream.close();
					  }
	
				
			
			System.out.println("\n"); 
			System.out.println("--------------End of Validation for this File--------------");
			System.out.println("\n");
			
			/*if(flag_centralized_server == true){
			*//***Copy from output directory to common Result directory***//*
			if(execute_in_unix){
			//For Unix
			//String strSource = directory_path+inputQueryFileName+"_temp/";
			//String strDestination = directory_path+"Results_"+execution_id+"/";
				String strSource = directory_path+inputQueryFileName+"_temp";
				String strDestination = directory_path+"Results_"+execution_id;
			//String[] b = new String[] {"bash", "-c", "cp -R \"" + strSource + "/\"* \"" + strDestination + "/\""};//original
			String[] b = new String[] {"bash", "-c", "cp -R \"" + strSource + "/*\" \"" + strDestination + "/\""};
			for(int i=0;i<b.length;i++){
			System.out.println("Command-"+i+": "+b[i]);
			}
			//String[] b = new String[] {"bash", "-c", "cp -R \"" + strSource + "* \"" + strDestination };
	        Runtime.getRuntime().exec(b);
			File srcDir = new File(strSource);			
			File destDir = new File(strDestination);

			try {
			    FileUtils.copyDirectory(srcDir, destDir);
			} catch (IOException e) {
			    e.printStackTrace();
			}
			Process p1=null;
			ProcessBuilder pb = new ProcessBuilder("cp ", strSource, strDestination);
			p1 = pb.start();
			//Thread.sleep(4000);
			//p1.waitFor();
			//p1.destroy();
			}
			else{
             //For Windows
			//In Windows: Copy from output directory to common Result directory
			String source = "C:\\tmp\\bdv_pims\\PIMS_FT\\"+inputQueryFileName+"_temp/";
			String destination = "C:\\tmp\\bdv_pims\\PIMS_FT\\Results_"+execution_id+"/";
			
			File srcDir = new File(source);			
			File destDir = new File(destination);

			try {
			    FileUtils.copyDirectory(srcDir, destDir);
			} catch (IOException e) {
			    e.printStackTrace();
			}
			}
			}*/
			
	}
	

}