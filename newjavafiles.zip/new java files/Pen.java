class Pen{

public static void main(String a[])
{
    String penName = "reynolds";
     int price= 12;
 String color =  "black";
System.out.println("Pen is a sword");
System.out.println(penName);
System.out.println(price);
System.out.println(color);
}

}