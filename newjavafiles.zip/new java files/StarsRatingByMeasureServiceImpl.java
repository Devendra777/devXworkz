package com.wellpoint.pc2dash.service.stars;

import static com.wellpoint.pc2dash.service.dashboard.Constants.COMMA;
import static com.wellpoint.pc2dash.service.dashboard.ErrorMessages.HOMEPAGE_TICKER;
import static com.wellpoint.pc2dash.service.dashboard.ErrorMessages.SQL;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.wellpoint.pc2dash.action.stars.StarsRatingByMeasureRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dao.AbstractDao;
import com.wellpoint.pc2dash.dto.stars.StarsRatingByMeasureJson;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;
import static com.wellpoint.pc2dash.util.Constants.CLOSE_BRACKET;

public class StarsRatingByMeasureServiceImpl extends AbstractDao{
	
	

	


	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(StarsRatingByMeasureServiceImpl.class);
	private static final String  MSR_DIM_KEY = "MSR_DIM_KEY";
	private static final String MSR_NM = "MSR_NM";
	private static final String STAR_RATING_NUMBER = "STAR_RATING_NUMBER"; 
	
	
	public List<StarsRatingByMeasureJson> getData(StarsRatingByMeasureRequest measureRequest) throws PC2Exception {
		List<StarsRatingByMeasureJson> results = new ArrayList<StarsRatingByMeasureJson>();
		
		StringBuilder sql = getStarsRatingByMeasureQuery(measureRequest);
		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(measureRequest, sql.toString());
			executeQuery(logger, sql.toString());
			getResult(results);
		}
		catch (Exception e) {
			throw new PC2Exception( HOMEPAGE_TICKER + measureRequest.toString() + SQL + sql.toString(), e);
		}
		finally {
			close();
		}

		return results;
	}
		




	private StringBuilder getStarsRatingByMeasureQuery(StarsRatingByMeasureRequest measureRequest) {
		/**
		 *
		 * @param request
		 * @return
		 */
		StringBuilder sql = new StringBuilder()
				.append("select ")
				.append(" MDCR_STAR.MSR_DIM_KEY as MSR_DIM_KEY, ")
				.append(" RFRNC.MSR_NM as  MSR_NM, ")
				.append(" RFRNC.STAR_LVL_CD, ")
				.append(" SUBSTR(RFRNC.STAR_LVL_CD,1,1) as STAR_RATING_NUMBER ")
				.append(" from ( ")
				.append(" SELECT ")
				.append(" MSSF.MSR_DIM_KEY, ")
				.append(" MD.MSR_DSPLY_NM, ")
				.append(" MD.RULE_ID,  ")
				.append("  MSSF.MSR_YEAR_NBR,  ")
				.append("SUM(NMRTR_NBR) AS NMRTR_NBR, ")
				.append(" SUM(DNMNTR_NBR) AS DNMNTR_NBR,  ")
				.append(" ROUND(CAST(SUM(NMRTR_NBR)*100 AS DECIMAL(18,2))/SUM(DNMNTR_NBR),2)AS CMPLNC_RT_PCT  ")
				.append(" FROM MDCR_STAR_SMRY_FACT MSSF  ")
				.append(" INNER JOIN PROV_GRP_DIM PGD ")
				.append(" ON MSSF.PROV_GRP_DIM_KEY=PGD.PROV_GRP_DIM_KEY ")
				.append(" AND PGD.RCRD_STTS_CD='ACT' ")
				.append(" INNER JOIN PROV_ORG_DIM POD ")
				.append(" ON MSSF.PROV_ORG_DIM_KEY=POD.PROV_ORG_DIM_KEY ")
				.append(" AND POD.RCRD_STTS_CD='ACT' ")
				.append(" INNER JOIN PGM_DIM PD ")
				.append(" ON MSSF.PGM_DIM_KEY=PD.PGM_DIM_KEY ")
				.append(" AND PD.RCRD_STTS_CD='ACT' ")
				.append(" INNER JOIN MSR_DIM MD ")
				.append(" ON MSSF.MSR_DIM_KEY=MD.MSR_DIM_KEY ")
				.append(" AND PD.RCRD_STTS_CD='ACT' ")
			    .append(" INNER JOIN PSL_DIM PSL ")
				.append(" ON MSSF.PSL_DIM_KEY=PSL.PSL_DIM_KEY ")
				.append("  join poit_user_scrty_acs PUSA on ( ")
				.append("    pgd.prov_grp_id = PUSA.prov_grp_id ")
				.append("    and case ")
				.append("        when PUSA.prov_org_tax_id = '0' then pod.prov_org_tax_id ")
				.append("        else PUSA.prov_org_tax_id ")
				.append("      end = pod.prov_org_tax_id ")
				.append("  ) ")	
				.append("  where PRTLT_ID='1000' ")
				.append(buildWhereClause(measureRequest))
				.append("  GROUP BY MSSF.MSR_DIM_KEY, ")
				.append("  MD.MSR_DSPLY_NM, ")
				.append("  MD.RULE_ID, ")
				.append("  MSSF.MSR_YEAR_NBR  ")
				.append(" WITH UR  ")
				.append("  ) MDCR_STAR ")
				.append(" LEFT OUTER JOIN MDCR_STARS_CUT_PCT_RFRNC RFRNC  ")
				.append(" ON MDCR_STAR.RULE_ID=RFRNC.RULE_ID  ")
				.append(" AND MDCR_STAR.MSR_YEAR_NBR=RFRNC.MSR_YEAR_NBR ")
				.append(" AND MDCR_STAR.CMPLNC_RT_PCT BETWEEN RFRNC.MIN_CUT_PCT AND RFRNC.MAX_CUT_PCT WITH UR ");

		return sql;

	}

	/**
	 * This methods builds the where clause for the above query
	 * @param request
	 * @return
	 */
	private String buildWhereClause(StarsRatingByMeasureRequest request) {
		
		StringBuilder sql = new StringBuilder()
				.append("and PUSA.sesn_id = ? ")
				.append("and PUSA.enttlmnt_hash_key = ? ");

			if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
				sql.append("and pgd.prov_grp_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + CLOSE_BRACKET);
			}

			if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
				sql.append("and MSSF.pgm_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + CLOSE_BRACKET);
			}
	
			if (StringUtil.isNotBlankOrFalse(request.getPslIds())) {
				sql.append("and PSL.psl_desc in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPslIds()) + CLOSE_BRACKET);
			}

		    if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
	        	sql.append("and MSSF.prov_org_dim_key in ("
		  		+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys()) + CLOSE_BRACKET);
			}

			return sql.toString();
	}

	

	/**
	 * This method is to build prepared statement(populate values) in the where clause of AVCompletion port-let query 
	 * @param request
	 * @param query
	 * @throws SQLException
	 */
	protected void buildPreparedStatement(StarsRatingByMeasureRequest request, String query) throws SQLException {
		int i = 1;
		prepareStatement(logger, query);

		ps.setString(i++, request.getSessionId());

		ps.setString(i++, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
			String[] array = request.getProvGrpIds().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
			String[] array = request.getProgramIds().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getPslIds())) {
			String[] array = request.getPslIds().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}

	
		 if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) { 
			 String[] array = request.getOrgDimKeys().split(COMMA);
			 for (String item : array) {
				 ps.setString(i++, item); 
			 } 
		 }	  		
	}

	
	/**
	 * This method populates the JSON object based on the values fetched from the query result
	 * @param results
	 * @throws SQLException
	 */
	private List<StarsRatingByMeasureJson> getResult(List<StarsRatingByMeasureJson> results) throws SQLException {
			
			while (rs.next()) {
				StarsRatingByMeasureJson jsonResult = new StarsRatingByMeasureJson();		
				jsonResult.setCareOppId(Integer.parseInt(StringUtil.getValueOrDashes(rs.getString(MSR_DIM_KEY))));
				jsonResult.setMeasure(StringUtil.getValueOrDashes(rs.getString(MSR_NM)));
				jsonResult.setRating(StringUtil.getValueOrDashes(rs.getString(STAR_RATING_NUMBER)));
				results.add(jsonResult);
			}
			return results;
		}



	@Override
	public boolean read(Dto o) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(Dto o) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Dto o) throws Exception {
		// TODO Auto-generated method stub

	}



}
