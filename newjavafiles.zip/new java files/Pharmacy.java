class Pharmacy{

public static void main(String a[]){
    
 static  String name = "Mahindra";
static String address  = "Kalyanagar";
  static int noOfStaff  = 89;
static boolean isPharmacyAvailable = true;

 

System.out.println(name + "   "+ address + "   "+ noOfStaff + "  " +  isPharmacyAvailable);

}

}