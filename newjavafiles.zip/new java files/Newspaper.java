clas Newspaper12
{
     public static void main(String a[])
    {

      System.out.println("Reading Bangalore Mirror");
    }


} 