class   Add{


 static   int a1 = 56 + 89;
static int b1 = 90 + 34;
static int c1  = 76+12;

public static void main(String a[]){
  
System.out.println(a1);
System.out.println(b1);
System.out.println(c1);

System.out.println("getting output with methods");

add(56, 89);
add(90, 34);
add(76, 12);


}


public static void   add( int a1 , int b1){

        int c1 = a1+b1;
System.out.println(c1);
        }

}