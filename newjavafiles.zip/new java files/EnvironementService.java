package com.legato.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.legato.persistence.dto.EnvDTO;
import com.legato.persistence.dto.FilterConditionsDTO;
import com.legato.persistence.dto.JoinConditionsDetailsDTO;
import com.legato.persistence.dto.MetaDataDTO;
import com.legato.persistence.dto.SubQueryDetailsDTO;
import com.legato.persistence.repository.EnvironmentRepository;
import com.legato.persistence.repository.FilterConditionRepository;
import com.legato.persistence.repository.JoiningConditionRepository;
import com.legato.persistence.repository.MetaDataRepository;
import com.legato.persistence.repository.SubQueryDetailsRepository;

@Service
public class EnvironementService {

	@Autowired
	EnvironmentRepository environmentRepo;

	@Autowired
	FilterConditionRepository filterConditionRepository;

	@Autowired
	JoiningConditionRepository joiningConditionRepository;

	@Autowired
	MetaDataRepository metaDataRepository;

	@Autowired
	SubQueryDetailsRepository subQueryDetailsRepository;

	public EnvironementService() {
		// TODO Auto-generated constructor stub
	}

	public void validateAndSaveEnv(EnvDTO dto) {
		// TODO Auto-generated method stub
		if (dto != null) {
			environmentRepo.save(dto);
		}
	}

	public void validateAndSaveFilterConditions(FilterConditionsDTO dto) {
		try {
			if (dto != null) {
				filterConditionRepository.save(dto);
			} else {

			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

	public void validateAndSaveJoinConditions(JoinConditionsDetailsDTO dto) {
		try {
			if (dto != null) {
				joiningConditionRepository.save(dto);
			} else {

			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

	public void validateAndSaveMetaDataDetails(MetaDataDTO dto) {
		try {
			if (dto != null) {
				metaDataRepository.save(dto);
			} else {

			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

	public void validateAndSaveSubQueryDetails(SubQueryDetailsDTO dto) {
		try {
			if (dto != null) {
				subQueryDetailsRepository.save(dto);
			} else {

			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}

	}

}
