package com.hiring.trackr.dto;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "POSITION_DTL")
public class CreatePositionDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "pos_id")
	private int posId;
	@Column(name = "role_id")
	private int roleId;
	@Column(name = "tower_id")
	private int towerId;
	@Column(name = "domain_id")
	private int domainId;
	@Column(name = "user_id")
	private int userId;
	@Column(name = "prmry_skill_id")
	private int prmrySkillId;
	@Column(name = "scndry_skill_id")
	private int scndrySkillId;
	@Column(name = "year_exp")
	private int yearsOfExp;
	@Column(name = "loc_id")
	private int locId;
	@Column(name = "urgency_id")
	private int urgencyId;
	@Column(name = "hiring_type_id")
	private int hiringTypeId;
	@Column(name = "descr")
	private String description;

	@Column(name = "cmnts")
	private String comments;

	@Column(name = "file_attm")
	@Lob
	private Blob fileAttached;

	@Column(name = "updtd_by_user_id")
	private int updtdByUserId;
	@Column(name = "creatd_by_user_id")
	private int createdUserId;
	@Column(name = "updtd_dtm")
	private Date updtdUserDate;
	@Column(name = "creatd_dtm")
	private Date createdUserDate;

	public int getUpdtdByUserId() {
		return updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public int getCreatedUserId() {
		return createdUserId;
	}

	public void setCreatedUserId(int createdUserId) {
		this.createdUserId = createdUserId;
	}

	public CreatePositionDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getPosId() {
		return posId;
	}

	public void setPosId(int posId) {
		this.posId = posId;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public int getTowerId() {
		return towerId;
	}

	public void setTowerId(int towerId) {
		this.towerId = towerId;
	}

	public int getDomainId() {
		return domainId;
	}

	public void setDomainId(int domainId) {
		this.domainId = domainId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getPrmrySkillId() {
		return prmrySkillId;
	}

	public void setPrmrySkillId(int prmrySkillId) {
		this.prmrySkillId = prmrySkillId;
	}

	public int getScndrySkillId() {
		return scndrySkillId;
	}

	public void setScndrySkillId(int scndrySkillId) {
		this.scndrySkillId = scndrySkillId;
	}

	public int getYearsOfExp() {
		return yearsOfExp;
	}

	public void setYearsOfExp(int yearsOfExp) {
		this.yearsOfExp = yearsOfExp;
	}

	public int getLocId() {
		return locId;
	}

	public void setLocId(int locId) {
		this.locId = locId;
	}

	public int getUrgencyId() {
		return urgencyId;
	}

	public void setUrgencyId(int urgencyId) {
		this.urgencyId = urgencyId;
	}

	public int getHiringTypeId() {
		return hiringTypeId;
	}

	public void setHiringTypeId(int hiringTypeId) {
		this.hiringTypeId = hiringTypeId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getUpdtdUserDate() {
		return updtdUserDate;
	}

	public void setUpdtdUserDate(Date updtdUserDate) {
		this.updtdUserDate = updtdUserDate;
	}

	public Date getCreatedUserDate() {
		return createdUserDate;
	}

	public void setCreatedUserDate(Date createdUserDate) {
		this.createdUserDate = createdUserDate;
	}

}
