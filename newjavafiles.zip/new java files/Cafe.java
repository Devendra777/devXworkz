class Cafe {

    String name ; 
   String location;
   String timings;
  

public Cafe(){
this("Mysore Road");
cafeDetails();
System.out.println("Cafe construtor with zero parameters");
}


public Cafe(String location){

this("Meltin Cafe" , "6pm - 6am");
System.out.println("starting with Cafe construtor with one parameters");
cafeDetails();
this.location  = location;
cafeDetails();
System.out.println("ending with Cafe construtor with one parameters");
}


public Cafe(String name , String timings){
System.out.println("starting with Cafe construtor with two parameters");
cafeDetails();
this.name = name;
this.timings = timings;
cafeDetails();
System.out.println("ending with Cafe construtor with two parameters");
}


public void cafeDetails()
{
 System.out.println(this.name + "  " + this.location + "  "+ this.timings);

}

public static void party(){
System.out.println("Party with Freinds");
}


}