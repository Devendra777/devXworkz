package com.legato.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.legato.persistence.dto.JoinConditionsDetailsDTO;
import com.legato.persistence.repository.JoiningConditionRepository;

@Service
public class JoiningConditionService {

	@Autowired
	JoiningConditionRepository joiningConditionRepo;

	public JoiningConditionService() {
		// TODO Auto-generated constructor stub
	}

	public void validateAndSaveJoinConditions(JoinConditionsDetailsDTO dto) {
		// TODO Auto-generated method stub
		if (dto != null) {
			joiningConditionRepo.save(dto);
		}

	}

}
