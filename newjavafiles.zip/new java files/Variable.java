class Variable
{
public static void main(String a[])
{
     int a=890,890,890
}

}