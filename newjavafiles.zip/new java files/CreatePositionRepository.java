package com.hiring.trackr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hiring.trackr.dto.CreatePositionDTO;

public interface CreatePositionRepository extends JpaRepository<CreatePositionDTO, Integer>{

}
