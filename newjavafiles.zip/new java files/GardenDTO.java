public class GardenDTO
{
   private  String name;
  private  String address;
 public static  String type="government";

 public void setName(String nm)
{
       name=nm;
}
public   String getName()
{
return name;
}
public void setAddress(String add)
{
       address=add;
}
public   String getAddress()
{
return address;
}


}