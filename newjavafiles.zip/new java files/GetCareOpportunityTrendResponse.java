package com.wellpoint.pc2dash.service.careOpportunitiesTrending;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetCareOpportunityTrendResponse extends ActionResponse {

}
