class   Namskara{
public static void main(String a[])

{
 System.out.println("Any body can code in X-workz");
}
}