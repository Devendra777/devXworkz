package com.wellpoint.pc2dash.action.careOpportunitiesTrending;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.careOpportunities.GetCareOpportunityCurrentTrendAction;
import com.wellpoint.pc2dash.action.careOpportunities.GetCareOpportunityCurrentTrendRequest;
import com.wellpoint.pc2dash.action.careOpportunities.GetCareOpportunityCurrentTrendResponse;
import com.wellpoint.pc2dash.dto.careOpportunities.CareOppTrendBean;
import com.wellpoint.pc2dash.dto.careOpportunities.CareOppTrendRateBeanJson;
import com.wellpoint.pc2dash.dto.careOpportunities.CareOpportunitiesTrendBean;
import com.wellpoint.pc2dash.dto.careOpportunities.CareOpportunitiesTrendJson;
import com.wellpoint.pc2dash.dto.careOpportunities.TrendMetadata;
import com.wellpoint.pc2dash.dto.careOpportunities.TrendRateMetaData;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.CareOpportunitiesRateExport;
import com.wellpoint.pc2dash.export.population.CareOpportunitiesTrendViewRateExport;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.careOpportunitiesTrending.CareOpportunityTrendRateServiceImpl;
import com.wellpoint.pc2dash.service.careopportunities.CareopportunitiesTrendServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

import static com.wellpoint.pc2dash.util.Constants.DASHES;
import static com.wellpoint.pc2dash.util.Constants.SUCCESS_NO_DATA;
import static com.wellpoint.pc2dash.util.Constants.SUCCESSFUL;


public class GetCareOpportunityTrendRateAction extends Action{

	private static final String CARE_OPPS_TREND_RETURNED = "Care Opps Trend returned";
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetCareOpportunityTrendRateAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		ActionResponse response = new GetCareOpportunityCurrentTrendResponse();
		List<CareOpportunitiesTrendJson> trendList = null;
		List<CareOpportunitiesRateJson>	rateList = null;
		List<CareOpportunitiesTrendBean> resultList = null;
		List<CareOpportunitiesTrendBean> resultListPreviousYear = null;
		List<CareOpportunitiesTrendBean> resultListCurrentYear = null;

		String max_month = null;
		boolean previousyear = false;
		boolean currentyear = false;
		int lobvalue = 0;

		TrendMetadata metadata = new TrendMetadata();
		GetCareOpportunityCurrentTrendRequest request = (GetCareOpportunityCurrentTrendRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();

		List<String> filteredProvGrpList = new ArrayList<String>();
		CareOpportunityTrendRateServiceImpl service = new CareOpportunityTrendRateServiceImpl();

		try {
			removeLobPgmPrefixes(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			if (null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				filteredProvGrpList = filterProvGrpsByCmpScrtyLvl(request, filteredProvGrpList);
				request.setProvGrpIds(StringUtils.join(filteredProvGrpList, ','));
			}

			if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {

				request.setProvGrpIds(StringUtils.join(filteredProvGrpList, ','));
				request.setGrpInd(Constants.GRP_IND_N);

				lobvalue = request.getLobCtgryNm().split(",").length;
				String[] lobs = request.getLobCtgryNm().split(",");

				for (int i = 0; i <= lobs.length - 1; i++) {
					if (lobs[i].contentEquals(DASHES))
						lobvalue = lobvalue - 1;
				}

				max_month = service.getmaxdate();
				metadata = service.metadata(lobvalue, request);

				if (lobvalue == 1) {
					previousyear = true;
					resultListPreviousYear = service.getdata(request, max_month, lobvalue, previousyear, currentyear);
					previousyear = false;
					currentyear = true;
					resultListCurrentYear = service.getdata(request, max_month, lobvalue, previousyear, currentyear);
				} else if ((lobvalue >= 2)) {
					resultList = service.getdata(request, max_month, lobvalue, previousyear, currentyear);
				}
			}

			if ((null != resultList && !resultList.isEmpty())
					|| (null != resultListPreviousYear && !resultListPreviousYear.isEmpty()
							|| null != resultListCurrentYear && !resultListCurrentYear.isEmpty())) {

				if (lobvalue == 1) {
					trendList = service.SingleLOB(resultListPreviousYear, resultListCurrentYear, max_month,
							request.getLobCtgryNm(), request.getMeasureId(), request.getMeasureName());
					rateList = service.RateList(trendList, lobvalue);
					
				} else if (lobvalue >= 2) {
					trendList = service.MixedLOB(resultList, request.getLobCtgryNm(), request.getMeasureId(),
							request.getMeasureName(), max_month);
					rateList = service.RateList(trendList, lobvalue);
				}
				response.setData(trendList);
				response.setMessage(err.getProperty(SUCCESSFUL));
			} else {
				response.setMessage(err.getProperty(SUCCESS_NO_DATA));
			}
			logger.debug(CARE_OPPS_TREND_RETURNED);
			response.setMetaData(metadata);
			response.setSuccess(true);
			return response;
		} catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
