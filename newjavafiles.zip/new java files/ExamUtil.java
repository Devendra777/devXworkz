class ExamUtil{
public static void main(String a[]){
   Exam exam = new Exam();
   exam.code = "17EC81";
  exam.fees = 1999;

HallTicket hallTicket = new HallTicket("123ertcs",5,"NitinReddy");
    
boolean allowed = exam.allow(hallTicket);
if(allowed)
{
System.out.println("can write exam");
}
else{
System.out.println("cannot write exam");
}
  
     System.out.println("**********************************"); 
Exam  exam1 =  new SupplementaryExam (); 
boolean allowedForSupplementary  =  exam1.allow(hallTicket);
if(allowedForSupplementary){
System.out.println("can write Supplementary exam");
}
else{
System.out.println("cannot write Supplementary exam");
}
}
}