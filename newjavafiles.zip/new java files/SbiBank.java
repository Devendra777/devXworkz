class SbiBank extends Bank{

     public  String address=  "SanjeevNagar";
    public String ifscCode = "SBIN45674567";
   public int noOfBranches = 67;

@Override
public   Integer  giveLoanOnRateOfInterest(){

return 9;
}

public void displayDetails(){
System.out.println(this.address);
System.out.println(this.ifscCode);
System.out.println(noOfBranches);
}

}