class Movies{

public static void main(String a[]){

   String moviesName[]  ={"Roohi", "KGF2" , "Shershah"};
System.out.println(moviesName.length);

System.out.println(moviesName[0] + "   "+ moviesName[1] + "    "+ moviesName[2]);
}



}