package com.legato.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.legato.persistence.dao.AutomationDAO;
import com.legato.persistence.dto.EnvDTO;
import com.legato.persistence.dto.EnvironmentDetailsDTO;
import com.legato.persistence.dto.TableColumnsDTO;
import com.legato.persistence.dto.TableNameDTO;
import com.legato.web.view.request.RequestView;

@Service
public class AutomationService {

	@Autowired
	AutomationDAO automationDAO;
	
	public List<TableNameDTO> getAllStgTablesService(RequestView request)  { 
		List<TableNameDTO> list= automationDAO.getAllStgTablesDAO(request);
		return list;
	}
	public List<TableColumnsDTO> getStgTablesColumns(RequestView request)  { 
		List<TableColumnsDTO> list= automationDAO.getStgTablesColumnsDAO(request);
		return list;
	}
	public List<TableNameDTO> getStgSchemaService()  { 
		List<TableNameDTO> list= automationDAO.getStgSchemasDAO();
		return list;
	}
	
	public EnvironmentDetailsDTO getEnvDetails(RequestView request)  { 
		EnvironmentDetailsDTO envDetails= automationDAO.getEnvDetails(request);
		return envDetails;
	}
	

}
