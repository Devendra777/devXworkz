class OldMobile{

   String name ; 
  String modelNo;

public void doCall(){
System.out.println("calling from old mobile");
}
void sendMessage(){
System.out.println();
}

}