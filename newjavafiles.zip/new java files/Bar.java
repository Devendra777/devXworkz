class  Bar{

public static void main(String a[])
{
        String gstNo="AAAAA0000A1234566";
       String barName = "Navrang Bar";
 
        String address = "Rajajinagar";  
     int noOfBrands = 45;

    System.out.println(gstNo);
 System.out.println(barName);

 System.out.println(noOfBrands);
 System.out.println(address);
}



}