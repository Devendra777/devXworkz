class  LifesAmazingSecret   extends Novel{

public LifesAmazingSecret(){
System.out.println("lifesAmazingSecret object is created");
}
     
}









