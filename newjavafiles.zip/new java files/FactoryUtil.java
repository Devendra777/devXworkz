class FactoryUtil
{
public static void main(String a[])
{
FactoryDTO fact = new FactoryDTO();
System.out.println("               " +fact.getFactoryId());
   fact.setFactoryId(1);
System.out.println("               " +fact.getFactoryId());
}
}