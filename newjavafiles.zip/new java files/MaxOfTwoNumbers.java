class   MaxOfTwoNumbers
{
    public static void main(String a[])
{
int num1=34;
int num2=2;
int num3=90;
int num4=12;
findMaxValue(num1, num2);
findMaxValue(num3, num4);
}


static void findMaxValue(int num1, int num2)
{
   if(num1 > num2)
{
    System.out.println( "the greatest number is  : " + num1 );
}
else 
{
 System.out.println( "the greatest number is  : "  + num2);
}
}



static void findMaxValue(int num3, int num4)
{
   if(num3 > num4)
{
    System.out.println( "the greatest number is  : " + num3 );
}
else 
{
 System.out.println( "the greatest number is  : "  + num4);
}
}



}