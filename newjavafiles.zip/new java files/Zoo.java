class Zoo
{
public static void main(String a[])
{
String name="MysoreZoo";
String place=null;
  String value=   protectAnimals(name , place);
System.out.println(value);
}

static String protectAnimals(String name , String place)
{
if(place !=null)
{
  return place;
}
else{
return name;
}
}
}