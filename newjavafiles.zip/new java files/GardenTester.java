class GardenTester
{
   public static void main(String a[])
{
     GardenDTO dto = new GardenDTO();
     dto.setName("bharathi Garden");
   dto.setAddress("Jayanagar");
  
System.out.println( dto.getName() + " "
+ dto.getAddress() + " "+ GardenDTO.type );
}

}