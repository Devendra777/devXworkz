package com.legato.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.legato.persistence.dto.FilterConditionsDTO;

public interface FilterConditionRepository extends JpaRepository<FilterConditionsDTO, String>{
	

}
