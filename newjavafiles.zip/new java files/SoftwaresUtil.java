class SoftwareUtil{

 public static void main(String a[])
{
        Softwares ref  = new Softwares(45000,"autocaed","design",true);
        ref.printSoftwaresDetails();
      
     
}

}