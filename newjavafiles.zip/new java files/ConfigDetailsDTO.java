package com.legato.persistence.dto;

public class ConfigDetailsDTO {

	private String env;
	private String release;
	private String layer;
	private String audittDBschema;
	private String auditTablePassword; 
	private String auditTableDBDriver;
	private String credentialProviderURL;
	private String userName;
	private String password;
	private String srcformat;
	private String srcDbServerUrl;
	private String srcJdbcDriver;
	private String ancillarysrcformat;
	private String ancillarysrcdbserverurl;
	private String ancillarysrcjdbcdriver;
	private String tgtformat;
	private String tgtdbserverurl;
	private String tgtjdbcdriver;
	private String auditTable;
	private String rdsConfigPath;
	private String systemname;
	private String datasets;
	private String queryMap;
	
	
	
	public String getEnv() {
		return env;
	}
	public void setEnv(String env) {
		this.env = env;
	}
	public String getRelease() {
		return release;
	}
	public void setRelease(String release) {
		this.release = release;
	}
	public String getLayer() {
		return layer;
	}
	public void setLayer(String layer) {
		this.layer = layer;
	}
	public String getAudittDBschema() {
		return audittDBschema;
	}
	public void setAudittDBschema(String audittDBschema) {
		this.audittDBschema = audittDBschema;
	}
	public String getAuditTablePassword() {
		return auditTablePassword;
	}
	public void setAuditTablePassword(String auditTablePassword) {
		this.auditTablePassword = auditTablePassword;
	}
	public String getAuditTableDBDriver() {
		return auditTableDBDriver;
	}
	public void setAuditTableDBDriver(String auditTableDBDriver) {
		this.auditTableDBDriver = auditTableDBDriver;
	}
	public String getCredentialProviderURL() {
		return credentialProviderURL;
	}
	public void setCredentialProviderURL(String credentialProviderURL) {
		this.credentialProviderURL = credentialProviderURL;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSrcformat() {
		return srcformat;
	}
	public void setSrcformat(String srcformat) {
		this.srcformat = srcformat;
	}
	public String getSrcDbServerUrl() {
		return srcDbServerUrl;
	}
	public void setSrcDbServerUrl(String srcDbServerUrl) {
		this.srcDbServerUrl = srcDbServerUrl;
	}
	public String getSrcJdbcDriver() {
		return srcJdbcDriver;
	}
	public void setSrcJdbcDriver(String srcJdbcDriver) {
		this.srcJdbcDriver = srcJdbcDriver;
	}
	public String getAncillarysrcformat() {
		return ancillarysrcformat;
	}
	public void setAncillarysrcformat(String ancillarysrcformat) {
		this.ancillarysrcformat = ancillarysrcformat;
	}
	public String getAncillarysrcdbserverurl() {
		return ancillarysrcdbserverurl;
	}
	public void setAncillarysrcdbserverurl(String ancillarysrcdbserverurl) {
		this.ancillarysrcdbserverurl = ancillarysrcdbserverurl;
	}
	public String getAncillarysrcjdbcdriver() {
		return ancillarysrcjdbcdriver;
	}
	public void setAncillarysrcjdbcdriver(String ancillarysrcjdbcdriver) {
		this.ancillarysrcjdbcdriver = ancillarysrcjdbcdriver;
	}
	public String getTgtformat() {
		return tgtformat;
	}
	public void setTgtformat(String tgtformat) {
		this.tgtformat = tgtformat;
	}
	public String getTgtdbserverurl() {
		return tgtdbserverurl;
	}
	public void setTgtdbserverurl(String tgtdbserverurl) {
		this.tgtdbserverurl = tgtdbserverurl;
	}
	public String getTgtjdbcdriver() {
		return tgtjdbcdriver;
	}
	public void setTgtjdbcdriver(String tgtjdbcdriver) {
		this.tgtjdbcdriver = tgtjdbcdriver;
	}
	public String getAuditTable() {
		return auditTable;
	}
	public void setAuditTable(String auditTable) {
		this.auditTable = auditTable;
	}
	public String getRdsConfigPath() {
		return rdsConfigPath;
	}
	public void setRdsConfigPath(String rdsConfigPath) {
		this.rdsConfigPath = rdsConfigPath;
	}
	public String getSystemname() {
		return systemname;
	}
	public void setSystemname(String systemname) {
		this.systemname = systemname;
	}
	public String getDatasets() {
		return datasets;
	}
	public void setDatasets(String datasets) {
		this.datasets = datasets;
	}
	public String getQueryMap() {
		return queryMap;
	}
	public void setQueryMap(String queryMap) {
		this.queryMap = queryMap;
	}
	
	
	
	

}
