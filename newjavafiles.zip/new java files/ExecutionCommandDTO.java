package com.legato.persistence.dto;

public class ExecutionCommandDTO {

	private String serverPath;
	private String localPath;
	public String getServerPath() {
		return serverPath;
	}
	public void setServerPath(String serverPath) {
		this.serverPath = serverPath;
	}
	public String getLocalPath() {
		return localPath;
	}
	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}
	
	
}
