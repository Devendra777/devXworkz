package com.legato.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.legato.persistence.dto.SubQueryDetailsDTO;
import com.legato.persistence.repository.SubQueryDetailsRepository;

@Service
public class SubQueryDetailsService {

	@Autowired
	SubQueryDetailsRepository subQueryDetailsRepository;

	public SubQueryDetailsService() {
		// TODO Auto-generated constructor stub
	}



}
