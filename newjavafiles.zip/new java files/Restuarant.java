class  Restuarant
{
     String   id;
      String name;
     String address;

  public void eat()
{
System.out.println("eating schezwan noodles");
}

public static void main(String a[])
{
  Restuarant rs = new Restuarant();
      rs.id="DERT456";
      rs.name="Kadamba";
     rs.address="Malleshwaram";
System.out.println( rs.id + " "+ rs.name + " "+  rs.address)  ;


Restuarant rest = new Restuarant();
      rest.id="78R9";
      rest.name="Indrapashta";
    rest.address="Vijayanagar";
System.out.println( rest.id + " "+ rest.name + " "+  rest.address)  ;

  rs.eat();
}

}