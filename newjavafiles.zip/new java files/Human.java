class  Person{

public static void main(String a[]){
             String      humanName = "Baba Ramdev" ;
             int         age =  89;
            boolean         isAlive  = true;
               int             contactNo = 6786786789;
System.out.println(humanName);
System.out.println(age);
System.out.println(isAlive);
System.out.println(contactNo);

                }
}