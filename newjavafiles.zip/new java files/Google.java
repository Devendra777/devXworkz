abstract  class Google{

void connectDB(){
System.out.println("Connecting to Google DB");
System.out.println("verify email and password");
}

abstract  void sendMail();
}