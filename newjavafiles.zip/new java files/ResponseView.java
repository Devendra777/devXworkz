package com.anthem.aciisst.common.web.view;

/**
 * @author AG21260
 * ResponseView class is a Base response structure for all the responses that will be sent from MW team to UI team. 
 * @param <T>
 */
public class ResponseView<T> {
	/**
	 * status variable is used to indicate UI that if the request was processed successfully from MW team.
	 */
	private String status;
	/**
	 * statusDescription variable will be used to specify the description message for the response along with status 
	 */
	private String statusDescription;
    private T data;
    
    /**
     * return total number of records returned in the list
     */
    private long total;
    
	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	/**
	 * @return status 
	 * Returns status of the response, whether success or failure.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 * Sets the status of the response 
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return statusDescription
	 * Returns status description message based on response status.
	 */
	public String getStatusDescription() {
		return statusDescription;
	}

	/**
	 * @param statusDescription
	 * Sets the status description for the response.
	 */
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
   
 }
