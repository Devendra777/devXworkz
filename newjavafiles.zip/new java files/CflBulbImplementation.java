class CflBulbImplementation implements Switch{

@Override
 public void    sOn(){
System.out.println("Cfl Bulb is turned Onn");
}

@Override
  public void   sOff(){
System.out.println("Cfl Bulb is turned Off");
}


}