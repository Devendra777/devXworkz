class PlayGround
{
  String id;
  String  address;
 String  name;
  String   type;
 void   playing()
{
System.out.println("playing Cricket");

}

public static void main(String a[]){
      PlayGround pg = new PlayGround();

System.out.println(a[0] +" "+ a[1] + " "+ a[2]+ " "+a[3]);
pg.playing();

}

}