class  MiddleOfThreeNumber{


public static void main(String a[])
{
  

int  num1=12;
int num2=45;
int num3=90;
      midOfThreeNumber(num1, num2,num3);
}

}

}