class TheatreUtil{

public static void main(String a[]){
     
     Theatre th = new Theatre("Sangam" , " Mysore",true);

th.entertainment();
th.entertainment("Medium popcorn");

}



}