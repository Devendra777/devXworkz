class HP  extends Laptop{



}