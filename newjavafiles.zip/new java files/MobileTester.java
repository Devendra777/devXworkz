class MobileTester{


public static void main(String a[]){

      NewMobile b = new NewMobile();
     b.name = "Samsung-S21";
     b.modelNo = "sm-G991B/DS";
    b.doCall();
}
}