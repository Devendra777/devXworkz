package com.legato.persistence.dto;

public class TableColumnsDTO {
	private int  position;
	private String columnName;
	private String dataType;
	private int length;
	private int nullable;
	private String keySeq;
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getNullable() {
		return nullable;
	}
	public void setNullable(int nullable) {
		this.nullable = nullable;
	}
	public String getKeySeq() {
		return keySeq;
	}
	public void setKeySeq(String keySeq) {
		this.keySeq = keySeq;
	}
	
	
	
}
