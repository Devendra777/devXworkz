package com.legato.common.util;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;



public class StringUtil {

	private StringUtil() {

	}

	public static String buildPlaceholdersFromCommaSeparatedList(String list) {
		if (StringUtils.isEmpty(list)) {
			return "";
		} else if (list.contains(",")) {
			StringBuilder placeholders = new StringBuilder("");
			String[] array = list.split(",");
			for (int i = 0; i < array.length; i++) {
				placeholders.append(",?");
			}
			placeholders = placeholders.replace(0, 1, "");
			return placeholders.toString();
		}
		return "?";
	}
	
	public static String buildPlaceholdersFromList(List<String> list) {
		if (CollectionUtils.isEmpty(list)) {
			return "";
		} else {
			StringBuilder placeholders = new StringBuilder("");
			for (String item : list) {
				placeholders.append(",?");
			}
			placeholders = placeholders.replace(0, 1, "");
			return placeholders.toString();
		}
	}

	public static String buildCommaSeperatedStringFromList(List<String> stringList) {

		StringBuilder strBuilder = new StringBuilder("");
		if (!CollectionUtils.isEmpty(stringList)) {

			for (String str : stringList) {
				strBuilder.append(str).append(",");
			}
		}
		return strBuilder.length() > 2 ? strBuilder.substring(0, strBuilder.length() - 1) : strBuilder.toString();

	}
	
	public static String buildCommaSeperatedStringWithQuotesFromList(List<String> stringList) {

		StringBuilder strBuilder = new StringBuilder("");
		if (!CollectionUtils.isEmpty(stringList)) {

			for (String str : stringList) {
				strBuilder.append("'" + str.replace(",", "','") + "'").append(",");
			}
		}
		return strBuilder.length() > 2 ? strBuilder.substring(0, strBuilder.length() - 1) : strBuilder.toString();

	}
	
	public static String buildCommaSeperatedStringWithQuotesFromCBSAList(List<String> stringList) {

		StringBuilder strBuilder = new StringBuilder("");
		if (!CollectionUtils.isEmpty(stringList)) {

			for (String str : stringList) {
				strBuilder.append("'" + str + "'").append(",");
			}
		}
		return strBuilder.length() > 2 ? strBuilder.substring(0, strBuilder.length() - 1) : strBuilder.toString();

	}

	public static String buildCommaSpaceSeperatedStringFromList(List<String> stringList) {

		StringBuilder strBuilder = new StringBuilder("");
		if (!CollectionUtils.isEmpty(stringList)) {

			for (String str : stringList) {
				strBuilder.append(str).append(",").append(" ");
			}
		}
		return strBuilder.length() > 2 ? strBuilder.substring(0, strBuilder.length() - 2) : strBuilder.toString();

	}

	
	
	public static String checkForNullNA(String value) {
		if(value!=null) {
			return "NA".equalsIgnoreCase(value)?"":value;
		}else {
			return "";
		}
	}
	
	public static String validateStringForCarriageReturnsAndLineFeed(String inputValue){
		String outputValue = null;
		if(!StringUtils.isEmpty(inputValue)){
			outputValue = inputValue.replace('\n', '_').replace('\r', '_');
		}
		return outputValue;
	}
	
	public static String validateStringForAlphaNumeric(String txt) {

	    String regx = "(^[a-zA-Z0-9]{1,})$";//alpha-numeric 
	    Pattern pattern = Pattern.compile(regx);
	    Matcher matcher = pattern.matcher(txt);
	    matcher.find();
	    return matcher.group();

	}
	
	public static String validateStringForNumericOnly(String txt) {

	    String regx = "(^(\\+|-)?\\d{1,})$";//signed integer
	    Pattern pattern = Pattern.compile(regx);
	    Matcher matcher = pattern.matcher(txt);
	    matcher.find();
	    return matcher.group();

	}
	
	public static String validateStringForAlphaNumericHyphen(String txt) {

	    String regx = "(^[a-zA-Z0-9\\-]{1,})$";//alpha-numeric-hyphen
	    Pattern pattern = Pattern.compile(regx);
	    Matcher matcher = pattern.matcher(txt);
	    matcher.find();
	    return matcher.group();

	}
	
	public static String addSingleQuotesForEachCommaseparatedValue(String value){

		return "'" + value.replace(",", "','") + "'";
	}
	
	public static String addSingleQuotesForEachCommaseparatedListValue(List<Integer> value){
		List<String> key = new ArrayList<String>();
		for(Integer i: value) {
			key.add("'" + i + "'");
		}
		
		return  key.toString() ;
	}
	
	public static String addSingleQuotesForValue(String value){

		return "'" + value + "'";
	}
	
	public static String addSingleDoubleQuotesForEachCommaseparatedValue(String value){

		return "''" + value.replace(",", "'',''") + "''";
		
	}
	
	public static String addSingleQuotesforListValue(List<Integer> value){
		return "'" + value + "'";
		
	}

	public static String addDoubleQuotesForValue(String value){

		return "\"" + value + "\"";
	}
	public static String getPhysicalFileName(String exportId, String fileType) {
		/*
		 * Parse physical file name to ensure expected format.
		 */
		Pattern p = Pattern.compile("(^[a-zA-Z0-9_-]{1,})(\\.)(xlsx|xls|pdf|txt|csv)$");
		Matcher m = p.matcher(exportId + "." + fileType);
		m.find();

		return m.group(1) + m.group(2) + m.group(3);
	}

	public static Double checkNullForDouble(Object CellValue) {
		if (CellValue != null) {
			return Double.valueOf(CellValue.toString());
		}
		return Double.valueOf(0);
	}
	
}
