class  Cricket
{
    public static void main(String a[])
{
System.out.println("Sachin is a god of cricket");
System.out.println("India made an History in Gabba");
}
}
