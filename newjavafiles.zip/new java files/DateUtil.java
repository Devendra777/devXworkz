package com.legato.common.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	
	static Calendar myCalendar = Calendar.getInstance();
	static DateFormat YYYYMMDD_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	
	private DateUtil(){
		
	}
	
	public static Timestamp getCurrentTimestamp(){
		Calendar calendar = Calendar.getInstance();
		Timestamp currentTimestamp = new Timestamp(calendar.getTime().getTime());
		
		return currentTimestamp;
	}
	
	public static java.sql.Date getCurrentDate(){
		return new java.sql.Date(new Date().getTime());
	}
	
}
