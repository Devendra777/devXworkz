package com.legato.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.common.web.view.ResponseView;
import com.legato.common.constants.Constants;
import com.legato.persistence.dao.AbstractDAO;
import com.legato.persistence.dto.EnvDTO;
import com.legato.persistence.dto.JoinConditionsDetailsDTO;
import com.legato.web.service.EnvironementService;
import com.legato.web.service.JoiningConditionService;


@CrossOrigin
@RestController
@RequestMapping("/")
public class JoiningConditionController extends AbstractDAO{
	
	@Autowired
	JoiningConditionService joiningConditionService;
	
	public JoiningConditionController() {
		// TODO Auto-generated constructor stub
	}


	@RequestMapping(method = RequestMethod.POST, value = "/joiningConditions")
	public  ResponseView<JoinConditionsDetailsDTO> createJoinConditions(@RequestBody(required = false) JoinConditionsDetailsDTO  dto,HttpServletRequest httpRequest) {
	 
	 ResponseView<JoinConditionsDetailsDTO> responseView = new ResponseView<>();
	 try { 
		 joiningConditionService.validateAndSaveJoinConditions(dto);
	          
	          responseView.setData(dto);
	 		 responseView.setTotal(1);
	 		 responseView.setStatus(Constants.RESPONSE_SUCCESS);
	 		 responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
	 	 }catch(Exception e) {
	 		 responseView.setStatus(Constants.RESPONSE_FAILURE);
	 		 responseView.setStatusDescription(e.getMessage());
	 	 }
	 	  return responseView;
	 	}
}
