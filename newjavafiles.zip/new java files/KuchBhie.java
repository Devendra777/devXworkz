class  KuchBhie{
 

public static void main(String dev[]){
System.out.println("Missing Prerana");
}

}