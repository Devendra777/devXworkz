class Candy
{
public static void main(String a[])
{

eat(7);
eat("Best Friend");

}

public static void eat(int noOfCandy){
System.out.println("Eating " + noOfCandy + " candies alone");

}

public  static void eat(String   friends ){
	
System.out.println("Eating candy with " +friends);

}





}