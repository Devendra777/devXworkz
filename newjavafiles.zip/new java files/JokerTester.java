class JokerTester
{

    public static void main(String a[])
{
   JokerDTO joker= new JokerDTO("Baba","JPNagar",9187561304L);
   System.out.println(joker.getName() + " "+ joker.getAddress()
        + " "+ joker.getMobileNo());
    
}
}