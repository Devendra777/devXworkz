package com.wellpoint.pc2dash.service.stars;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.wellpoint.pc2dash.action.stars.GetPCVCompletionRequest;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dao.AbstractDao;
import com.wellpoint.pc2dash.dto.stars.PCVCompletionJson;
import com.wellpoint.pc2dash.exception.PC2Exception;




public class PCVCompletionServiceImpl extends AbstractDao{

	
	
	public List<PCVCompletionJson> getPCVTicker(GetPCVCompletionRequest request) throws PC2Exception {
		List<PCVCompletionJson> results = new ArrayList<PCVCompletionJson>();

		

		try {
			getPCVTickers(request);
		}
		catch (Exception e) {
			throw new PC2Exception( "Exception during PCVCompletionTickersServiceImpl " + request.toString(), e);
		}
		finally {
			close();
		}

		return results;
}	
	

public List<PCVCompletionJson> getPCVTickers(GetPCVCompletionRequest request) throws SQLException {
		
		List<PCVCompletionJson> results= new ArrayList<PCVCompletionJson>();
		
		PCVCompletionJson pcv = new PCVCompletionJson();
		pcv.setMeasure("PCV Completion");
		pcv.setValue("32");
		pcv.setMinGoal("68");
		pcv.setMaxGoal("75");

		
		results.add(pcv);
		
		return results;
	}
	@Override
	public boolean read(Dto o) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public void insert(Dto o) throws Exception {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void update(Dto o) throws Exception {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void delete(Dto o) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
