class Airport{

   String airportName;
   int noOfTerminals;
   String departure;
  String arrival;
public static void main(String a[])
{
     Airport airport = new Airport();
    airport . airportName = "Kempegowda International Airport";
    airport. noOfTerminals = 32;
    airport. departure = "bangalore";
    airport .arrival= "Dubai";
System.out.println(airport . airportName + " "+  airport. noOfTerminals + " "+
airport. departure  + "  "+ airport . arrival );
  airport.checking();
}

void checking()
{
 System.out.println("checking the passengers");
}

}