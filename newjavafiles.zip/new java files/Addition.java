class   Addition{
public static void add(int a  , int b) 
{
 int c  = a+b;
System.out.println(c);
}

 static void add(int a,int b ){
  int c  = a+b+d;
System.out.println(c);
}



public static void main(String a[])
{
         add(67,76);  
     add(689,767);
   add(675,76);
   add(689,71); 
add(45,78,89);
}
}