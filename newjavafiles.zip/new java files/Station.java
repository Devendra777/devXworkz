class Station
{
   static String address="Malayalam";
  static   String platforms[] ={"platform1","platform2",
"platform3","platform4" , "platform5","platform6" ,
"platform7","platform8"};
public static void main(String a[])
{
System.out.println(platforms.length);
            getPlatforms();
}


 static void getPlatforms()
{
    for(int i=0;i< platforms.length;i++)
{
System.out.println(platforms[i]);
}
}
}