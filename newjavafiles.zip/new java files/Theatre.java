class Theatre{

String name;
String location ;
boolean isBookingAvailable;
int totalNoOfSeats;
int noOfScreens;
int showsPerDay;

public Theatre(){
System.out.println("Theatre with zero parameters");
}

public Theatre(int totalNoOfSeats,int noOfScreens, int showsPerDay){
this();
System.out.println("Theatre with three parameters");
this.totalNoOfSeats = totalNoOfSeats;
this.noOfScreens = noOfScreens;
this.showsPerDay = showsPerDay;

}

public Theatre(String name , String location , boolean isBookingAvailable ){
 this(961,1,4);

System.out.println("Theatre  with parameters");
    this.name =name ;
   this.location = location;
this.isBookingAvailable = isBookingAvailable;

System.out.println(this.name + "   "+ this.location + "  "+ this.isBookingAvailable + "  "   
+ this.totalNoOfSeats  +"   "+ this.noOfScreens +  "  "+ this.showsPerDay) ;
}


public  void entertainment(){
     System.out.println("Entertainment... Entertainment and Entertainment");

}

public void entertainment(String popcorn){
System.out.println("Enjoying with freinds with "+ popcorn);

}

}