class MidMobile extends OldMobile{


public void doCall(){
System.out.println("calling from mid mobile");
}

       void music(){

}
}