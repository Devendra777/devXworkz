package com.legato.persistence.repository;
/**
 * 
 */


import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author AF48929
 *
 */
public interface UserRepository extends JpaRepository<Integer, Integer> {

	
	
}
