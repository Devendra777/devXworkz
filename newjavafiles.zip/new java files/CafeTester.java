class CafeTester
{

public static void main(String a[])
{
  Object cafe = new Cafe();
  cafe.party();
}


}