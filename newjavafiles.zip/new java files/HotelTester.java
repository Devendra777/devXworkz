class HotelTester
{
  public static void main(String a[])
{
    HotelDTO dto = new HotelDTO();
           dto.setName("Sapthagiri");
           dto.setAddress("Rajajinagar"); 
          
           System.out.println(HotelDTO.getName() + " "+ HotelDTO.getAddress()+ " "+ dto.type);

}

}