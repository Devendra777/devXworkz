class MyProg
{

public static void main(String a[]){
char ch[] = new char[100];
System.out.println(ch[50]);
}
}