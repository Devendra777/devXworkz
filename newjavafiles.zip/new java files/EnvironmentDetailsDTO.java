package com.legato.persistence.dto;

public class EnvironmentDetailsDTO {

	private String tgtDBSF;
	private String tgtTableName;
	private String primaryKeyColumns;
	private String query;
	private String srcDBTeradata; 
	private String tgtDBHadoop;
	private String awsS3InboundFilePath;
	private String hadoopSQLFile;
	private String hadoopConfFile;
	private String numberOfBigTablePartition;
	private String partitionColumnName;
	private String informaticaWorkflowLoadingDB2STGtable;
	private String informaticaMappingUNIXScriptName;
	
	
	public String getTgtDBSF() {
		return tgtDBSF;
	}
	public void setTgtDBSF(String tgtDBSF) {
		this.tgtDBSF = tgtDBSF;
	}
	public String getTgtTableName() {
		return tgtTableName;
	}
	public void setTgtTableName(String tgtTableName) {
		this.tgtTableName = tgtTableName;
	}
	public String getPrimaryKeyColumns() {
		return primaryKeyColumns;
	}
	public void setPrimaryKeyColumns(String primaryKeyColumns) {
		this.primaryKeyColumns = primaryKeyColumns;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSrcDBTeradata() {
		return srcDBTeradata;
	}
	public void setSrcDBTeradata(String srcDBTeradata) {
		this.srcDBTeradata = srcDBTeradata;
	}
	public String getTgtDBHadoop() {
		return tgtDBHadoop;
	}
	public void setTgtDBHadoop(String tgtDBHadoop) {
		this.tgtDBHadoop = tgtDBHadoop;
	}
	public String getAwsS3InboundFilePath() {
		return awsS3InboundFilePath;
	}
	public void setAwsS3InboundFilePath(String awsS3InboundFilePath) {
		this.awsS3InboundFilePath = awsS3InboundFilePath;
	}
	public String getHadoopSQLFile() {
		return hadoopSQLFile;
	}
	public void setHadoopSQLFile(String hadoopSQLFile) {
		this.hadoopSQLFile = hadoopSQLFile;
	}
	public String getHadoopConfFile() {
		return hadoopConfFile;
	}
	public void setHadoopConfFile(String hadoopConfFile) {
		this.hadoopConfFile = hadoopConfFile;
	}
	public String getNumberOfBigTablePartition() {
		return numberOfBigTablePartition;
	}
	public void setNumberOfBigTablePartition(String numberOfBigTablePartition) {
		this.numberOfBigTablePartition = numberOfBigTablePartition;
	}
	public String getPartitionColumnName() {
		return partitionColumnName;
	}
	public void setPartitionColumnName(String partitionColumnName) {
		this.partitionColumnName = partitionColumnName;
	}
	public String getInformaticaWorkflowLoadingDB2STGtable() {
		return informaticaWorkflowLoadingDB2STGtable;
	}
	public void setInformaticaWorkflowLoadingDB2STGtable(String informaticaWorkflowLoadingDB2STGtable) {
		this.informaticaWorkflowLoadingDB2STGtable = informaticaWorkflowLoadingDB2STGtable;
	}
	public String getInformaticaMappingUNIXScriptName() {
		return informaticaMappingUNIXScriptName;
	}
	public void setInformaticaMappingUNIXScriptName(String informaticaMappingUNIXScriptName) {
		this.informaticaMappingUNIXScriptName = informaticaMappingUNIXScriptName;
	}
	
	
	

}
