package com.legato.reports.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.legato.common.constants.Constants;
import com.legato.common.util.StringUtil;
import com.legato.persistence.dto.UserExportDTO;

@Component
public class ExportFileHelper {
	@Value("${export.path}")
	private String exportPath;

	/**
	 * This metod will write the file (Excel/CSV/PDF) in specified location
	 * 
	 * @param dataByte
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	public String writeFile(byte[] dataByte, String fileName, String fileType) throws IOException {

		String path = exportPath + getPhysicalFileName(fileName, fileType);
		
		try (FileOutputStream out = new FileOutputStream(path)) {
			out.write(dataByte);
			out.flush();
		} catch (IOException e) {
				throw new IOException(e);
		}

		return Constants.COMPLETED;
	}

	/**
	 * @param userExport
	 * @param response
	 * @return
	 * @throws IOException
	 */
	public boolean readFile(UserExportDTO userExport, HttpServletResponse response) throws IOException {
		boolean status = false;
		/* For LND report the completed status should be EXCELCOMPLETED */
		String completedStatus = userExport.getExtractTypeCd().equals(Constants.LND_APPLICATION_CODE)
				? Constants.EXCELCOMPLETED
				: Constants.COMPLETED;
		if (userExport!=null && completedStatus.equalsIgnoreCase(userExport.getSttsCd())) {
			String fileDirPath = StringUtils.isEmpty(userExport.getFilePathTxt())
					|| userExport.getFilePathTxt().equalsIgnoreCase(Constants.NA)
							? Constants.EMPTY_BLANK_STRING
							: StringUtil.validateStringForCarriageReturnsAndLineFeed(userExport.getFilePathTxt());
			String path = exportPath + fileDirPath + getPhysicalFileName(userExport.getExprtId(), userExport.getFileTypeCd());
			String fileName = StringUtil.validateStringForCarriageReturnsAndLineFeed(userExport.getFileNm());
			String filteTypeCd = StringUtil.validateStringForCarriageReturnsAndLineFeed(userExport.getFileTypeCd());
			
			if(!StringUtils.isEmpty(fileName)){
				fileName = fileName.trim();
			}
			if(!StringUtils.isEmpty(filteTypeCd)){
				filteTypeCd = filteTypeCd.trim();
			}
			fileName = fileName + "." + filteTypeCd;
			byte[] bytes = new byte[4096];
			
			ESAPI.httpUtilities().setHeader(response,"Content-Disposition", "attachment; filename=\"" + fileName + "\"");
			//Below code can be updated to fetch file content type from DB table FILE_CNTN_TYPE.
			if (userExport.getFileTypeCd().trim().equalsIgnoreCase(Constants.PDF)) {
				response.setHeader("Content-Type", Constants.PDF_MEDIA_TYPE);
			} else if (userExport.getFileTypeCd().trim().equalsIgnoreCase(Constants.EXCEL_XTN)) {
				response.setHeader("Content-Type", Constants.EXCEL_MEDIA_TYPE);
			} else if (userExport.getFileTypeCd().trim().equalsIgnoreCase(Constants.CSV_XTN)) {
				response.setHeader("Content-Type", Constants.CSV_MEDIA_TYPE);
			} else if (userExport.getFileTypeCd().trim().equalsIgnoreCase(Constants.EXCELX_XTN)) {
				response.setHeader("Content-Type", Constants.EXCELX_MEDIA_TYPE);
			}
			 else if (userExport.getFileTypeCd().trim().equalsIgnoreCase(Constants.CONF)) {
					response.setHeader("Content-Type", Constants.EXCELX_MEDIA_TYPE);
				}
			 else if (userExport.getFileTypeCd().trim().equalsIgnoreCase(Constants.LST)) {
					response.setHeader("Content-Type", Constants.EXCELX_MEDIA_TYPE);
				}

			File file = null;
			ServletOutputStream os = null;
			file = new File(path);
			os = response.getOutputStream();

			try (InputStream is = new FileInputStream(file)) {
				int c = 0;

				while ((c = is.read(bytes, 0, bytes.length)) > 0) {
					os.write(bytes, 0, c);
					os.flush();
				}
				os.close();

				status = true;
			}

		}

		return status;
	}

	/**
	 * @param path
	 * @throws IOException
	 */
	// Delete the file after download
	public void cleanUp(Path path) throws IOException {
		Files.delete(path);
	}

	public String getPhysicalFileName(String exportId, String fileType) {

		/*
		 * Parse physical file name to ensure expected format.
		 */
		Pattern p = Pattern.compile("(^[a-zA-Z0-9_-]{1,})(\\.)(xlsx|xls|pdf|txt|sql|csv|conf|lst)$");
		Matcher m = p.matcher(exportId + "." + fileType);
		m.find();

		return m.group(1) + m.group(2) + m.group(3);
	}
}
