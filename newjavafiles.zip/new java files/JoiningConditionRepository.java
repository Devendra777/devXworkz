package com.legato.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.legato.persistence.dto.JoinConditionsDetailsDTO;

public interface JoiningConditionRepository extends JpaRepository<JoinConditionsDetailsDTO, String>{

}
