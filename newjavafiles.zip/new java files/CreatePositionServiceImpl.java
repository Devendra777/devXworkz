package com.hiring.trackr.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hiring.trackr.dto.CreatePositionDTO;
import com.hiring.trackr.repository.CreatePositionRepository;

@Service
public class CreatePositionServiceImpl implements CreatePositionService {

	@Autowired
	private CreatePositionRepository repo;

	@Override
	public void savePosition(CreatePositionDTO createPositionDTO) {

		repo.save(createPositionDTO);
	}

	//getting a specific record  
	public CreatePositionDTO getPositionById(int id)   
	{  
	return repo.findById(id).get();  
	}  

}
