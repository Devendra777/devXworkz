class CivilEngineer extends Engineer{
 
Constants branch = Constants.CIVIL;


public CivilEngineer (){
super();
}

@Override
public void problemSolving(){
System.out.println("invoked problemSolving() of Civil Engineer");
System.out.println("problem solved by "+ this.branch);
}


public void constructs(){
System.out.println("Developing Country");
}

public Constants getBranch(){
return branch;
}

public Constants getParentBranch(){
return super.branch;
}


}