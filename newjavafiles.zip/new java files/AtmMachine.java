class AtmMachine{

void slot(Atm a)
{
a.connectBankDB();
}
}