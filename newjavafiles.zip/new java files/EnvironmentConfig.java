package com.legato.migration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.legato.persistence.dto.EnvironmentDetailsDTO;
import com.legato.web.view.request.RequestView;

@Configuration
@Profile("env")
@PropertySource("file:/C:/GIT/InternalAutomation/InternalAutomation/src/main/resources/environmentConfiguration.properties")
public class EnvironmentConfig {
	 @Autowired
	    Environment env;

	public EnvironmentDetailsDTO getEnvDetails(RequestView request){
		EnvironmentDetailsDTO envDetails = new EnvironmentDetailsDTO();
		try{
		envDetails.setTgtDBSF(env.getProperty("sf.sit.servername"));
		envDetails.setTgtTableName("abc_stg"); // need to get it from request
		envDetails.setPrimaryKeyColumns(null);
		envDetails.setQuery(null);
		envDetails.setSrcDBTeradata(env.getProperty("teradata.sit.db"));
		envDetails.setTgtDBHadoop(env.getProperty("hadoop.sit.stgdb"));
		envDetails.setAwsS3InboundFilePath(env.getProperty("aws.incr.etl"));
		envDetails.setHadoopSQLFile("abc_stg.sql");// need to check
		envDetails.setHadoopConfFile(null);// need to check
		envDetails.setNumberOfBigTablePartition(null);
		envDetails.setPartitionColumnName(null);
		envDetails.setInformaticaWorkflowLoadingDB2STGtable(null);
		envDetails.setAwsS3InboundFilePath(null);
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return envDetails;
		
	}	

}
