package com.legato.persistence.dto;

public class VulcanMetaDataDTO {

	private String appCode;
	private String dbType;
	private String srcSystemName;
	private String catalogName;
	private String schemaName;
	private String srcTableName;
	private String srcClaimListFile;
	private String deltaTableName;
	private String deltaTableClaim;
	private String deleteTableName;
	private String deleteTableClaim;
	private String hdfsDeltaTablePath;
	private String hdfcDeleteTablePath;
	private String destS3ObjectKey;
	private String destS3BucketName;
	private String destTypeDesc;
	private String tptInstCount;
	private String targetTableRefresh;
	private String reqId;
	private String ownershipTeam;
	public String getAppCode() {
		return appCode;
	}
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	public String getDbType() {
		return dbType;
	}
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}
	public String getSrcSystemName() {
		return srcSystemName;
	}
	public void setSrcSystemName(String srcSystemName) {
		this.srcSystemName = srcSystemName;
	}
	public String getCatalogName() {
		return catalogName;
	}
	public void setCatalogName(String catalogName) {
		this.catalogName = catalogName;
	}
	public String getSchemaName() {
		return schemaName;
	}
	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}
	public String getSrcTableName() {
		return srcTableName;
	}
	public void setSrcTableName(String srcTableName) {
		this.srcTableName = srcTableName;
	}
	public String getSrcClaimListFile() {
		return srcClaimListFile;
	}
	public void setSrcClaimListFile(String srcClaimListFile) {
		this.srcClaimListFile = srcClaimListFile;
	}
	public String getDeltaTableName() {
		return deltaTableName;
	}
	public void setDeltaTableName(String deltaTableName) {
		this.deltaTableName = deltaTableName;
	}
	public String getDeltaTableClaim() {
		return deltaTableClaim;
	}
	public void setDeltaTableClaim(String deltaTableClaim) {
		this.deltaTableClaim = deltaTableClaim;
	}
	public String getDeleteTableName() {
		return deleteTableName;
	}
	public void setDeleteTableName(String deleteTableName) {
		this.deleteTableName = deleteTableName;
	}
	public String getDeleteTableClaim() {
		return deleteTableClaim;
	}
	public void setDeleteTableClaim(String deleteTableClaim) {
		this.deleteTableClaim = deleteTableClaim;
	}
	public String getHdfsDeltaTablePath() {
		return hdfsDeltaTablePath;
	}
	public void setHdfsDeltaTablePath(String hdfsDeltaTablePath) {
		this.hdfsDeltaTablePath = hdfsDeltaTablePath;
	}
	public String getHdfcDeleteTablePath() {
		return hdfcDeleteTablePath;
	}
	public void setHdfcDeleteTablePath(String hdfcDeleteTablePath) {
		this.hdfcDeleteTablePath = hdfcDeleteTablePath;
	}
	
	public String getDestS3ObjectKey() {
		return destS3ObjectKey;
	}
	public void setDestS3ObjectKey(String destS3ObjectKey) {
		this.destS3ObjectKey = destS3ObjectKey;
	}
	public String getDestS3BucketName() {
		return destS3BucketName;
	}
	public void setDestS3BucketName(String destS3BucketName) {
		this.destS3BucketName = destS3BucketName;
	}
	public String getDestTypeDesc() {
		return destTypeDesc;
	}
	public void setDestTypeDesc(String destTypeDesc) {
		this.destTypeDesc = destTypeDesc;
	}
	public String getTptInstCount() {
		return tptInstCount;
	}
	public void setTptInstCount(String tptInstCount) {
		this.tptInstCount = tptInstCount;
	}
	public String getTargetTableRefresh() {
		return targetTableRefresh;
	}
	public void setTargetTableRefresh(String targetTableRefresh) {
		this.targetTableRefresh = targetTableRefresh;
	}
	public String getReqId() {
		return reqId;
	}
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}
	public String getOwnershipTeam() {
		return ownershipTeam;
	}
	public void setOwnershipTeam(String ownershipTeam) {
		this.ownershipTeam = ownershipTeam;
	}
	
	
}
