class Movie{
static String movieName ="ChiChore";
 static int noOfCharactors = 8;
static  String directorName= "Tiwari" ; 
 static String storyType =  "Drama" ; 
 static String duration = "130mins";
static  int noOfSongs =  5;
static char movieType = 'A' +'B';

public static void main(String a[]){
 
System.out.println(movieName);
System.out.println(noOfCharactors);
System.out.println(noOfSongs);
System.out.println(storyType);
System.out.println(directorName);
System.out.println(duration);
System.out.println(movieType);
}


}