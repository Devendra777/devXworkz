class WaterFalls{
 
  static String name = "niagara";
 static   String location= "America";
static    int height = 7000;

public static String provideElectricity(){

System.out.println("Water Falls name is " + name  + " Enjoyyyyyyy");
return "Providng electricity to the surrounding village";
}

public static void main(String a[]){
 String electricity =  provideElectricity(); 
System.out.println(electricity);
System.out.println(name);

}


}