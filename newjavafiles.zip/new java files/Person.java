class  Person{
static    String humanName ;
  static    int age ;
static    long contactNo  ;

public static void main(String a[]){
  humanName = "Dev";
System.out.println(humanName);
System.out.println(age);
System.out.println(contactNo);
}

}