class  Dell extends Laptop{

         
}