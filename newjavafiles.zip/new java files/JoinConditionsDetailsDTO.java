package com.legato.persistence.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "join_condtn_dtl")
public class JoinConditionsDetailsDTO {

	public JoinConditionsDetailsDTO() {
		// TODO Auto-generated constructor stub
	}

	@Id
	@Column(name = "tbl_nm")
	private String tblName;
	@Id
	@Column(name = "prmry_join_type")
	private String prmryJoinType;
	@Column(name = "src_tbl_nm")
	private String srcTableName;
	@Column(name = "tbl_alias")
	private String tblAlias;
	@Column(name = "join_condtn_txt")
	private String joinConditionText;
	
	public String getTblName() {
		return tblName;
	}
	public void setTblName(String tblName) {
		this.tblName = tblName;
	}
	public String getPrmryJoinType() {
		return prmryJoinType;
	}
	public void setPrmryJoinType(String prmryJoinType) {
		this.prmryJoinType = prmryJoinType;
	}
	public String getSrcTableName() {
		return srcTableName;
	}
	public void setSrcTableName(String srcTableName) {
		this.srcTableName = srcTableName;
	}
	public String getTblAlias() {
		return tblAlias;
	}
	public void setTblAlias(String tblAlias) {
		this.tblAlias = tblAlias;
	}
	public String getJoinConditionText() {
		return joinConditionText;
	}
	public void setJoinConditionText(String joinConditionText) {
		this.joinConditionText = joinConditionText;
	}
}
