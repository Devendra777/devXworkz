package com.legato.migration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternalAutomationApplicationTests {

	@Test
	void contextLoads() {
	}

}
