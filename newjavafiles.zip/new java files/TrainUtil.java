class TrainUtil{

static {
System.out.println("executing trainUtil");
}

public static void main (String a[])

{
System.out.println("main method started");
Train.carryingPassengers(); 
System.out.println("main method ended");
}
}