package com.legato.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.legato.persistence.dao.MetaDataDAO;
import com.legato.persistence.dto.MetaDataDTO;
import com.legato.persistence.repository.MetaDataRepository;

@Service
public class MetaDataService {
	
	

	@Autowired
	MetaDataRepository metaDataRepo;
	
	public MetaDataService() {
		// TODO Auto-generated constructor stub
	}
	


	public void validateAndSaveMetaDataDetails(MetaDataDTO dto) {
		// TODO Auto-generated method stub
		if(dto != null)
		{
			metaDataDAO.s	
		}
		
	}
	
	
	

}
