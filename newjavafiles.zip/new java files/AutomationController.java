package com.legato.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.common.web.view.ResponseView;
import com.legato.common.constants.Constants;
import com.legato.persistence.dao.AbstractDAO;
import com.legato.persistence.dto.EnvDTO;
import com.legato.persistence.dto.EnvironmentDetailsDTO;
import com.legato.persistence.dto.TableColumnsDTO;
import com.legato.persistence.dto.TableNameDTO;
import com.legato.web.service.AutomationService;
import com.legato.web.view.request.RequestView;

@CrossOrigin
@RestController
@RequestMapping("automation")
public class AutomationController  extends AbstractDAO {

	@Autowired
	AutomationService automationService;
	
	public AutomationController() {

	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/getAllSTGTables")
	public ResponseView<List<TableNameDTO>> getStgAllTables(@RequestBody(required = false) RequestView  request,HttpServletRequest httpRequest) {
	 List<TableNameDTO> list = new ArrayList<>();
	 ResponseView<List<TableNameDTO>> responseView = new ResponseView<>();
	 try { 
		 list = automationService.getAllStgTablesService(request);
		 responseView.setData(list);
		 responseView.setTotal(list.size());
		 responseView.setStatus(Constants.RESPONSE_SUCCESS);
		 responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
	 }catch(Exception e) {
		 responseView.setStatus(Constants.RESPONSE_FAILURE);
		 responseView.setStatusDescription(e.getMessage());
	 }
	  return responseView;
	}
	@RequestMapping(method = RequestMethod.POST, value = "/getColumnNames")
	public ResponseView<List<TableColumnsDTO>> getStgTablesColumns(@RequestBody(required = false) RequestView  request,HttpServletRequest httpRequest) {
	 List<TableColumnsDTO> list = new ArrayList<>();
	 ResponseView<List<TableColumnsDTO>> responseView = new ResponseView<>();
	 try { 
		 list = automationService.getStgTablesColumns(request);
		 responseView.setData(list);
		 responseView.setTotal(list.size());
		 responseView.setStatus(Constants.RESPONSE_SUCCESS);
		 responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
	 }catch(Exception e) {
		 responseView.setStatus(Constants.RESPONSE_FAILURE);
		 responseView.setStatusDescription(e.getMessage());
	 }
	  return responseView;
	}
	@RequestMapping(method = RequestMethod.POST, value = "/getAllSTGSchemas")
	public ResponseView<List<TableNameDTO>> getStgSchemas(HttpServletRequest httpRequest) {
	 List<TableNameDTO> list = new ArrayList<>();
	 ResponseView<List<TableNameDTO>> responseView = new ResponseView<>();
	 try { 
		 list = automationService.getStgSchemaService();
		 responseView.setData(list);
		 responseView.setTotal(list.size());
		 responseView.setStatus(Constants.RESPONSE_SUCCESS);
		 responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
	 }catch(Exception e) {
		 responseView.setStatus(Constants.RESPONSE_FAILURE);
		 responseView.setStatusDescription(e.getMessage());
	 }
	  return responseView;
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/getEnvInfo")
	public ResponseView<EnvironmentDetailsDTO> getEnvironmentDetails(@RequestBody(required = false)  RequestView  request,HttpServletRequest httpRequest) {
	 EnvironmentDetailsDTO envDetails = new EnvironmentDetailsDTO();
	 ResponseView<EnvironmentDetailsDTO> responseView = new ResponseView<>();
	 try { 
		 envDetails = automationService.getEnvDetails(request);
		 responseView.setData(envDetails);
		 responseView.setTotal(1);
		 responseView.setStatus(Constants.RESPONSE_SUCCESS);
		 responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
	 }catch(Exception e) {
		 responseView.setStatus(Constants.RESPONSE_FAILURE);
		 responseView.setStatusDescription(e.getMessage());
	 }
	  return responseView;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/downloadMcIdData")
	public ResponseView<String> downloadMcIdDataAsExcel(@RequestBody(required = false) RequestView  request, HttpServletRequest httpRequest) {
		ResponseView<String> responseView = new ResponseView<>();
		responseView.setData("Download request submitted successfully");
		responseView.setStatus(Constants.RESPONSE_SUCCESS);
		responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
		try {
			
//			UserExportDTO userExport = infectionSummaryDashboardService.init(request,
//					ACIISSTConstants.COVID19_MCID_REPORT_NM, ACIISSTConstants.EXCEL);
//			infectionSummaryDashboardService.generateMcIdDataAsExcel(ACIISSTConstants.EXCEL, request, userExport, smUserId,account);
		} catch (Exception e) {
			responseView.setData("Error submitting Download request - " + e.getMessage());
			}
		return responseView;
	}	
	
}
