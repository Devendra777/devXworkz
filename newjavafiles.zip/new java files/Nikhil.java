class Nikhil{

public static void main(String a[])
{
   char   type='!';
   long  phoneNo = 9638527410L;
     boolean isAlive= true;
System.out.println(phoneNo);
System.out.println(isAlive);
System.out.println(type);

}


}