interface Switch {
 
 public   void  sOn();
 public void   sOff();
 
}