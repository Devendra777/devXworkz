class Exam{

    public String code;
  public   HallTicket  hallTicket;
  public  static String universityName = "VTU";
  public   double fees;

 public Exam(){
System.out.println("Exam Object is created");
}

public boolean  allow(HallTicket hallTicket){
System.out.println("invoked allow");
boolean there = false;
  if(this.fees >= 1000){
System.out.println("fees is paid");
         if(hallTicket != null)          {
                 there = true;
            this.hallTicket = hallTicket;
           this.hallTicket.displayHallTicketDetails();
      System.out.println("EXAM CODE :"  + this.code);
}
else{
   System.out.println("no hall ticket");
}
}
else{
System.out.println("fees is less");
}
return there;
}

}