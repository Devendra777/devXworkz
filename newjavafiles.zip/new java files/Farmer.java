class Former
{
        String name="Ranganna";
      static String address="Davangere";

 public static void main(String a[])
{
System.out.println("Main method aarambha");
System.out.println(name);
System.out.println(address);
           farming();
System.out.println("Main method anthya");
}
   
  static void farming()
{
System.out.println("Farming method started");
System.out.println("Farming Corn");
System.out.println("Farming method ended");
}
}