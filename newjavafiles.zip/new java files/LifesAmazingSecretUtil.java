import java.util.Scanner;

class LifesAmazingSecretUtil{

public static void main(String a[]){
Scanner sc = new Scanner(System.in);
System.out.println("Enter the  Author ");

 String author=   sc.nextLine();

System.out.println("Enter the NovelId");
  int novelId=   sc.nextInt();
System.out.println("  no Of Pages");
int noOfPages=   sc.nextInt();
sc.close();
System.out.println(novelId);
LifesAmazingSecret lifes = new LifesAmazingSecret();
lifes.novelId=novelId;
lifes.author = author;
lifes.noOfPages = noOfPages;
System.out.println(lifes.novelId + "   "+ lifes.author + "  "+ lifes.noOfPages );
}


}