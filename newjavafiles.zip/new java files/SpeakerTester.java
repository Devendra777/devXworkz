class  SpeakerTester{

public static void main(String a[]){

     Speaker.onOrOff();
   

  }



}