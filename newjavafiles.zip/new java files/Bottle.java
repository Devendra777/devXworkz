class Bottle
{
     public static void myMain(String a[])
     {
      System.out.println("Bottle is used to store liquid");
    }

}