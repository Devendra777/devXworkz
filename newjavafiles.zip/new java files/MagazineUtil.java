class MagazineUtil{

public static void main(String a[])
{
  MagazineDTO dto  = new MagazineDTO();

dto.setNoOfPages(45);
dto.setName("Sparda Spoorthi");
dto.setType("Competative");
dto.setPrice(50.00);
   System.out.println(dto.getNoOfPages());
   System.out.println(dto.getName());
  System.out.println(dto.getType());
  System.out.println(dto.getPrice());


MagazineDTO dto1 = new MagazineDTO();

dto1.setNoOfPages(79);
dto1.setName("Viveka Sampada");
dto1.setType("Spiritual");
dto1.setPrice(120.00);
   System.out.println(dto1.getNoOfPages());
   System.out.println(dto1.getName());
  System.out.println(dto1.getType());
  System.out.println(dto1.getPrice());

}
}