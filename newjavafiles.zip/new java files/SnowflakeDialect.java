package com.legato.persistence.snowflake.dialect;

import org.hibernate.dialect.Dialect;

public class SnowflakeDialect extends Dialect{

}
