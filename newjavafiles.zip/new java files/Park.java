class  Park
{
     
static String name="LalbaghAndNationalpark&Couple'sPark";
static String address= "Mavalli&Banerugatta&NearMGRoad";

    public static void main(String a[])
{
   
entertainAndPeace();


}


  static void entertainAndPeace()
{
     System.out.println("Getting Entertained by seeing the behavoir of the couples");

}
}