class Ba123ba{

public static void main(String a[]){
System.out.println("baba is a great guy");
}
}