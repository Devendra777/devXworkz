class Engineer {

public String USN;

public Constants branch = Constants.ARCH;


public Engineer(){
super();
System.out.println("Engineer object is created");

}


public void problemSolving(){
System.out.println("invked problemSolving()");
System.out.println("problem solved");

}

// Setter Initialization
public void setUSN(String USN){
   this.USN=USN;
}

// getter method
public String getUSN(){
return USN;
}

public Constants getBranch(){
return branch;
}

}