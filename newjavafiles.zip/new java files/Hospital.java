import java.util.Arrays;
class Hospital{

   private String name  ;
  public PatientDTO[]  patients;
 private int index;

public Hospital(int size){
 patients = new  PatientDTO[size];
System.out.println( this.getClass().getSimpleName() +" object is created");
}



public void savePatients(PatientDTO  patients){
if(patients != null){
System.out.println(" adding Patient Details");
    this.patients[index] = patients;
     index++;
}
else{
System.out.println("Patient Details are Empty ..Please add the Patient details");
}
    
}

public  void getPatients(){

 for(PatientDTO patient :   patients ){
   if(patient != null)
  { 

 System.out.println(patient.getPatientId() + "  "+patient.getName() + "  "+ patient.getAge() +  "   "+ patient.getMobileNo() );

}
else{
System.out.println("no patient found");
}
}
}

public boolean  updatePatientsMobileNoByPatientId(long mobileNo ,String  patientId){
System.out.println("invoked updatePatientsMobileNoByPatientId");
boolean updatedMobileNo = false;
 for(int i=0 ; i < patients.length ; i++){
         if(patients[i] != null){
                   if(patientId.equals(patients[i].getPatientId())){  
                                          patients[i].setMobileNo(  mobileNo);        
                        System.out.println("MobileNo updated"); 
                                         updatedMobileNo = true;
                }
          }
  }
return updatedMobileNo;
}


public boolean  deletePatientById(String  patientId){
System.out.println("invoked deletePatientById()");
      boolean deleted = false;
             for(int i=0 ; i< patients.length ; i++){
                                if(patients[i] != null){
                                        if(patientId.equals(patients[i].getPatientId())){  
                                            patients[i] = null;
                                            deleted = true;
                                        }
                               }
            }
return deleted;
}



public String  getStateNamesByPatientName(String name){
        String stateName=null;
      for(int i=0 ; i< patients.length ; i++){
                if(patients[i] != null){
                                        if(name.equals(patients[i].getName())){
                          AddressDTO addressDTO =        patients[i].getAddress();
                                        CountryDTO country =            addressDTO.getCountries();
                                      StateDTO[] states = country.getStates();
                                                    for(int j=0  ; j<  states.length ; j++ ){
                                                            stateName =       states[j].getStateName();
                                                  }
                                                             
                                          
                                     }
                          }
                     }
            return stateName;
            }




public String getName(){
return name ;
}
public void setName(String name){
this .name = name ;
}


}