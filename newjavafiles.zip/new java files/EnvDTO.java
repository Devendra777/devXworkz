package com.legato.persistence.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "env_info_dtl")
public class EnvDTO implements Serializable {

	public EnvDTO() {
		// TODO Auto-generated constructor stub
	}
	

	@Id
	@Column(name = "tbl_nm")
	private String tblName;
	
	@Id
	@Column(name = "parm_nm")
	private String paramName;
	
	@Column(name = "parm_dtl_txt")
	private String paramDtlTxt;

	public String getTblName() {
		return tblName;
	}

	public void setTblName(String tblName) {
		this.tblName = tblName;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamDtlTxt() {
		return paramDtlTxt;
	}

	public void setParamDtlTxt(String paramDtlTxt) {
		this.paramDtlTxt = paramDtlTxt;
	}

}
