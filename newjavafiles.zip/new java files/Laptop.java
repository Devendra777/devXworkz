class Laptop{

void browse(Google g){
g.connectDB();
g.sendMail();
}

}