package com.legato.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.common.web.view.ResponseView;
import com.legato.common.constants.Constants;
import com.legato.persistence.dao.AbstractDAO;
import com.legato.persistence.dto.EnvDTO;
import com.legato.persistence.dto.FilterConditionsDTO;
import com.legato.web.service.EnvironementService;
import com.legato.web.service.FilterConditionService;


@CrossOrigin
@RestController
@RequestMapping("/")
public class FilterConditionController extends AbstractDAO{
	
	@Autowired
	FilterConditionService filterConditionService;
	
	
	public FilterConditionController() {
		
	}
	
	


	@RequestMapping(method = RequestMethod.POST, value = "/filterConditions")
	public  ResponseView<FilterConditionsDTO> createFilterConditions(@RequestBody(required = false) FilterConditionsDTO  dto,HttpServletRequest httpRequest) {
	 
	 ResponseView<FilterConditionsDTO> responseView = new ResponseView<>();
	 try { 
		 filterConditionService.validateAndSaveFilterConditions(dto);
	          
	          responseView.setData(dto);
	 		 responseView.setTotal(1);
	 		 responseView.setStatus(Constants.RESPONSE_SUCCESS);
	 		 responseView.setStatusDescription(Constants.RESPONSE_SUCCESS_DESCP);
	 	 }catch(Exception e) {
	 		 responseView.setStatus(Constants.RESPONSE_FAILURE);
	 		 responseView.setStatusDescription(e.getMessage());
	 	 }
	 	  return responseView;
	 	}
	
	

}
