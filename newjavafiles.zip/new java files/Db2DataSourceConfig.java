package com.legato.migration;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "db2EntityManager", transactionManagerRef = "db2TransactionManager", basePackages = "com.legato.persistence.db2.repository")
public class Db2DataSourceConfig {
	@Primary
	@Bean(name = "db2DataSource")
	@ConfigurationProperties(prefix = "spring.db2.datasource")
	public DataSource db2DataSource() {
		return DataSourceBuilder.create().build();
	}

	@Primary
	@Bean(name = "db2EntityManager")
	public LocalContainerEntityManagerFactoryBean db2EntityManagerFactory(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(db2DataSource()).properties(hibernateProperties())
				.packages("com.legato.persistence.db2.entity").persistenceUnit("db2PU").build();
	}
	@Primary
	@Bean(name = "db2TransactionManager")
	public PlatformTransactionManager db2TransactionManager(
			@Qualifier("db2EntityManager") EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}
	
	@Bean(name = "db2NamedParameterJdbcTemplate")
	public NamedParameterJdbcTemplate db2NamedParameterJdbcTemplate(
	        @Qualifier("db2DataSource") DataSource db2DataSource) {
	    return new NamedParameterJdbcTemplate(db2DataSource);
	}

	private Map<String, Object> hibernateProperties() {

		HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect",
          "com.legato.persistence.snowflake.dialect.DB2Dialect");
		return properties;

	}
}
