package com.legato.persistence.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sub_qry_dtl")
public class SubQueryDetailsDTO {

	public SubQueryDetailsDTO() {
		// TODO Auto-generated constructor stub
	}

	@Id
	@Column(name = "tbl_nm")
	private String tblName;
	@Id
	@Column(name = "sub_qry_tbl_nm")
	private String subQueryTableName;
	@Column(name = "sub_qry_txt")
	private String subQueryText;
	
	public String getTblName() {
		return tblName;
	}
	public void setTblName(String tblName) {
		this.tblName = tblName;
	}
	public String getSubQueryTableName() {
		return subQueryTableName;
	}
	public void setSubQueryTableName(String subQueryTableName) {
		this.subQueryTableName = subQueryTableName;
	}
	public String getSubQueryText() {
		return subQueryText;
	}
	public void setSubQueryText(String subQueryText) {
		this.subQueryText = subQueryText;
	}
	
	

}