class AddingTwoNumbers
{
  
           public static void  modulus(int a , int b){
System.out.println("modulus method started");
           int num = a+b;
          System.out.println(num);
System.out.println("modulus method ended");
}

public static void main(String a[]){
System.out.println("main method started");
modulus(1,1); 
System.out.println("main method ended");
}


}