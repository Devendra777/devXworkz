package com.wellpoint.pc2dash.service.stars;

import java.util.ArrayList;
import java.util.List;
import com.wellpoint.pc2dash.action.stars.AverageStarRatingRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dao.AbstractDao;
import com.wellpoint.pc2dash.dto.stars.AverageStarRatingJson;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import static com.wellpoint.pc2dash.service.dashboard.Constants.COMMA;
import static com.wellpoint.pc2dash.service.dashboard.ErrorMessages.SQL;
import static com.wellpoint.pc2dash.util.Constants.CLOSE_BRACKET;

import java.sql.SQLException;

import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class AverageStarRatingServiceImpl extends AbstractDao {
	
	private static final String UNABLE_TO_GET_AVERAGE_STAR_RATING = "UNABLE_TO_GET_AVERAGE_STAR_RATING";
	private static final String AVG_STAR_RTNG = "AVG_STAR_RTNG";
	private static final String AVERAGE_STAR_RATING = "Average Star Rating";
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AverageStarRatingServiceImpl.class);
	
	public List<AverageStarRatingJson> getData(AverageStarRatingRequest ratingRequest) throws PC2Exception{
		
		List<AverageStarRatingJson> results=new ArrayList<AverageStarRatingJson>();
			
		StringBuilder sql = getAverageStarRatingQuery(ratingRequest);
		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(ratingRequest, sql.toString());
			executeQuery(logger, sql.toString());
			getResult(results);
		}
		catch (Exception e) {
			throw new PC2Exception( UNABLE_TO_GET_AVERAGE_STAR_RATING  + ratingRequest.toString() + SQL + sql.toString(), e);
		}
		finally {
			close();
		}

		return results;
	}
		

	private StringBuilder getAverageStarRatingQuery(AverageStarRatingRequest ratingRequest) {
			StringBuilder sql = new StringBuilder()
					.append("SELECT  ")
					.append("listagg(MDCR_STAR.MSR_DIM_KEY,',') as STAR_MSR_LIST, ") //Latest Data-Query
					.append("  ROUND(AVG(SUBSTR(RFRNC.STAR_LVL_CD,1,1)),2) AS AVG_STAR_RTNG ")
					.append(" FROM ( ")
					.append("  SELECT ")
					.append(" MSSF.MSR_DIM_KEY, ")
					.append(" MD.MSR_DSPLY_NM, ")
					.append(" MD.RULE_ID,")
					.append(" MSSF.MSR_YEAR_NBR, ")
					.append(" SUM(NMRTR_NBR) AS NMRTR_NBR, ")
					.append(" SUM(DNMNTR_NBR) AS DNMNTR_NBR, ")
					.append(" ROUND(CAST(SUM(NMRTR_NBR)*100 AS DECIMAL(18,2))/SUM(DNMNTR_NBR),2)AS CMPLNC_RT_PCT ")
					.append(" FROM PC2WEB_RPT_ACTV.MDCR_STAR_SMRY_FACT MSSF ")
					.append(" INNER JOIN PC2WEB_RPT_ACTV.PROV_GRP_DIM PGD ")
					.append(" ON MSSF.PROV_GRP_DIM_KEY=PGD.PROV_GRP_DIM_KEY ")
					.append(" AND PGD.RCRD_STTS_CD='ACT' ")
					.append(" INNER JOIN PC2WEB_RPT_ACTV.PROV_ORG_DIM POD ")
					.append(" ON MSSF.PROV_ORG_DIM_KEY=POD.PROV_ORG_DIM_KEY ")
					.append(" AND POD.RCRD_STTS_CD='ACT' ")
					.append(" INNER JOIN PC2WEB_RPT_ACTV.PGM_DIM PD ")
					.append(" ON MSSF.PGM_DIM_KEY=PD.PGM_DIM_KEY ")
					.append(" AND PD.RCRD_STTS_CD='ACT' ")
					.append(" INNER JOIN PC2WEB_RPT_ACTV.MSR_DIM MD ")
					.append(" ON MSSF.MSR_DIM_KEY=MD.MSR_DIM_KEY ")
					.append(" AND MD.RCRD_STTS_CD='ACT' ")
					.append("INNER JOIN PSL_DIM PSLD ")
					.append("ON MSSF.PSL_DIM_KEY=PSLD.PSL_DIM_KEY ")
					.append("AND PSLD.RCRD_STTS_CD='ACT' ")
					.append("  join poit_user_scrty_acs PUSA on ( ")
					.append("    pgd.prov_grp_id = PUSA.prov_grp_id ")
					.append("    and case ")
					.append("        when PUSA.prov_org_tax_id = '0' then pod.prov_org_tax_id ")
					.append("        else PUSA.prov_org_tax_id ")
					.append("      end = pod.prov_org_tax_id ")
					.append("  ) ")		
				 	.append("WHERE PRTLT_ID='1000' AND ")
					.append(buildWhereClause(ratingRequest))
					.append(" GROUP BY  ")
					.append(" MSSF.MSR_DIM_KEY, ")
					.append(" MD.MSR_DSPLY_NM, ")
					.append(" MD.RULE_ID, ")
					.append(" MSSF.MSR_YEAR_NBR ")
					.append(" WITH UR ")
					.append(" ) MDCR_STAR ")
					.append(" LEFT OUTER JOIN PC2WEB_RPT_ACTV.MDCR_STARS_CUT_PCT_RFRNC RFRNC ")
					.append(" ON MDCR_STAR.RULE_ID=RFRNC.RULE_ID ")
					.append(" AND MDCR_STAR.MSR_YEAR_NBR=RFRNC.MSR_YEAR_NBR ")
					.append(" AND MDCR_STAR.CMPLNC_RT_PCT BETWEEN RFRNC.MIN_CUT_PCT AND RFRNC.MAX_CUT_PCT WITH UR ");		
			return sql;
		}
	
	

	private String  buildWhereClause(AverageStarRatingRequest request) {
		StringBuilder sql = new StringBuilder()
				.append("PUSA.sesn_id = ? ")
				.append("and PUSA.enttlmnt_hash_key = ? ");

			if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
				sql.append("and pgd.prov_grp_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
				sql.append("and MSSF.pgm_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ");
			}
			
			if (StringUtil.isNotBlankOrFalse(request.getPslIds())) {
				sql.append("and PSLD.psl_desc in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPslIds()) + CLOSE_BRACKET);
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				sql.append("and MSSF.prov_org_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys()) + ") ");
			}
			return sql.toString();
		}
	
	protected void buildPreparedStatement(AverageStarRatingRequest request, String query) throws SQLException {

		int i = 1;
		prepareStatement(logger, query);

		ps.setString(i++, request.getSessionId());

		ps.setString(i++, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
			String[] array = request.getProvGrpIds().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
			String[] array = request.getProgramIds().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getPslIds())) {
			String[] array = request.getPslIds().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(COMMA);
			for (String item : array) {
				ps.setString(i++, item);
			}
		}
	}

	private List<AverageStarRatingJson> getResult(List<AverageStarRatingJson> results) throws SQLException {
		while (rs.next()) {
			AverageStarRatingJson jsonResult = new AverageStarRatingJson();		
			jsonResult.setMeasure(AVERAGE_STAR_RATING);
			jsonResult.setValue(StringUtil.getValueOrDashes(rs.getString(AVG_STAR_RTNG)));
			results.add(jsonResult);
		}
		return results;	
	}
	
	@Override
	public boolean read(Dto o) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Dto o) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Dto o) throws Exception {
		// TODO Auto-generated method stub
		
	}

}