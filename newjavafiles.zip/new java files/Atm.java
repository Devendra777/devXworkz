interface Atm{

void connectBankDB();
}