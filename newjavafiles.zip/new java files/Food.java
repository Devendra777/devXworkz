class Food
{
static   String  name =   "Puliogare";
   public static void main(String a[]){
    /* datatype   variableName = value */
      
         int       price =25; 
      System.out.println(name);
      System.out.println(price);

}



}