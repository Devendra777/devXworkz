Class Phone
{

static double price = 34000.00;
public static void main(String a[])
{


   long number =      call(97897897890L);
System.out.println(number);
   call("Rohit");
}


 static long call(long number)
{
return number;
}

public static  void call(String name)
{
System.out.println(name);

}




}