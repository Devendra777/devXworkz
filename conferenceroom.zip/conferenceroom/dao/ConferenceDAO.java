package com.cleartrip.conferenceroom.dao;

import java.util.List;

import com.cleartrip.conferenceroom.dto.BookingDTO;
import com.cleartrip.conferenceroom.dto.BuildingsDTO;

public interface ConferenceDAO {
	
	
	
	public boolean saveConferenceRooms(BuildingsDTO buildingsDTO);

	public List<BuildingsDTO> getConferenceRooms();

	public boolean saveBooking(BookingDTO bookingDTO);

	public List<BookingDTO> getBookings();

	public BookingDTO getBooking(int userId);

}
