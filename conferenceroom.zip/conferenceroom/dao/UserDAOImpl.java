package com.cleartrip.conferenceroom.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cleartrip.conferenceroom.dto.UserDTO;

@Repository
public class UserDAOImpl implements UserDAO{
	
	
	private List<UserDTO> users = new ArrayList<UserDTO>();

	@Override
	public boolean saveUser(UserDTO userDTO) {
		// TODO Auto-generated method stub
		return users.add(userDTO);
	}

	@Override
	public List<UserDTO> getUsers() {
		// TODO Auto-generated method stub
		return users;
	}
	

	

}
