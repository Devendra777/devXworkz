package com.cleartrip.conferenceroom.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cleartrip.conferenceroom.dto.BookingDTO;
import com.cleartrip.conferenceroom.dto.BuildingsDTO;

@Repository
public class ConferenceDAOImpl implements ConferenceDAO{
	
	List<BookingDTO> bookings =new ArrayList<BookingDTO>();
	
	List<BuildingsDTO> buildingsDTO = new ArrayList<BuildingsDTO>();
	
	

	@Override
	public boolean saveConferenceRooms(BuildingsDTO buildingsDTO) {
		return this.buildingsDTO.add(buildingsDTO);
	}


	@Override
	public List<BuildingsDTO> getConferenceRooms() {
		// TODO Auto-generated method stub
		
		return buildingsDTO;
	
	}


	@Override
	public boolean saveBooking(BookingDTO bookingDTO) {
	return bookings.add(bookingDTO);
	}


	@Override
	public List<BookingDTO> getBookings() {
		// TODO Auto-generated method stub
		return bookings;
	}


	@Override
	public BookingDTO getBooking(int userId) {
		BookingDTO bookingDTO = null;
	 
	for (BookingDTO bookingDTO2 : bookings) {
		if(userId == bookingDTO2.getUser().getUserId())
		{
			bookingDTO = bookingDTO2;
			
		}
	}
	return bookingDTO;
	}

}
