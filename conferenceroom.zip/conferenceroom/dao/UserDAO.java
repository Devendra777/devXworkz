package com.cleartrip.conferenceroom.dao;

import java.util.List;

import com.cleartrip.conferenceroom.dto.UserDTO;

public interface UserDAO {
	
	public boolean saveUser(UserDTO userDTO);

	public List<UserDTO> getUsers(); 

}
