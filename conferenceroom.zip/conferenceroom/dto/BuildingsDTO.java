package com.cleartrip.conferenceroom.dto;

import java.util.List;

public class BuildingsDTO {

	public String buildingName;

	public List<FloorDTO> floors;

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public List<FloorDTO> getFloors() {
		return floors;
	}

	public void setFloors(List<FloorDTO> floors) {
		this.floors = floors;
	}

}
