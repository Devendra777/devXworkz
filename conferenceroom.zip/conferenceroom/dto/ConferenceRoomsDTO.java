package com.cleartrip.conferenceroom.dto;

import java.util.List;

public class ConferenceRoomsDTO {
	
	
	private List<String> names;

}
