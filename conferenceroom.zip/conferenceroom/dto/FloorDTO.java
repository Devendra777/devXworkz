package com.cleartrip.conferenceroom.dto;

import java.io.Serializable;
import java.util.List;

public class FloorDTO implements Serializable{

	private String floorName;
	private List<String> conferenceRooms;
	
	public FloorDTO() {
		// TODO Auto-generated constructor stub
	}
	


	public List<String> getConferenceRooms() {
		return conferenceRooms;
	}

	public void setConferenceRooms(List<String> conferenceRooms) {
		this.conferenceRooms = conferenceRooms;
	}



	public String getFloorName() {
		return floorName;
	}



	public void setFloorName(String floorName) {
		this.floorName = floorName;
	}

}
