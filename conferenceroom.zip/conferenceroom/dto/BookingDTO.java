package com.cleartrip.conferenceroom.dto;

public class BookingDTO {

	private UserDTO user;
	private String slot;
	private BuildingsDTO buildingDetails;

	public BookingDTO() {
		// TODO Auto-generated constructor stub
	}

	

	public String getSlot() {
		return slot;
	}

	public void setSlot(String slot) {
		this.slot = slot;
	}




	public UserDTO getUser() {
		return user;
	}



	public void setUser(UserDTO user) {
		this.user = user;
	}



	public BuildingsDTO getBuildingDetails() {
		return buildingDetails;
	}



	public void setBuildingDetails(BuildingsDTO buildingDetails) {
		this.buildingDetails = buildingDetails;
	}

}
