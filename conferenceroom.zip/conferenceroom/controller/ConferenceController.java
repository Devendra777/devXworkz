package com.cleartrip.conferenceroom.controller;

import java.lang.annotation.Annotation;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cleartrip.conferenceroom.dto.BookingDTO;
import com.cleartrip.conferenceroom.dto.BuildingsDTO;
import com.cleartrip.conferenceroom.dto.ConferenceRoomsDTO;
import com.cleartrip.conferenceroom.dto.UserDTO;
import com.cleartrip.conferenceroom.service.ConferenceService;
import com.cleartrip.conferenceroom.service.UserService;

@RestController("/")
public class ConferenceController {

	@Autowired
	private UserService userService;

	@Autowired
	private ConferenceService confService;

	public ConferenceController() {
		// TODO Auto-generated constructor stub
	}

	@PostMapping("/user")
	public boolean registerUser(@RequestBody UserDTO userDTO) {
		if (userDTO != null) {
			return userService.validateUserAndSave(userDTO);
		}

		return false;

	}

	@GetMapping("/getAllUsers")
	public List<UserDTO> getAllUsers() {

		List<UserDTO> list = userService.fetchUsers();
		if (list != null) {
			return list;
		}
		return null;
	}

	@PostMapping("/addConferenceRooms")
	public boolean addConferenceRooms(@RequestBody BuildingsDTO dto) {
		if (dto != null) {
			return confService.addConferenceRooms(dto);
		}

		return false;

	}

	@GetMapping("/getConferenceRooms")
	public List<BuildingsDTO> getConferenceRooms() {

		List<BuildingsDTO> list = confService.getConferenceRooms();
		if (list != null) {
			return list;
		}

		return null;

	}

	@PostMapping("/addBooking")
	public boolean createBooking(@RequestBody BookingDTO bookingDTO) {
		if (bookingDTO != null) {
			return confService.addBookings(bookingDTO);
		}

		return false;
	}

	@GetMapping("/getBooking")
	public List<BookingDTO> getBookings() {

		List<BookingDTO> list = confService.getBookings();
		if (list != null) {
			return list;
		}

		return null;

	}

	@GetMapping("/getBooking/{userId}")
	public BookingDTO getBookingsByUser(@PathVariable int userId) {

		BookingDTO list = confService.getBookings(userId);
		if (list != null) {
			return list;
		}

		return null;

	}

}
