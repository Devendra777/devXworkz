package com.cleartrip.conferenceroom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cleartrip.conferenceroom.dao.ConferenceDAO;
import com.cleartrip.conferenceroom.dto.BookingDTO;
import com.cleartrip.conferenceroom.dto.BuildingsDTO;

@Service
public  class ConferenceServiceImpl implements ConferenceService{
	
	@Autowired
	private ConferenceDAO dao;

	@Override
	public boolean addConferenceRooms(BuildingsDTO buildingsDTO) {
		// TODO Auto-generated method stub
		return dao.saveConferenceRooms(buildingsDTO);
	}

	@Override
	public List<BuildingsDTO>  getConferenceRooms() {
		return dao.getConferenceRooms();
		}

	@Override
	public boolean addBookings(BookingDTO bookingDTO) {
		return dao.saveBooking(bookingDTO);
	}

	@Override
	public List<BookingDTO> getBookings() {
		// TODO Auto-generated method stub
		return dao.getBookings();
	}

	@Override
	public BookingDTO getBookings(int userId) {
		return dao.getBooking(userId);
	}

}
