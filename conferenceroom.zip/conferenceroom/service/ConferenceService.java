package com.cleartrip.conferenceroom.service;

import java.util.List;

import com.cleartrip.conferenceroom.dto.BookingDTO;
import com.cleartrip.conferenceroom.dto.BuildingsDTO;

public interface ConferenceService {
	
	 public boolean   addConferenceRooms(BuildingsDTO buildingsDTO);

	public List<BuildingsDTO> getConferenceRooms();

	public boolean addBookings(BookingDTO bookingDTO);

	public List<BookingDTO> getBookings();

	public BookingDTO getBookings(int userId);

}
