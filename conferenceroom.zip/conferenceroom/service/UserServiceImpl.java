package com.cleartrip.conferenceroom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cleartrip.conferenceroom.dao.UserDAO;
import com.cleartrip.conferenceroom.dto.UserDTO;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDAO dao;
	

	@Override
	public boolean validateUserAndSave(UserDTO userDTO) {
		// TODO Auto-generated method stub
		return dao.saveUser(userDTO);
	}


	@Override
	public List<UserDTO> fetchUsers() {
		return dao.getUsers();
	}

}
