package com.cleartrip.conferenceroom.service;

import java.util.List;

import com.cleartrip.conferenceroom.dto.UserDTO;

public interface UserService {
	
	
	public boolean validateUserAndSave(UserDTO userDTO);

	public List<UserDTO> fetchUsers();

}
