package com.dev.devapp.service;

import com.dev.devapp.dto.PubDTO;

public interface PubService {
	
	
	
	public  void validateAndSave(PubDTO dto) ;

	public PubDTO getPubById(int i);

}
