package com.dev.devapp.service;

import com.dev.devapp.dao.PubDAO;
import com.dev.devapp.dao.PubDAOImpl;
import com.dev.devapp.dto.PubDTO;

public class PubServiceImpl implements PubService {
	
	PubDAO dao;
	public PubServiceImpl() {
		dao = new PubDAOImpl();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void validateAndSave(PubDTO dto) {
		if(dto != null)
		{
			dao.create(dto);
		}
		// TODO Auto-generated method stub

	}

	@Override
	public PubDTO getPubById(int i) {
		return dao.getPubById(i);
	}

}
