package com.dev.devapp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pub_table")
public class PubDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "pub_id")
	private int pubId;

	@Column(name = "pub_name")
	private String pubName;
	
	@Column(name = "pub_address")
	private String address;

	public PubDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getPubId() {
		return pubId;
	}

	public void setPubId(int pubId) {
		this.pubId = pubId;
	}

	public String getPubName() {
		return pubName;
	}

	public void setPubName(String pubName) {
		this.pubName = pubName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
