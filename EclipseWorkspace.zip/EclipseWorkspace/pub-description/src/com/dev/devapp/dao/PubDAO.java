package com.dev.devapp.dao;

import com.dev.devapp.dto.PubDTO;

public interface PubDAO {

	public void create(PubDTO dto);

	public PubDTO getPubById(int i);

}