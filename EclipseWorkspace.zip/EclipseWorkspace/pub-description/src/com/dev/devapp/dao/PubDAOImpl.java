package com.dev.devapp.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dev.devapp.dto.PubDTO;
import com.xworkz.singleton.HibernateUtil;

public class PubDAOImpl implements PubDAO {
	@Override
	public void create(PubDTO pubDTO) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			transaction = session.beginTransaction();
			
			session.save(pubDTO);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (transaction != null) {
				session.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		// factory.close();
	}

	@Override
	public PubDTO getPubById(int id) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		
		PubDTO dto = session.get(PubDTO.class, id);
		System.out.println(dto);
		
		dto= session.load(PubDTO.class, id);
		System.out.println(dto.getPubId());
		
		
		session.close();
	 factory.close();
		return dto;
	}

}
