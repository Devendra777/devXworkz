package com.dev.devapp;

import com.dev.devapp.dto.PubDTO;
import com.dev.devapp.service.PubService;
import com.dev.devapp.service.PubServiceImpl;

public class PubTester {
	
	
	
	public static void main(String[] args) {
		
		
		PubDTO dto = new PubDTO();
		dto.setAddress("Indiranagar");
		dto.setPubName("Urban Deccan");
		
		
	PubService pubService = new PubServiceImpl();
		//pubService.validateAndSave(dto);
		
pubService.getPubById(9);
	}


}
