package com.dev.devapp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.dev.devapp.dto.MusicInstrumentDTO;

public class MusicInstrumentDAOImpl implements MusicInstrumentDAO{

	@Override
	public void saveMusicInstrument(MusicInstrumentDTO instrumentDTO) {
		// TODO Auto-generated method stub
		Configuration configuration= new Configuration();
		configuration.configure();
		configuration.addAnnotatedClass(MusicInstrumentDTO.class);
		SessionFactory  sessionFactory=configuration.buildSessionFactory();
		Session session= sessionFactory.openSession(); 
		Transaction transaction = session.beginTransaction();
		session.save(instrumentDTO);
		transaction.commit();
		session.close();
		sessionFactory.close();
	}

}
