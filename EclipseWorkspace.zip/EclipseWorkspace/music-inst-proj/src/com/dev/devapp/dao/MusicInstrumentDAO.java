package com.dev.devapp.dao;

import com.dev.devapp.dto.MusicInstrumentDTO;

public interface MusicInstrumentDAO {

	public void saveMusicInstrument(MusicInstrumentDTO instrumentDTO);
	
}
