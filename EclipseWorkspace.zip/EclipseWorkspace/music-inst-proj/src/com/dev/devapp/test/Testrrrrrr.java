package com.dev.devapp.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Testrrrrrr {

	public static void main(String[] args) {

		List<String> list = new ArrayList<String>();
		list.add("Average");
		list.add("Adult BMI");
		
		
		//resluts
		
		System.out.println(list.size());
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
			
		}

		/*
		 * for (int i = 0; i < list.size(); i++) {
		 * 
		 * }
		 */
	
		

	}

}
