package com.dev.devapp.test;

import com.dev.devapp.dao.MusicInstrumentDAO;
import com.dev.devapp.dao.MusicInstrumentDAOImpl;
import com.dev.devapp.dto.MusicInstrumentDTO;

public class Tester {
	
	
	public static void main(String[] args) {
		
		MusicInstrumentDTO dto = new MusicInstrumentDTO();
		dto.setMusicId(1);
		dto.setName("Guitar");
		dto.setType("Electric");
		dto.setCost(8000.00);
		
		MusicInstrumentDAO dao =new MusicInstrumentDAOImpl();
		dao.saveMusicInstrument(dto);
	}

}
