package com.dev.devapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Asd {
	
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		int i=sc.nextInt();
		System.out.println("Enter h");

	
			//PreparedStatement preparedStatement = 
	try {
		String insert ="insert into game values(?,?,?)";
		Connection connection =  DriverManager.getConnection("");
		for (int j = 0; j < i; j++) {
			
	PreparedStatement preparedStatement=	connection.prepareStatement("");
	
	
	}
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	}
	

}
