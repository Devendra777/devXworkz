package com.xworkz.xworkzapp.util;

import com.xworkz.xworkzapp.watch.Rolex;
import com.xworkz.xworkzapp.watch.Watch;

public class WatchUtil {
	
	public static void main(String[] args) {
		/*
		 * Watch watch = new Rolex(); 
		 * Rolex rolex=(Rolex) watch; // Rolex rolex= (Rolex)
		 * new Watch(); watch.modelNo="RT420"; watch.price = 5678.99;
		 * watch.displayTime();
		 */
	    
	  // System.out.println(watch.modelNo + " "+watch.price);
	    
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		
	     long iLong = 10L;
		int  i= (int) iLong;
		
		int nn=34;
		long nmmm=nn;
		
		
		
		
		
		
	}

}
