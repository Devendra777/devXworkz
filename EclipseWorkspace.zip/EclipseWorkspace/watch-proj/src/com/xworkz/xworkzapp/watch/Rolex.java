package com.xworkz.xworkzapp.watch;

import java.util.Date;

public class Rolex extends Watch{
	
	
	public Rolex() {
		super();
		System.out.println("Rolex Object created");
	}
	
	
	public void displayTime() {
		
		System.out.println("12/23/2020");
	}
	
	

}
