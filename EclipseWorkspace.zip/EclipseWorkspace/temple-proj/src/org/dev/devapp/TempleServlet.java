package org.dev.devapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/temp" ,  loadOnStartup=+7 , name="Temp" ,
initParams =  {
		@WebInitParam(name="Name",value="Shrikar"),
		@WebInitParam(name="Age",value="27")
})
public class TempleServlet extends HttpServlet {
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
	}
	
	public TempleServlet() {
		// TODO Auto-generated constructor stub
		
		System.out.println("Temple servlet is created ");
	  
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		ServletConfig config = getServletConfig();
		String name = config.getInitParameter("Name");
		String age = config.getInitParameter("Age");
		
		  ServletContext  context =   getServletContext();
		String sale = context.getInitParameter("sale");
		         

		resp.setContentType("text/html");
		PrintWriter writer = resp.getWriter();
		writer.print(sale);
		writer.print(name + " " + age);
	}

}
