package com.dev.devapp.test;

import java.util.List;

import com.dev.devapp.dao.CountryDAO;
import com.dev.devapp.dao.CountryDAOImpl;
import com.dev.devapp.dto.CountryDTO;

public class CountryUtil {

	public static void main(String[] args) {

		CountryDTO countryDTO = new CountryDTO();
		countryDTO.setCurrency("euro");
		countryDTO.setName("France");
		countryDTO.setNoOfStates(34);
		countryDTO.setPopulation(1211115645l);

		CountryDAO countryDAO = new CountryDAOImpl();
		// countryDAO.saveCountry(countryDTO);
		// countryDAO.updatePopByCountryName(23444444444L, "India");
		// countryDAO.deleteCountryNameByCurrency("dinar");
		CountryDTO dto = countryDAO.getCountryByCurrency("Rupee");
		System.out.println(dto);
		List<CountryDTO> countryDTOs = countryDAO.getAllCountries();
		for (CountryDTO countryDTO2 : countryDTOs) {
			System.out.println(countryDTO2);
		}
	}

}
