package com.dev.devapp.dao;

import java.util.List;

import com.dev.devapp.dto.CountryDTO;

public interface CountryDAO {
	
	
	 void saveCountry(CountryDTO dto );
	 
	 public void updatePopByCountryName(long population, String countryName);
	 public void deleteCountryNameByCurrency(String currency);
	 public CountryDTO getCountryByCurrency(String currency);
     public List<CountryDTO> getAllCountries();
}
