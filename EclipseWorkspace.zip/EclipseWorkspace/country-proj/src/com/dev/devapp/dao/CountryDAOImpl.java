package com.dev.devapp.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.dev.devapp.dto.CountryDTO;

public class CountryDAOImpl implements CountryDAO {

	private StandardServiceRegistry standardServiceRegistry;

	private static SessionFactory sessionFactory;

	@Override
	public void saveCountry(CountryDTO dto) {
		Session session = null;
		Transaction transaction = null;
		try {
			standardServiceRegistry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
			Metadata metadata = metadataSources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.save(dto);
			transaction.commit();
		} catch (HibernateException e) {
			if (transaction != null) {
				transaction.rollback();
			}
		} finally {
			if(session!=null)
			session.close();
			if(sessionFactory!=null)
			sessionFactory.close();
		}
	}

	@Override
	public void updatePopByCountryName(long population, String countryName) {
		
		Session session = null;
		Transaction transaction = null;
		try {
			standardServiceRegistry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
			Metadata metadata = metadataSources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
			session = sessionFactory.openSession();
			Query query=session.getNamedQuery("updatePopByCountry");
			query.setParameter("pop", population);
			query.setParameter("nm", countryName);
			query.executeUpdate();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if(session!=null)
			session.close();
			if(sessionFactory!=null)
			sessionFactory.close();
		}
		
	}

	@Override
	public void deleteCountryNameByCurrency( String currency) {
		
		Session session = null;
		Transaction transaction = null;
		try {
			standardServiceRegistry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
			Metadata metadata = metadataSources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
			session = sessionFactory.openSession();
			Query query = session.getNamedQuery("deleteByCurrency");
			query.setParameter("cr", currency);
			query.executeUpdate();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if(session!=null)
			session.close();
			if(sessionFactory!=null)
			sessionFactory.close();
		}
	}

	@Override
	public CountryDTO getCountryByCurrency(String currency) {

		Session session = null;
		CountryDTO countryFromDb=null;
		try {
			standardServiceRegistry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
			Metadata metadata = metadataSources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
			session = sessionFactory.openSession();
			Query query = session.getNamedQuery("selectQuery");
			query.setParameter("cr", currency);
			countryFromDb=	(CountryDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if(session!=null)
			session.close();
			if(sessionFactory!=null)
			sessionFactory.close();
		}
		return countryFromDb;
	}

	@Override
	public List<CountryDTO> getAllCountries() {
		Session session = null;
		List<CountryDTO> countryFromDb=null;
		try {
			standardServiceRegistry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
			Metadata metadata = metadataSources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
			session = sessionFactory.openSession();
			Query query = session.getNamedQuery("listOfCountries");
			countryFromDb=	 query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if(session!=null)
			session.close();
			if(sessionFactory!=null)
			sessionFactory.close();
		}
		return countryFromDb;
	}
	

}
