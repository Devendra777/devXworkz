package com.dev.devapp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@NamedQueries({
		@NamedQuery(query = "update CountryDTO dto set dto.population=:pop where dto.name=:nm", name = "updatePopByCountry"),
		@NamedQuery(query = "delete from CountryDTO ct where ct.currency=:cr", name = "deleteByCurrency"),
		@NamedQuery(query = "select dto from CountryDTO dto where dto.currency=:cr", name = "selectQuery")
	, @NamedQuery(query = "from CountryDTO dto", name = "listOfCountries"),
		})
@Table(name = "country_table")
public class CountryDTO {

	@Id
	@GenericGenerator(name = "ref", strategy = "increment")
	@GeneratedValue(generator = "ref")
	@Column(name = "country_id")
	private int countryId;
	@Column(name = "country_name")
	private String name;
	@Column(name = "country_currency")
	private String currency;
	@Column(name = "country_no_of_states")
	private int noOfStates;
	@Column(name = "country_population")
	private long population;

	public CountryDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public int getNoOfStates() {
		return noOfStates;
	}

	public void setNoOfStates(int noOfStates) {
		this.noOfStates = noOfStates;
	}

	public long getPopulation() {
		return population;
	}

	public void setPopulation(long population) {
		this.population = population;
	}

	@Override
	public String toString() {
		return "CountryDTO [countryId=" + countryId + ", name=" + name + ", currency=" + currency + ", noOfStates="
				+ noOfStates + ", population=" + population + "]";
	}

}
