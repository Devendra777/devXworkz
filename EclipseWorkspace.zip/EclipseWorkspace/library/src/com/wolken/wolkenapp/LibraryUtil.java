package com.wolken.wolkenapp;

import java.util.Scanner;

import com.wolken.wolkenapp.library.Library;
import com.wolken.wolkenapp.library.dto.BookDTO;

public class LibraryUtil {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = scanner.nextInt();

		Library library = new Library(size);

		for (int i = 0; i < size; i++) {
			System.out.println("Enter the book Id");
			int bookId = scanner.nextInt();
			System.out.println("Enter the Author");
			String author = scanner.next();
			System.out.println("Enter the Book Name");
			String bookName = scanner.next();
			System.out.println("Enter the Edition");
			String edition = scanner.next();
			System.out.println("Enter the type");
			String type = scanner.next();
			System.out.println("Enter the price");
			int price = scanner.nextInt();
			System.out.println("Enter the publisher");
			String publisher = scanner.next();
			BookDTO bookDTO = new BookDTO();

			bookDTO.setBookId(bookId);

			bookDTO.setAuthor(author);
			bookDTO.setBookName(bookName);
			bookDTO.setEdition(edition);
			bookDTO.setType(type);
			bookDTO.setPrice(price);
			bookDTO.setPublisher(publisher);

			library.addBooks(bookDTO);
			
		}
		scanner.close();
		library.getAllBooks();
		
	BookDTO bookDTO = 	library.getBookByAuthor("RKNarayan");
	System.out.println(bookDTO.getAuthor() + " "+ bookDTO.getBookId());
	}

}
