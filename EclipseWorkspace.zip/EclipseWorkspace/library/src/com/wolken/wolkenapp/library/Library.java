package com.wolken.wolkenapp.library;

import com.wolken.wolkenapp.library.dto.BookDTO;

public class Library {

	// instance variable
	public BookDTO[] bookDTO;
	public int index;

	public Library(int size) {
		// TODO Auto-generated constructor stub
		bookDTO = new BookDTO[size];
	}

	public void addBooks(BookDTO bookDTO) {
		if (bookDTO != null) {
			System.out.println("Books added in the library");
			this.bookDTO[index++] = bookDTO;
		
			
			//  this.bookDTO[0]  = bookDTO;
			//this.bookDTO[1] = bookDTO;
		} else {
			System.out.println("Book Object is null ... cannot add book details");
		}
	}

	public void getAllBooks() {
		for (int i = 0; i < bookDTO.length; i++) {
			System.out.println(bookDTO[i].getBookId() + "  " + bookDTO[i].getBookName() + "  " + bookDTO[i].getAuthor()
					+ "  " + bookDTO[i].getEdition() + "  " + bookDTO[i].getPublisher() + "  " + bookDTO[i].getPrice()
					+ "  " + bookDTO[i].getType());
		}
		
	}

	public BookDTO getBookByAuthor(String author) {
		BookDTO bookDTO = null;

		for (int i = 0; i < this.bookDTO.length; i++) {
			if (this.bookDTO[i] != null) {
				if (this.bookDTO[i].getAuthor().equals(author)) {
					bookDTO = this.bookDTO[i];
				} else {
					System.out.println("No author found ");
				}

			}

		}
		return bookDTO;
	}

	public void updatePriceByName(String bookName, int price) {
		for (int i = 0; i < this.bookDTO.length; i++) {
			if (this.bookDTO[i] != null) {
				if (this.bookDTO[i].getBookName().equalsIgnoreCase(bookName)) {
					this.bookDTO[i].setPrice(price);
				}

			} else {
				System.out.println("No Books found");
			}

		}
		return;

	}

	public void deleteBookByBookId(int bookId) {
		for (int i = 0; i < this.bookDTO.length; i++) {
			if (this.bookDTO[i] != null) {
				if (this.bookDTO[i].getBookId() == bookId) {

					this.bookDTO[i] = null;
				}

			} else {
				System.out.println("No Books found");
			}

		}
		return;

	}

}
