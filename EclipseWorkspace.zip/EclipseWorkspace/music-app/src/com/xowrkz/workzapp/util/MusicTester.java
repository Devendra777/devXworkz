package com.xowrkz.workzapp.util;

import java.util.Scanner;

import com.xowrkz.workzapp.app.Spotify;
import com.xowrkz.workzapp.app.constants.Language;

public class MusicTester {

	
	
	public static void main(String[] args) {
		
		
        Spotify app = new Spotify();
		 app.songs[0]="Khairiyat";
		 app.songs[1]="Marali Manasaagidhe";
		 app.songs[2]="Buttabomma";
		 app.songs[3]="Maari";
		 app.songs[4]="Kadhale";
		 app.songs[5]="Passion Fruit";
	    app.searchSongs(app.songs[0], Language.HINDI);
		 
		 
		 
		
		
	}
}
