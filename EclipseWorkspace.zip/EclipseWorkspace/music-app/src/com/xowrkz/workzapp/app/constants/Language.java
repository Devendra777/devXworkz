package com.xowrkz.workzapp.app.constants;

public enum Language {
  KANNADA, HINDI, ENGLISH, TAMIL
}
