package com.xowrkz.workzapp.app;

import com.xowrkz.workzapp.app.MusicApp;
import com.xowrkz.workzapp.app.constants.Language;

public class Spotify extends MusicApp{


      public static String  year="2020";
	

	@Override // annotations
	public void searchSongs(String songName , Language language)
	{
		if (year.equals("2020"))
		// calling super class searchSongs method
	    super.searchSongs(songName , language);
	}
	
	
}
