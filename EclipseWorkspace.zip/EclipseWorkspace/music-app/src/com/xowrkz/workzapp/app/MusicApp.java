package com.xowrkz.workzapp.app;

import com.xowrkz.workzapp.app.constants.Language;
//parent class or Super class or Base class
public class MusicApp {

	// private static final String langauge="HINDI";
	public String songs[] = new String[6];
	// public int index;

	/*
	 * public void addSongs(String song) { this.songs[index++] =song ; }
	 */
	public void searchSongs(String songName , Language language) {

		
		if(Language.HINDI.equals(language.HINDI ))
		// code
		for (int i = 0; i < songs.length; i++) {
			// null check
			if (songs[i] != null) {
				if (songs[i].equals(songName)) {
					System.out.println(songs[i]);
				}

			} else if ((songs[i] == null)) {
				System.out.println("No song found");

			}
		}
	}

}
