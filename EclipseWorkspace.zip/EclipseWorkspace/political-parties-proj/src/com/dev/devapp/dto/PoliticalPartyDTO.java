package com.dev.devapp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;

@Entity

@Table(name="political_party_table")

public class PoliticalPartyDTO implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="political_id")
	private  int politicalPartyId;
	@Column(name="political_name")
	private  String partyName;
	@Column(name="political_symbol")
	private  String partySymbol;
	@Column(name="political_type")
	private  String typesOfParties;
	
	
	public PoliticalPartyDTO() {
		// TODO Auto-generated constructor stub
	}


	public int getPoliticalPartyId() {
		return politicalPartyId;
	}


	public void setPoliticalPartyId(int politicalPartyId) {
		this.politicalPartyId = politicalPartyId;
	}


	public String getPartyName() {
		return partyName;
	}


	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}


	public String getPartySymbol() {
		return partySymbol;
	}


	public void setPartySymbol(String partySymbol) {
		this.partySymbol = partySymbol;
	}


	public String getTypesOfParties() {
		return typesOfParties;
	}


	public void setTypesOfParties(String typesOfParties) {
		this.typesOfParties = typesOfParties;
	}


	@Override
	public String toString() {
		return "PoliticalPartyDTO [politicalPartyId=" + politicalPartyId + ", partyName=" + partyName + ", partySymbol="
				+ partySymbol + ", typesOfParties=" + typesOfParties + "]";
	}

	
	

}
