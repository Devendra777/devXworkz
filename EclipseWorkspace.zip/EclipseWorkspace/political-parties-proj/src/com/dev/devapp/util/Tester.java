package com.dev.devapp.util;

import com.dev.devapp.dao.PoliticalPartyDAO;
import com.dev.devapp.dao.PoliticalPartyDAOImpl;
import com.dev.devapp.dto.PoliticalPartyDTO;

public class Tester {

	public static void main(String[] args) {

		PoliticalPartyDTO dto = new PoliticalPartyDTO();
		dto.setPartyName("BJP");
		dto.setTypesOfParties("Central");
		dto.setPartySymbol("Lotus");

		PoliticalPartyDAO dao = new PoliticalPartyDAOImpl();
		//dao.savePoliticalParty(dto);
		PoliticalPartyDTO dto2=	dao.fetchData(1);
	}

}
