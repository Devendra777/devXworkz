package com.dev.devapp.dao;

import com.dev.devapp.dto.PoliticalPartyDTO;

public interface PoliticalPartyDAO {
	
	
	public void savePoliticalParty(PoliticalPartyDTO partyDTO);
	public PoliticalPartyDTO fetchData(int id);
	

}
