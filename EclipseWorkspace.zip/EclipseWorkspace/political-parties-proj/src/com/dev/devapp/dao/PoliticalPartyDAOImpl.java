package com.dev.devapp.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.dev.devapp.dto.PoliticalPartyDTO;

public class PoliticalPartyDAOImpl implements PoliticalPartyDAO {

	// private SessionFactory factory = null;
	private StandardServiceRegistry standardServiceRegistry;

	public PoliticalPartyDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	/*
	 * @Override public void savePoliticalParty(PoliticalPartyDTO partyDTO) {
	 * Session session = null; Transaction tx = null; try { Configuration
	 * configuration = new Configuration(); configuration.configure(); factory =
	 * configuration.buildSessionFactory(); session = factory.openSession(); tx =
	 * session.beginTransaction(); session.save(partyDTO); tx.commit();
	 * session.close(); factory.close(); } catch (HibernateException e) { if (tx !=
	 * null) { tx.rollback(); } } }
	 */

	@Override
	public PoliticalPartyDTO fetchData(int id) {
		standardServiceRegistry = new StandardServiceRegistryBuilder().configure().build();
		MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
		Metadata metadata = metadataSources.getMetadataBuilder().build();
		SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();
		Session session = sessionFactory.openSession();
		PoliticalPartyDTO partyDTO = 	session.get(PoliticalPartyDTO.class, id);
	System.out.println(partyDTO);
		session.close();
		
		PoliticalPartyDTO partyDTO2 = 	session.get(PoliticalPartyDTO.class, id);
		System.out.println(partyDTO2);
		sessionFactory.close();
		return partyDTO;
	}

	@Override
	public void savePoliticalParty(PoliticalPartyDTO partyDTO) {
		// TODO Auto-generated method stub
		
	}

}
