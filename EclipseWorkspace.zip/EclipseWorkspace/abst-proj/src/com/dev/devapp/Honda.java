package com.dev.devapp;
//instantiated
public abstract class Honda {


	public abstract void start();
	
	
	
	public static void main(String[] args) {
		Honda honda = new Honda() 
	}
}
