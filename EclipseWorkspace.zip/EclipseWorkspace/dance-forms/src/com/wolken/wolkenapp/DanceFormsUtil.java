package com.wolken.wolkenapp;

public class DanceFormsUtil {
	
	static {
		System.out.println("static  block 1 is executed before main ");
		int baba = 9;
		System.out.println(baba);
		
	}
	static {
		System.out.println("static  block 2 is executed before main ");
		int baba = 9;
		System.out.println(baba);
		
	}

	public static void main(String[] args) {
		System.out.println("inside main ");
  // className ref  = new constructors
		DanceForms danceForms = new DanceForms("garba",45,"gujarat");
		
		/*
		 * DanceForms danceForms1 = new DanceForms("ghoomar",45,"Rajasthan"); DanceForms
		 * danceForms2 = new DanceForms("bihu",45,"Assam");
		 */
		
 
		
		System.out.println(danceForms.style + " " + danceForms.origin + " " + danceForms.noOfPerformers);
	}

}
