package com.wolken.wolkenapp;

public class DanceForms {

	// instance variables
	String style;
	int noOfPerformers;
	String origin;

	public DanceForms(String style, int noOfPerformers, String origin) {
		this.noOfPerformers = noOfPerformers;
		this.origin = origin;
		this.style = style;
		System.out.println("DanceForms Object is created");
	}
	
	static {
		System.out.println("inside block");
		int baba = 9;
		System.out.println(baba);
		
	}
	


}
