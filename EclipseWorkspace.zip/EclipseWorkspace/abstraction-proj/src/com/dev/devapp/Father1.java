package com.dev.devapp;

public interface Father1 {
	
	void care();
	
	

}
