package com.dev.devapp;

public interface ISwitch {
	void sOn();
	void sOff();
}
