package com.dev.devapp;

public class Tee {
	
	public boolean is;
	

	@Override
	public boolean equals(Object  tee){
		Tee tee2 = (Tee)tee;
		if(this.is == tee2.is)
		{
		return true;
		}
		return false;

	}
	
	
	public static void main(String[] args) {
		Tee tee = new Tee();
		tee.is=true;
		Tee tee1 = new Tee();
		tee1.is=false;
		System.out.println(tee.equals(tee1));
	}
	

}
