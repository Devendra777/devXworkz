package com.dev.devapp;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class MultipleTester {
	
	public static void main(String[] args) throws ParseException {
		
		  SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm:ss[.sss]((+|-) hh:mm |Z)");
         SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
         String formattedDob= simpleDateFormat.format(dateFormat.parse("2021-06-15T18:30:00.000Z"));
         
         
         
		 System.out.println(formattedDob);
        // System.out.println(dateFormat1);3.
	}

}
