package com.dev.devapp;


public interface Father2 extends ISwitch , Father1{
	

}
