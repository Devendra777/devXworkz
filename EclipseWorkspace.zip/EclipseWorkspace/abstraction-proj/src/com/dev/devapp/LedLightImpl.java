package com.dev.devapp;


// Implemntation class contains Implementation logic
public class LedLightImpl implements ISwitch{

	@Override
	public void sOn() {
		System.out.println("LedLight is Swiched On");// TODO Auto-generated method stub
		
	}

	@Override
	public void sOff() {
		// TODO Auto-generated method stub
		System.out.println("LedLight is Swiched OFF");
	}

}
