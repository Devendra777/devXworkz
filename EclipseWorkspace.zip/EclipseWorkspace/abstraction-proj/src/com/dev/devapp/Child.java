package com.dev.devapp;


public  class Child  implements  Father1 {

	@Override
	public void care() {
		// TODO Auto-generated method stub
		
	}
	/*
	 * @Override public void care() { // TODO Auto-generated method stub
	 * System.out.println("Child caring "); }
	 */
}