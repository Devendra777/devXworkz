package com.dev.devapp;

public class TubeLightImpl implements ISwitch{

	@Override
	public void sOn() {
		System.out.println("TubLight is Swiched On");
	}

	@Override
	public void sOff() {
		// TODO Auto-generated method stub
		System.out.println("TubLight is Swiched Off");
	}

	
	
	
}
