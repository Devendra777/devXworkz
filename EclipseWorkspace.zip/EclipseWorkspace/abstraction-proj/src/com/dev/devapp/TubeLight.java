package com.dev.devapp;

public class TubeLight {
	
	
	
	public Object s() {
		return "6";
	}
	
	@Override
	public boolean equals(Object obj) {
		if()
		return true;
	}

}
