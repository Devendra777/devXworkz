package com.dev.devapp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Scanner;

public class Tester {

	public static void main(String[] args) throws ParseException {

		Scanner sc = new Scanner(System.in);
		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);
		LocalDate date = LocalDate.parse("2018-04-10T04:00:00.000Z", inputFormatter);
		String formattedDate = outputFormatter.format(date);
		System.out.println(formattedDate); // prints 10-04-2018
		
		
		 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
         SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
         String formattedDob= simpleDateFormat.format(dateFormat.parse("2021-07-07T18:30:00.000Z"));
	
System.out.println(formattedDob);


        


	}

}
