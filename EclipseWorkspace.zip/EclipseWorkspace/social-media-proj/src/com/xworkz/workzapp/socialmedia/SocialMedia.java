package com.xworkz.workzapp.socialmedia;

//parent class or Base class or Super class
public class SocialMedia {

	
	protected String owner="Mark Zukerberg";
	
	// time waste , time pass , entertain , communicate ,
	//trap , promotions
	
protected SocialMedia() {
	// TODO Auto-generated constructor stub
}
	 
	protected void timeWaste()
	{
		System.out.println("Wasting the time of people in India");
	}
}
