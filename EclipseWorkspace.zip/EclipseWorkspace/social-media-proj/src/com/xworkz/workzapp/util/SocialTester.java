package com.xworkz.workzapp.util;

import com.xworkz.workzapp.socialmedia.SocialMedia;

public class SocialTester {

	public static void main(String[] args) {

		SocialMedia  gram = new SocialMedia();
    
	}
}
