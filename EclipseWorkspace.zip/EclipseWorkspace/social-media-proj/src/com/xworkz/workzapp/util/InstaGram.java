package com.xworkz.workzapp.util;

import com.xworkz.workzapp.socialmedia.SocialMedia;

public class InstaGram extends SocialMedia{

	
	public static void main(String[] args) {
		InstaGram gram = new InstaGram();
		System.out.println(gram.owner);
		gram.timeWaste();
		
	}
	
	
	
	
}
