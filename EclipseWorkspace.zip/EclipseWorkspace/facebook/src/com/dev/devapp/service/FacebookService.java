package com.dev.devapp.service;

import com.dev.devapp.dto.FaceBookDTO;

public interface FacebookService {
              
	public void validateAndSave(FaceBookDTO bookDTO);
	

}
