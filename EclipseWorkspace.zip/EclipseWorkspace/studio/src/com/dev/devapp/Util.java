package com.dev.devapp;

public class Util {

	public static void main(String[] args){
		System.out.println("main started");
		String baba = null;
		String babaOne = null;
	try {
		compare(baba, babaOne);
	}catch (ClassNotFoundException e) {
		// TODO: handle exception
		e.printStackTrace();
	}
		
		System.out.println("main ended");
	}

	public static void compare(String baba, String babaOne) throws ClassNotFoundException {
		
		compare(baba, babaOne);
		
	}
	
	
	

}
