package com.dev.devapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/vote", loadOnStartup = +9)
public class VoterServlet extends GenericServlet {

	
	public VoterServlet() {
		// TODO Auto-generated constructor stub
		System.out.println("servlet object is created");
	}

	@Override
	public void init(ServletConfig config) throws ServletException {

		System.out.println("Initialize the resources of servlet object");
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
System.out.println("post method is called");
		String name = req.getParameter("nm");
		String place = req.getParameter("pl");
		String age = req.getParameter("ag");
		
		int age1 = Integer.parseInt(age);

		PrintWriter printWriter = resp.getWriter();
		printWriter.print("Welcome " + name);
		// TODO Auto-generated method stub
		printWriter.flush();
		printWriter.close();
	}

	@Override
	public void destroy() {

		System.out.println("Closing all the costly resources");
	}

}
