package com.dev.devapp;

// Implementation class -- Contains Implementation Logic
public class CflBulbImpl implements ISwitch{

	@Override
	public void sOn() {
		System.out.println("CflBulb turned On");
	}

	@Override
	public void sOff() {
		System.out.println("CflBulb turned Off");
	}

}
