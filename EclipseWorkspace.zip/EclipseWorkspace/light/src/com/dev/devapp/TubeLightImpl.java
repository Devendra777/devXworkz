package com.dev.devapp;

//Implementation class 
public class TubeLightImpl implements ISwitch {

	@Override
	public void sOn() {
		System.out.println("TubeLight Turned oN");
	}

	@Override
	public void sOff() {
		System.out.println("TubeLight Turned off");
	}

}
