package com.dev.devapp;

// Factory Class-  Object Creation Logic
public class LightFactory {

	
	// factor Method
	public static ISwitch getLight(String type) {

		if (type.equalsIgnoreCase("tubelight")) {
			return new TubeLightImpl();
		}

		else if (type.equalsIgnoreCase("cflbulb")) {
			return new CflBulbImpl();
		}
		
		return null;
	}

}
