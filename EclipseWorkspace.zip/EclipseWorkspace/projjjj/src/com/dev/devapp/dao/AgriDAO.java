package com.dev.devapp.dao;

import com.dev.devapp.dto.AgriDTO;

public interface AgriDAO {
	
    public void saveAgri(AgriDTO dto);
    
    public void getAgri(int id);
	
	
	

}
