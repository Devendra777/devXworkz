package com.dev.devapp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.dev.devapp.dto.AgriDTO;

public class AgriDAOImpl implements AgriDAO {

	@Override
	public void saveAgri(AgriDTO dto) {

		Configuration configuration = new Configuration();
		configuration.configure();
		configuration.addAnnotatedClass(AgriDTO.class);
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(dto);
		tx.commit();
		session.close();
		sessionFactory.close();
		
		
		

	}

	@Override
	public void getAgri(int id) {
		Configuration configuration = new Configuration();
		configuration.configure();
		configuration.addAnnotatedClass(AgriDTO.class);
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
	//	Transaction tx = session.beginTransaction();
	AgriDTO dtoFromDb=	session.get(AgriDTO.class, id);
      	System.out.println(dtoFromDb);
		//tx.commit();
		session.close();
		sessionFactory.close();
	}

}
