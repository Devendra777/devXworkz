package com.dev.devapp.test;

import com.dev.devapp.dao.AgriDAO;
import com.dev.devapp.dao.AgriDAOImpl;
import com.dev.devapp.dto.AgriDTO;

public class Tester {
	
	
	public static void main(String[] args) {
		
		boolean y=true;
		boolean x= false ;
		
		if(x || y)
		{
			x=true ;
		}
		
		System.out.println(x);
		/*
		 * AgriDTO dto = new AgriDTO(); dto.setAgriId(3);
		 * dto.setDepartment("organic-farming"); dto.setLocation("davangere");
		 * dto.setState("Karnataka");
		 * 
		 * 
		 * AgriDAO dao = new AgriDAOImpl(); //dao.saveAgri(dto); dao.getAgri(2);
		 */
	}

}
