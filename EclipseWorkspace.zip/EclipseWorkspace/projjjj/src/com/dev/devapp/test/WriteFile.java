package com.dev.devapp.test;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import javax.swing.text.TabableView;

import org.hibernate.mapping.Table;

public class WriteFile {

	/*  *//**
			 * This class shows how to write file in java
			 * 
			 * @param args
			 * @throws IOException
			 */
	/*
	 * public static void main(String[] args) { String data =
	 * "I will write this String to File in Java"; int noOfLines = 10000;
	 * writeUsingFileWriter(data);
	 * 
	 * writeUsingBufferedWriter(data, noOfLines);
	 * 
	 * writeUsingFiles(data);
	 * 
	 * writeUsingOutputStream(data); System.out.println("DONE"); }
	 * 
	 *//**
		 * Use Streams when you are dealing with raw data
		 * 
		 * @param data
		 */
	/*
	 * private static void writeUsingOutputStream(String data) { OutputStream os =
	 * null; try { os = new FileOutputStream(new File("/Users/pankaj/os.txt"));
	 * os.write(data.getBytes(), 0, data.length()); } catch (IOException e) {
	 * e.printStackTrace(); }finally{ try { os.close(); } catch (IOException e) {
	 * e.printStackTrace(); } } }
	 * 
	 *//**
		 * Use Files class from Java 1.7 to write files, internally uses OutputStream
		 * 
		 * @param data
		 */
	/*
	 * private static void writeUsingFiles(String data) { try {
	 * Files.write(Paths.get("/Users/pankaj/files.txt"), data.getBytes()); } catch
	 * (IOException e) { e.printStackTrace(); } }
	 * 
	 *//**
		 * Use BufferedWriter when number of write operations are more It uses internal
		 * buffer to reduce real IO operations and saves time
		 * 
		 * @param data
		 * @param noOfLines
		 */
	/*
	 * private static void writeUsingBufferedWriter(String data, int noOfLines) {
	 * File file = new File("/Users/pankaj/BufferedWriter.txt"); FileWriter fr =
	 * null; BufferedWriter br = null; String
	 * dataWithNewLine=data+System.getProperty("line.separator"); try{ fr = new
	 * FileWriter(file); br = new BufferedWriter(fr); for(int i = noOfLines; i>0;
	 * i--){ br.write(dataWithNewLine); } } catch (IOException e) {
	 * e.printStackTrace(); }finally{ try { br.close(); fr.close(); } catch
	 * (IOException e) { e.printStackTrace(); } } }
	 * 
	 *//**
		 * Use FileWriter when number of write operations are less
		 * 
		 * @param data
		 *//*
			 * private static void writeUsingFileWriter(String data) { File file = new
			 * File("C:/Users/AG49183/Documents/FileWriter.txt"); FileWriter fr = null; try
			 * { fr = new FileWriter(file); fr.write(data); } catch (IOException e) {
			 * e.printStackTrace(); }finally{ //close resources try { fr.close(); } catch
			 * (IOException e) { e.printStackTrace(); } } }
			 */

	/**
	 * This class shows how to create a File in Java
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		PrintWriter printWriter=null;
		// absolute file name with path
		String absoluteFilePath = "file.txt";
		System.out.println(absoluteFilePath);
		File file = new File(absoluteFilePath);

		// file name only
		if (!file.exists()) {
			file.createNewFile();
			printWriter = new  PrintWriter(file);
			printWriter.write(String.format("%20s %20s \r\n", "column 1", "column 2"));
			printWriter.write(String.format("%20s %20s \r\n", "data 1", "data 2"));
			Tab
		} else
			System.out.println("File file.txt already exists in the project root directory");
		
		
			if(Objects.nonNull(printWriter))
			{
				printWriter.flush();
				printWriter.close();
			}

	}
	
}
