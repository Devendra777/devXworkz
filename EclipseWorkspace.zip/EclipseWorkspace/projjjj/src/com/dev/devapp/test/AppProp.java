package com.anthem.pcms;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="APLCTN_PRPTY")
public class AppProp {
	
	@Id
	@Column(name="APLCTN_PRPTY_ID")
	private int id;

	@Column(name="APLCTN_PRPTY_KEY")
	private String key;
	
	@Column(name="APLCTN_PRPTY_NM")
	private String name;
	
	@Column(name="APLCTN_PRPTY_OWNR_NM")
	private String owner;

	@Column(name="APLCTN_PRPTY_VAL_TXT")
	private String value;

	@Column(name="PROV_GRP_ID")
	private String providerGroupId;

	@Column(name="UPDT_USER_ID")
	private String updateUserId;

	@Column(name="UPDT_TMS")
	private Date updateTimestamp;

	@Column(name="CMNT_TXT")
	private String comment;

	@Column(name="APLCTN_PRPTY_TYPE_CD")
	private String propertyTypeCode;

	@Column(name="ACS_TYPE_CD")
	private String acsTypeCode;

	@Column(name="APLCTN_PRPTY_CTGRY_NM")
	private String propertyCategoryName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getProviderGroupId() {
		return providerGroupId;
	}

	public void setProviderGroupId(String providerGroupId) {
		this.providerGroupId = providerGroupId;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String propertyKey) {
		this.key = propertyKey;
	}

	public String getPropertyTypeCode() {
		return propertyTypeCode;
	}

	public void setPropertyTypeCode(String propertyTypeCode) {
		this.propertyTypeCode = propertyTypeCode;
	}

	public String getAcsTypeCode() {
		return acsTypeCode;
	}

	public void setAcsTypeCode(String acsTypeCode) {
		this.acsTypeCode = acsTypeCode;
	}

	public String getPropertyCategoryName() {
		return propertyCategoryName;
	}

	public void setPropertyCategoryName(String propertyCategoryName) {
		this.propertyCategoryName = propertyCategoryName;
	}
	
	@Override
	public String toString() {
		return id + "|"
			+ key + "|"
			+ owner + "|"
			+ name + "|"
			+ value + "|"
			+ providerGroupId + "|"
			+ updateUserId + "|"
			+ updateTimestamp + "|"
			+ comment + "|"
			+ propertyTypeCode + "|"
			+ acsTypeCode + "|"
			+ propertyCategoryName;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof AppProp)) {
			return false;
		}
		
		AppProp other = (AppProp)obj;
		if (different(getOwner(), other.getOwner())
		|| different(getName(), other.getName())
		|| different(getValue(), other.getValue())
		|| different(getAcsTypeCode(), other.getAcsTypeCode())
		|| different(getComment(), other.getComment())
		|| different(getPropertyCategoryName(), other.getPropertyCategoryName())
		|| different(getPropertyTypeCode(), other.getPropertyTypeCode())
		|| different(getProviderGroupId(), other.getProviderGroupId())
		|| different(getUpdateUserId(), other.getUpdateUserId())) {
			return false;
		}
		
		return true;
	}
	
	private boolean different(Object value1, Object value2) {
		if (value1 == null && value2 == null) {
			return false;
		}
		
		if (value1 == null || value2 == null) {
			return true;
		}
		
		return !value1.equals(value2);
	}
}
