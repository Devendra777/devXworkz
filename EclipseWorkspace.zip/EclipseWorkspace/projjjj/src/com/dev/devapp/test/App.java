package com.anthem.pcms;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App {
	private static SimpleDateFormat sdfDB2Timestamp = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
	
	public static void main(String[] args) {

		HashMap<String, String> dbUrls = new HashMap<String, String>();
	//	dbUrls.put("PROD", "jdbc:db2://va10p10046:30500/pc2rptdb:currentSchema=PC2WEB_RPT_ACTV;");
	//	dbUrls.put("PERF", "jdbc:db2://va10n10085:30500/pc2rptdb:currentSchema=PC2WEB_RPT_ACTV;");
	//	dbUrls.put("UAT", "jdbc:db2://va10n10087:30500/pc2rptdb:currentSchema=PC2WEB_RPT_ACTV;");
		dbUrls.put("SIT", "jdbc:db2://va10n10047:30400/pc2rptdb:currentSchema=PC2WEB_RPT_ACTV;retrieveMessagesFromServerOnGetMessage=true;sslConnection=true;sslTrustStoreLocation=C:/Users/AG49183/jdbc/db2/PCMS_Keystore.jks;");
	//	dbUrls.put("SITSSL", "jdbc:db2://va10n10047:30410/PCRPSITN:currentSchema=PC2WEB_RPT_ACTV;retrieveMessagesFromServerOnGetMessage=true;sslConnection=true;sslTrustStoreLocation=C:/Users/af45334/jdbc/db2/PCMS_Keystore.jks;");
	//	dbUrls.put("SITLO", "jdbc:db2://va10n10047:30400/pc2rptlo:currentSchema=PC2WEB_RPT_ACTV;");
		dbUrls.put("DEV", "jdbc:db2://va10duvdb2006:30100/pc2rptdb:currentSchema=PC2WEB_RPT_ACTV;");
		
		File outputFile = null;
		boolean validFile = true;
		boolean generateDeletes = false;
		System.out.println(args.length);
		if (args.length >= 2) {
			 outputFile = new File("output.txt");
			
			try {
				if (!outputFile.exists() && !outputFile.createNewFile()) {
					validFile = false;
				}
			}
			catch (IOException e) {
				validFile = false;
			}
		}
		System.out.println(args.length);
		if (args.length < 1 || args.length > 2 || !dbUrls.containsKey(args[0].toUpperCase()) || 
			!dbUrls.containsKey(args[1].toUpperCase()) || !validFile ||
			args.length == 2 && !args[1].toLowerCase().equals("delete")) {
			if (outputFile != null && !validFile) {
				System.out.println("Output file can not be written to: " + outputFile.getAbsolutePath());
			}
			
			System.out.println("Usage: source destination username password outputfile [delete]");
			System.out.println("   valid values for source/destination:");
			for (String key : dbUrls.keySet()) {
				System.out.println("   " + key);
			}
			
			System.out.println("Example: UAT SIT YourUsername YourPassword c:\\Users\\AG49183\\output.sql"); 
			
			
		}
		
		if (args.length == 2) {
			generateDeletes = true;
		}
		
		
		String sourceUrl = dbUrls.get(args[0].toUpperCase());
		System.out.println(sourceUrl);
		String destUrl = dbUrls.get(args[1].toUpperCase());
		System.out.println(destUrl);
		String username = args[2];
		System.out.println(username);
		String password = args[3];
		System.out.println(password);
		
		process(sourceUrl, destUrl, username, password, outputFile, generateDeletes);
		
	}
	
	private static void process(String sourceUrl, String destUrl, String username, String password, File outputFile, boolean generateDeletes) {
		
		try {
	        EntityManager sourceEM = getSourceEntityManager(sourceUrl, username, password);
	        List<AppProp> sourceList = getApplicationPropertiesList(sourceEM);
	        sourceEM.close();
	        Map<String, AppProp> sourceMap = getApplicationPropertiesMap(sourceList);
	        if (!validateSource(sourceList)) {
	        	System.out.println("Exiting - source did not validate");
	        	return;
	        }
	        System.out.println("Generate delete statements: " + generateDeletes);
	        System.out.println("Source size: " + sourceList.size());
	        
	        EntityManager destEM = getDestinationEntityManager(destUrl, username, password);
	        List<AppProp> destList = getApplicationPropertiesList(destEM);
	        destEM.close();
			Map<String, AppProp> destMap = getApplicationPropertiesMap(destList);
			System.out.println("Dest size: " + destMap.size());
	        
	        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
	        for (AppProp sourceAp : sourceList) {
	        	if (environmentSpecific(sourceAp)) {
	        		continue;
	        	}
	        	
	        	if (destMap.containsKey(sourceAp.getKey())) {
	        		AppProp destAp = destMap.get(sourceAp.getKey());
	        		if (!destAp.equals(sourceAp)) {
	        			// sourceAp is in destination but has been updated so create update statement
	        			System.out.println("Found in dest but updated: " + sourceAp.getKey() + " | " + sourceAp.getOwner() + " | " + sourceAp.getName() + " | " + sourceAp.getUpdateTimestamp());
	        			writer.write(createUpdate(sourceAp, destAp.getId()));
	        			writer.write("\n\n");
	        		}
	        	}
	        	else {
	        		// sourceAp is not in destination so create insert statement
	        		System.out.println("Not found in dest: " + sourceAp.getKey() + " | " + sourceAp.getOwner() + " | " + sourceAp.getName() + " | " + sourceAp.getUpdateTimestamp());
	        		writer.write(createInsert(sourceAp));
	        		writer.write("\n\n");
	        	}
	        }
	        
	        if (generateDeletes) {
	        	// generate delete statements for rows in destination but not in source
		        for (AppProp destAp : destList) {
		        	if (!sourceMap.containsKey(destAp.getKey()) && !environmentSpecific(destAp)) {
		        		// destination row not in source so create delete statement
		        		System.out.println("Dest not in source: " + destAp.getKey() + " | " + destAp.getOwner() + " | " + destAp.getName() + " | " + destAp.getUpdateTimestamp());
		        		writer.write(createDelete(destAp.getId()));
	        			writer.write("\n\n");
		        	}
		        }
	        }
	        
	        writer.close();
	        
	        System.out.println("\nFinished. Output written to: " + outputFile.getAbsolutePath());

		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	private static String createDelete(int id) {
		StringBuffer sb = new StringBuffer();
		sb.append("DELETE FROM APLCTN_PRPTY ");
		sb.append("WHERE APLCTN_PRPTY_ID = ").append(id);
		sb.append(";");
		
		return sb.toString();
	}
	
	private static String createUpdate(AppProp ap, int id) {
		StringBuffer sb = new StringBuffer();
		sb.append("UPDATE APLCTN_PRPTY ");
		sb.append("SET APLCTN_PRPTY_OWNR_NM = ").append(stringSQLValue(ap.getOwner())).append(", ");
		sb.append("APLCTN_PRPTY_NM = ").append(stringSQLValue(ap.getName())).append(", ");
		sb.append("APLCTN_PRPTY_VAL_TXT = ").append(stringSQLValue(ap.getValue())).append(", ");
		sb.append("PROV_GRP_ID = ").append(stringSQLValue(ap.getProviderGroupId())).append(", ");
		sb.append("UPDT_USER_ID = ").append(stringSQLValue(ap.getUpdateUserId())).append(", ");
		sb.append("UPDT_TMS = ").append(timestampSQLValue(ap.getUpdateTimestamp())).append(", ");
		sb.append("CMNT_TXT = ").append(stringSQLValue(ap.getComment())).append(", ");
		sb.append("APLCTN_PRPTY_TYPE_CD = ").append(stringSQLValue(ap.getPropertyTypeCode())).append(", ");
		sb.append("ACS_TYPE_CD = ").append(stringSQLValue(ap.getAcsTypeCode())).append(", ");
		sb.append("APLCTN_PRPTY_CTGRY_NM = ").append(stringSQLValue(ap.getPropertyCategoryName())).append(" ");
		sb.append("WHERE APLCTN_PRPTY_ID = ").append(id);
		sb.append(";");
		
		return sb.toString();
	}
	
	private static String createInsert(AppProp ap) {
		StringBuffer sb = new StringBuffer();
		sb.append("INSERT INTO APLCTN_PRPTY ")
			.append("(APLCTN_PRPTY_ID, APLCTN_PRPTY_KEY, APLCTN_PRPTY_NM, APLCTN_PRPTY_OWNR_NM, APLCTN_PRPTY_VAL_TXT, PROV_GRP_ID, UPDT_USER_ID, ")
			.append("UPDT_TMS, CMNT_TXT, APLCTN_PRPTY_TYPE_CD, ACS_TYPE_CD, APLCTN_PRPTY_CTGRY_NM) ") 
			.append("VALUES (");
		
		sb.append("(select max(APLCTN_PRPTY_ID)+1 from APLCTN_PRPTY)").append(", ");
		sb.append(stringSQLValue(ap.getKey())).append(", ");
		sb.append(stringSQLValue(ap.getName())).append(", ");
		sb.append(stringSQLValue(ap.getOwner())).append(", ");
		sb.append(stringSQLValue(ap.getValue())).append(", ");
		sb.append(stringSQLValue(ap.getProviderGroupId())).append(", ");
		sb.append(stringSQLValue(ap.getUpdateUserId())).append(", ");
		sb.append(timestampSQLValue(ap.getUpdateTimestamp())).append(", ");
		sb.append(stringSQLValue(ap.getComment())).append(", ");
		sb.append(stringSQLValue(ap.getPropertyTypeCode())).append(", ");
		sb.append(stringSQLValue(ap.getAcsTypeCode())).append(", ");
		sb.append(stringSQLValue(ap.getPropertyCategoryName()));
		sb.append(");");
		
		return sb.toString();
	}

	/**
	 * Check the values of ap to determine if it is an environment specific row
	 * @param ap to check if it is environment specific
	 * @return true if value is environment specific, false otherwise
	 */
	private static boolean environmentSpecific(AppProp ap) {
		// TODO get the environment specific owner/names from Vignesh, return true if matched
		return false;
	}



	private static String escapeSQLString(String value) {
		if (value == null) {
			return null;
		}
		
		return value.replaceAll("'", "''");
	}
	
	private static String stringSQLValue(String value) {
		if (value == null) {
			return null;
		}
		
		return "'" + escapeSQLString(value) + "'";
	}
	
	
	private static String timestampSQLValue(Date value) {
		if (value == null) {
			return null;
		}
		
		return "TIMESTAMP('" + sdfDB2Timestamp.format(value) + "')";
	}
	
	
	
	
	private static boolean validateSource(List<AppProp> list) {
		boolean valid = true;
		Set<String> set = new HashSet<String>();
		for (AppProp ap : list) {
			if (ap.getKey() == null) {
				System.out.println("null key found: " + ap.toString());
				valid = false;
			}
			else if (set.contains(ap.getKey())) {
				System.out.println("duplicate key found: " + ap.toString());
				valid = false;
			}
			else {
				set.add(ap.getKey());
			}
		}
		
		return valid;
	}

	@SuppressWarnings("unchecked")
	private static List<AppProp> getApplicationPropertiesList(EntityManager em) {
		return em.createQuery("select a from AppProp a").getResultList();
	}
	
	private static Map<String, AppProp> getApplicationPropertiesMap(List<AppProp> list) {
		Map<String, AppProp> map = new HashMap<>();
        for (AppProp ap : list) {
            map.put(ap.getKey(), ap);
        }
        
        return map;
	}
	
	private static EntityManager getSourceEntityManager(String url, String username, String password) {
		Properties props = new Properties();
		props.put("javax.persistence.jdbc.url", url);
		props.put("javax.persistence.jdbc.user", username);
		props.put("javax.persistence.jdbc.password", password);
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("source", props);
        return factory.createEntityManager();
	}
	
	private static EntityManager getDestinationEntityManager(String url, String username, String password) {
		Properties props = new Properties();
		props.put("javax.persistence.jdbc.url", url);
		props.put("javax.persistence.jdbc.user", username);
		props.put("javax.persistence.jdbc.password", password);
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("source", props);
        return factory.createEntityManager();
	}
	
}
