package com.dev.devapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/final")
public class FinalServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String moblieName = (String) req.getAttribute("mn");
		String quantity = (String) req.getAttribute("quan");
		double price = (Integer.parseInt(quantity) * 70000.00);

		PrintWriter printWriter = resp.getWriter();
		printWriter.print("Thank you for shopping with us - Ua amount is  " + price);
		// TODO Auto-generated method stub
		printWriter.flush();
		printWriter.close();
	}

}
