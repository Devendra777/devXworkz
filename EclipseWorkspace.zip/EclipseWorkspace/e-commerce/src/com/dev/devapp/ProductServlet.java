package com.dev.devapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/prod") // url-pattern
public class ProductServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		System.out.println("post method is called");
		String mobileName = req.getParameter("mb");
		String quantity = req.getParameter("qt");

		// req scope
		req.setAttribute("mn", mobileName);
		req.setAttribute("quan", quantity);

		RequestDispatcher dispatcher = req.getRequestDispatcher("final.jsp");
		dispatcher.forward(req, resp);

	}
}
