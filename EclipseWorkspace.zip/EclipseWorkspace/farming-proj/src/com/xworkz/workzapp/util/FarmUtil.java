package com.xworkz.workzapp.util;

import java.util.Scanner;

import com.xworkz.workzapp.farm.FarmDTO;
import com.xworkz.workzapp.farm.Operation;

public class FarmUtil {

	public static void main(String[] args) {

		/*
		 * FarmDTO farmOne = new FarmDTO("black", "2 acre", "peanuts"); FarmDTO farmTwo
		 * = new FarmDTO("red", "1 acre", "cotton"); FarmDTO farmThree = new
		 * FarmDTO("brown", "30*40", "sunflower");
		 */
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Farm size");
		int size = sc.nextInt();
		Operation operation = new Operation(size);
		for (int i =0; i < size; i++) {
			FarmDTO dto = new FarmDTO();
			System.out.println("Enter the " + (i + 1) + " Farm Details");
			System.out.println("Enter the type Of Soil");
			String typeOfSoil =sc.next();
			System.out.println("Enter the Area");
			String area = sc.next();
			System.out.println("Enter the type Of crop");
			String typeOfCrop = sc.next();
			  sc.close();
			dto.setTypeOfSoil(typeOfSoil);
			dto.setArea(area);
			dto.setTypeOfCrop(typeOfCrop);

			operation.addFarmDetails(dto);

		}
		
		operation.showAllFarmDetails();
    
	}

}
