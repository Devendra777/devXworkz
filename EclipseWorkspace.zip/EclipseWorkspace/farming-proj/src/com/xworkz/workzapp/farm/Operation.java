package com.xworkz.workzapp.farm;

public class Operation {

	// instance
	public FarmDTO[] farmDTOs;

	public int index;

	public Operation(int size) {
		farmDTOs = new FarmDTO[size];
	}

	public void addFarmDetails(FarmDTO farmDTO) {

		System.out.println("adding Farm Details");
		farmDTOs[index++] = farmDTO;
		System.out.println("added all the farms Details");
	}

	public void showAllFarmDetails() {
		for (int i = 0; i < farmDTOs.length; i++) {
			if (farmDTOs[i] != null) {
				System.out.println(farmDTOs[i].getTypeOfSoil() + "  " 
			+ farmDTOs[i].getArea() + " " + farmDTOs[i].getTypeOfCrop());
			} else {
				System.out.println("Please add the form details");
			}

		}

	}
	
	public void showFarmDetailsByCrop() {
		for (int i = 0; i < farmDTOs.length; i++) {
			if (farmDTOs[i] != null) {
				
				
				System.out.println(farmDTOs[i].getTypeOfSoil() + "  " 
			+ farmDTOs[i].getArea() + " " + farmDTOs[i].getTypeOfCrop());
			} else {
				System.out.println("Please add the form details");
			}

		}

	}
	
	
	
	
	
	
}
