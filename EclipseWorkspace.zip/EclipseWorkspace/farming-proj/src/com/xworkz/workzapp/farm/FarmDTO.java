package com.xworkz.workzapp.farm;

public class FarmDTO {
	
	private  String typeOfSoil;
	private  String area;
	private String typeOfCrop;

	public String getTypeOfSoil() {
		return typeOfSoil;
	}


	public void setTypeOfSoil(String typeOfSoil) {
		this.typeOfSoil = typeOfSoil;
	}


	public String getArea() {
		return area;
	}


	public void setArea(String area) {
		this.area = area;
	}


	public String getTypeOfCrop() {
		return typeOfCrop;
	}


	public void setTypeOfCrop(String typeOfCrop) {
		this.typeOfCrop = typeOfCrop;
	}

	
	
	
	

}
