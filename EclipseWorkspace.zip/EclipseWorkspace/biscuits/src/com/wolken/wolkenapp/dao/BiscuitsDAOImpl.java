package com.wolken.wolkenapp.dao;

import java.util.ArrayList;
import java.util.List;

import com.wolken.wolkenapp.dto.BiscuitsDTO;

public class BiscuitsDAOImpl implements BiscuitsDAO {
	
	List<BiscuitsDTO> biscuitsDTOs;

	public BiscuitsDAOImpl(List<BiscuitsDTO> biscuitsDTOs) {
		// TODO Auto-generated constructor stub
		this.biscuitsDTOs = biscuitsDTOs;
	}

	@Override
	public void save(BiscuitsDTO biscuitsDTO) {
		boolean check = biscuitsDTOs.contains(biscuitsDTO);
		if (!check) {
			this.biscuitsDTOs.add(biscuitsDTO);
			System.out.println("Biscuits added into the list");
		} else {
			System.out.println("not added into the list");
		}
	}

}
