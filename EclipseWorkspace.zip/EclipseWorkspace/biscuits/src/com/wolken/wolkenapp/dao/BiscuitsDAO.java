package com.wolken.wolkenapp.dao;

import com.wolken.wolkenapp.dto.BiscuitsDTO;

public interface BiscuitsDAO {

   public void save(BiscuitsDTO biscuitsDTO);
}
