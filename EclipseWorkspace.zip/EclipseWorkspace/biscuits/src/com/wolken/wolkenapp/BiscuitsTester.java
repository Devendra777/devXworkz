package com.wolken.wolkenapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


import com.wolken.wolkenapp.dto.BiscuitsDTO;

public class BiscuitsTester {

	public static void main(String[] args) {
	
		
		
		Map< String, BiscuitsDTO> biscuitsDTOs  = new HashMap< String,BiscuitsDTO>();
		/*
		 * BiscuitsDAO biscuitsDAO = new BiscuitsDAOImpl(biscuitsDTOs); BiscuitsService
		 * biscuitsService = new BiscuitsServiceImpl(biscuitsDAO);
		 * biscuitsService.validateAndSave(biscuitsDTO);
		 * 
		 */
		
		BiscuitsDTO biscuitsDTO = new BiscuitsDTO();
		biscuitsDTO.setId(89);
		biscuitsDTO.setBrand("Parle");
		biscuitsDTO.setPrice(34.01);
		biscuitsDTO.setQuantity(-10);
		biscuitsDTO.setName("HideAndSeek");
		
		BiscuitsDTO biscuitsDTO1 = new BiscuitsDTO();
		biscuitsDTO1.setId(56);
		biscuitsDTO1.setBrand("Cadburry");
		biscuitsDTO1.setPrice(34.07);
		biscuitsDTO1.setQuantity(-10);
		biscuitsDTO1.setName("HideAndSeek");
		
		BiscuitsDTO biscuitsDTO3 = new BiscuitsDTO();
		biscuitsDTO3.setId(1);
		biscuitsDTO3.setBrand("Britannia");
		biscuitsDTO3.setPrice(34.04);
		biscuitsDTO3.setQuantity(-10);
		biscuitsDTO3.setName("HideAndSeek");
	
		biscuitsDTOs.put("1",biscuitsDTO);
		biscuitsDTOs.put("2", biscuitsDTO1);
		biscuitsDTOs.put("3", biscuitsDTO3);
		
		/*
		 * biscuitsDTOs.forEach(System.out::println);
		 * System.out.println("--------------------------");
		 * Collections.sort(biscuitsDTOs); biscuitsDTOs.forEach(System.out::println);
		 */
		
		
		for (Map.Entry<String,BiscuitsDTO> string : biscuitsDTOs.entrySet()) {
			System.out.println(string.getKey() + " "+ string.getValue());
			
		}
		
		
//		for (int i = 0; i < biscuitsDTOs.size(); i++) {
//			
//		}
//		for (String string : biscuitsDTOs) {
//			
//		}
		
	//	System.out.println(biscuitsDTOs.containsValue(biscuitsDTO3));
		
		System.out.println(biscuitsDTOs.keySet());
		
		
		//BrandComparator brandComparator = new BrandComparator();
		/*
		 * Collections.sort(biscuitsDTOs , new BrandComparator());
		 * System.out.println("------------------------");
		 * biscuitsDTOs.forEach(System.out::println);
		 */
	}

}
