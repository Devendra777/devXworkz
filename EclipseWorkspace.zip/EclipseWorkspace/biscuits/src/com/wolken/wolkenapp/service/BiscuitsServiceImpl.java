package com.wolken.wolkenapp.service;

import com.wolken.wolkenapp.dao.BiscuitsDAO;
import com.wolken.wolkenapp.dto.BiscuitsDTO;

public class BiscuitsServiceImpl implements BiscuitsService {

	public BiscuitsDAO biscuitsDAO;
	
	public BiscuitsServiceImpl(BiscuitsDAO biscuitsDAO) {
		// TODO Auto-generated constructor stub
		this.biscuitsDAO  = biscuitsDAO;
	}
	

	@Override
	public boolean validateAndSave(BiscuitsDTO biscuitsDTO) {
		boolean check = false;
		if (biscuitsDTO != null) {
			String brand = biscuitsDTO.getBrand();
			if (brand != null && !brand.isEmpty() && !brand.contains(" ")) {
				check = true;
				System.out.println("brand is valid");
			}
			
			if (check) {
				int quantity = biscuitsDTO.getQuantity();
				if (quantity > 0) {
					System.out.println("quantity is valid");
					check = true;
				} else {
					System.out.println("quantity is not valid");
					check = false;
				}
			}
			if (check) {
				double price = biscuitsDTO.getPrice();
				if (price > 0 && price <= 100) {
					check = true;
					System.out.println("price is valid");
				} else {
					System.out.println("price is not valid");
					check = false;
				}
			}
			if(check)
			{
			biscuitsDAO.save(biscuitsDTO);
			check  = true;
		}
			else {
				check =  false;
				System.out.println("Dto is not valid!!");
				}
			}
		return check;
	}
}