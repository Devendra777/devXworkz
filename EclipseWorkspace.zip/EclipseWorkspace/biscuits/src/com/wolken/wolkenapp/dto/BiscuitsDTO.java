package com.wolken.wolkenapp.dto;

import java.io.Serializable;

public class BiscuitsDTO implements Comparable<BiscuitsDTO> , Serializable{

	private int id;
	private String name;
	private String brand;
	private Integer quantity;
	private Double price;
	
	public BiscuitsDTO() {
		// TODO Auto-generated constructor stub
	}

	
	
	public void setBrand(String brand) {
		this.brand = brand;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public String getBrand() {
		return brand;
	}

	public String getName() {
		return name;
	}

	public int getQuantity() {
		return quantity;
	}
	
	public Double getPrice() {
		return price;
	}
	
	public void setPrice(Double price) {
		this.price = price;
	}


@Override
public int hashCode() {
	// TODO Auto-generated method stub
	return id;
}

	@Override
	public int compareTo(BiscuitsDTO o) {
		// TODO Auto-generated method stub
		return this.hashCode() - o.hashCode();
	}



	@Override
	public String toString() {
		return "BiscuitsDTO [id=" + id + ", name=" + name + ", brand=" + brand + ", quantity=" + quantity + ", price="
				+ price + "]";
	}
	
	

}
