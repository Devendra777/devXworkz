package com.dev.devapp;

public class Basics {
	
	
	
        int k=101;  /// instance  variable
	
     
	
	int  add()
	{
		int a=10;
		int b=9;
		int result=a+b+k;// local variable
		System.out.println(result);
		return result;		
	}
	
	
	
	
	void sub()
	{
		int a=10;
		int b=9;
		int result=a-b-k;
		System.out.println(result);
	}

	
	//a=20;


}
/*
 * data types --- 2 types premitive data type (int , float , double , boolean ,
 * char , short , byte , long) and Non- premitive
 */