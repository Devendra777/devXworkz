package com.dev.devapp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestePrint {

	public static void main(String[] args) {

		List<Printer> list = new ArrayList<>();
		list.add(new Printer(1, "Epson", 1000.00));
		list.add(new Printer(2, "sony", 10000.00));
		list.add(new Printer(3, "hp", 100000.00));
		list.add(new Printer(4, "bp", 100000.00));
		list.add(new Printer(4, "bp", 100000.00));
		list.add(new Printer(4, "bp", 100000.00));
		list.add(new Printer(4, "bp", 100000.00));
		list.add(new Printer(4, "bp", 100000.00));
		list.add(new Printer(4, "bp", 100000.00));
		list.add(new Printer(4, "bp", 100000.00));
		v
		

		Iterator iterator = list.iterator();
		while (iterator.hasNext()) {
			Printer object = (Printer) iterator.next();
			System.out.println(object);
		}

	}

}
