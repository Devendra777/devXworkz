package com.dev.devapp;

public class LegatoBuilding {
	
	
   //states of l1 building , noOfFloors , address  , noofEmployees
	//Behavoir 
	
	public LegatoBuilding() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	/* static */
	static int noOfFloors =10;
static 	String name ="L1 Building";
	
	//states -- variables
	//behavoirs - -- methods
	
	
	
   void 	giveWork()
	{
		//code
	   //perform some specific task
	  
	}
   
   
    void   parkVehicle()
   {
    	System.out.println("Parking Vehicles");
	   
   }
	
	//<return type>    
	
	
	
    
    

}
