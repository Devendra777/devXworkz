package com.dev.devapp;

public class Tester {

	
	
	
	
	public static void main(String[] args) {
		
		   
		/*
		 * LegatoBuilding legatoBuilding= new LegatoBuilding();
		 */
		
		
		
System.out.println(LegatoBuilding.name + "    "  +   LegatoBuilding.noOfFloors);
	
		
		
		
	}
}
