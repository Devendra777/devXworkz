package com.dev.devapp;

public class Utillllll {

	
	
	public static void main(String[] args) {
		String  police="sweetPolice";
		Object nama=police;
		//downcasting 
		   String mainNama=    (String) nama;
		   
		   Object object;
		   
		System.out.println(mainNama);
		         
	}
}
