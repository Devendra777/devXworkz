package com.xworkz.xworkzapp.util;


public class BeachUtil {
	
	public static void main(String[] args) {
		
		
	}

}
