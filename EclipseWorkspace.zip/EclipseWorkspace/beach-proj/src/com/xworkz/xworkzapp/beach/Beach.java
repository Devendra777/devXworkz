package com.xworkz.xworkzapp.beach;

public class Beach {
	

	
	
	public Beach() {
		// TODO Auto-generated constructor stub
	}
	
	

}
