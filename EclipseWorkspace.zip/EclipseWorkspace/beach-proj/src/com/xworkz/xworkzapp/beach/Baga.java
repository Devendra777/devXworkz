package com.xworkz.xworkzapp.beach;

public class Baga extends Beach{

	
	public Baga() {
		// TODO Auto-generated constructor stub
	}
	
	
}
