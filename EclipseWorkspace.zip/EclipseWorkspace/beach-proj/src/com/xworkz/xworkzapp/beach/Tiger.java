package com.xworkz.xworkzapp.beach;

public class Tiger {
	
	int i;

	public Tiger() {
	}

	public Tiger(int i) {
		this.i = i;
	}
	
	

}
