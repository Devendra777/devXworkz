package com.xworkz.xworkzapp.beach;

public class Malpe extends Beach{
	
	
	Object
	
	public void enjoy(int noOfCafe)
	{
		System.out.println("Entering inside enjoy method of Malpe");
		
		super.enjoyWithFreinds();
		System.out.println("End of  enjoy method of Malpe");
	}

	
}
