package com.xworkz.workzapp.calci;

//Super class or Parent class or Base class
public class Calculator {

	public void add(int a, int b) {
		System.out.println(a + b);
	}

	public void sub(int a, int b) {
		System.out.println(a - b);
	}

}
