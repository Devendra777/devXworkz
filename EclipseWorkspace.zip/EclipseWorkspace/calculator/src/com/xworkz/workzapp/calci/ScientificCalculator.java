package com.xworkz.workzapp.calci;


// sub class or child class or Derived class
public class ScientificCalculator extends Calculator{
	
	
	/*
	 * public void add(int a , int b) { System.out.println(a+b); }
	 */
	public void sin(int sina , int sinb)
	{
		System.out.println("");
	}
	
	public void cos(int cosa , int cosb)
	{
		System.out.println("");
	}
}
