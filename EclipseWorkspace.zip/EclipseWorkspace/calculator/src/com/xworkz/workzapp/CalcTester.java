package com.xworkz.workzapp;

import com.xworkz.workzapp.calci.Calculator;
import com.xworkz.workzapp.calci.ScientificCalculator;

public class CalcTester {
	
	
	public static void main(String[] args) {
		
		ScientificCalculator calculator = new ScientificCalculator();
		calculator.sub(3, 1);
	}

}
