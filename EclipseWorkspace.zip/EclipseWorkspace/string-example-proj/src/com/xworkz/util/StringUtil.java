package com.xworkz.util;

public class StringUtil {

	public static void main(String[] args) {
		// itrAA
		String s1 = new String("My Name is Anthony"); // two objects

		String s2 = "Sakshi"; // 1 object
		String s3 = "Sakshi"; // 0 object

		StringBuffer buffer = new StringBuffer("Raja");
        buffer.append(34.00);
      
        buffer.append("     ");
        System.out.println(buffer);
        StringBuilder builder = new StringBuilder("Raja");
      
        builder.append("Raniiiiiii");
        builder.append("     ");
        System.out.println(builder);
	    System.out.println(builder.delete(4, 14));
		char ch = s1.charAt(3);
		System.out.println(ch);

		// System.out.print(s1 == s3);

	}

}
