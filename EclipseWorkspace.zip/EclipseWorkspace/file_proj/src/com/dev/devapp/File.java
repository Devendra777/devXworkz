package com.dev.devapp;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.*;

public class File {
	
	

	
	
	
	public static void main(String[] args) {
		String sqry="insert into file_table values(?,?)";
		  try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection
		("jdbc:mysql://localhost:3306/jokes?user=root&password=Rohith782912");
			PreparedStatement stmt=  con.prepareStatement(sqry);
			java.io.File  file = new java.io.File("C:\\Users\\AG49183\\Desktop\\Devendra.txt");
			FileReader rd = new FileReader
					(file);
			stmt.setInt(1,34);
			stmt.setCharacterStream(2,rd,(int)file.length());
		
			stmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
;