package com.dev.devapp;

public class Mall {
	
	
	public void windowShopping()
	{
		System.out.println("Window was very good");
	}

}
