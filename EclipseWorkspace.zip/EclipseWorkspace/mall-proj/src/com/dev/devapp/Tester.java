package com.dev.devapp;

public class Tester {
	public static void main(String[] args) {

		Mall mall = new Mall();
		mall.windowShopping();
	}
}
