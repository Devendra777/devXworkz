package com.wolken.wolkenapp.custom;

/*
 * //custom un-checked exception public class PubException extends
 * RuntimeException {
 * 
 * }
 */

public class PubException extends Exception {

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return " Age below 21 are not allowed";
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Age below 21 are not allowed";
	}

}