package com.wolken.wolkenapp;

import com.wolken.wolkenapp.custom.PubException;

public class Bouncer {

	public void check(int age) throws PubException  {
		if (age > 21) {
			System.out.println("please go ahead");
		} else {
			throw new PubException();
		}
	}

}
