package com.wolken.wolkenapp;

import com.wolken.wolkenapp.custom.PubException;

public class PubTester {
	public static void main(String[] args) {
		Bouncer bouncer = new Bouncer();

		try {
			bouncer.check(21);
		} catch (PubException e) {

			e.printStackTrace();
			e.getMessage();
		}
		System.out.println(bouncer.toString());

	}

}
