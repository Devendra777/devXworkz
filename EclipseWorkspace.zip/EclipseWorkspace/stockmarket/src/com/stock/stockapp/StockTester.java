package com.stock.stockapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.stock.stockapp.bean.StockBean;
import com.stock.stockapp.bean.StockMarketBean;

public class StockTester {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("resources/context.xml");

		StockMarketBean bean = context.getBean(StockMarketBean.class);
		System.out.println(bean.getStockMarketId());
		
        StockBean bean2 =     bean.getStocks();
        System.out.println(bean2.getStockId());
        System.out.println(bean2.getName());
		/*
		 * StockBean stockBean = context.getBean(StockBean.class);
		 * System.out.println(stockBean.getStockId());
		 */
	
	}

}
