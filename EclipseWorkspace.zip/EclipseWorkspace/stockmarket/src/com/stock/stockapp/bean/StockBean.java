package com.stock.stockapp.bean;

import java.io.Serializable;

public class StockBean implements Serializable {

	private int stockId;
	private String name;
	private double price;
	private String symbol;

	public StockBean() {
		System.out.println(this.getClass().getSimpleName() + " created");

	}

	public int getStockId() {
		return stockId;
	}

	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

}
