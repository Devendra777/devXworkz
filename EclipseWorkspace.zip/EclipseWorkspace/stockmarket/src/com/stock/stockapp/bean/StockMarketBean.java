package com.stock.stockapp.bean;

import java.io.Serializable;

//
public class StockMarketBean implements Serializable{
	
	private int stockMarketId;
	private String stockMarketName;
	private StockBean stocks;
	
	
	public StockMarketBean() {
		System.out.println( this.getClass().getSimpleName() + " created");
	}
	



	public StockMarketBean(int stockMarketId, String stockMarketName, StockBean stocks) {
		super();
		this.stockMarketId = stockMarketId;
		this.stockMarketName = stockMarketName;
		this.stocks = stocks;
	}




	public int getStockMarketId() {
		return stockMarketId;
	}


	public void setStockMarketId(int stockMarketId) {
		this.stockMarketId = stockMarketId;
	}


	public String getStockMarketName() {
		return stockMarketName;
	}


	public void setStockMarketName(String stockMarketName) {
		this.stockMarketName = stockMarketName;
	}



	public StockBean getStocks() {
		return stocks;
	}


	public void setStocks(StockBean stocks) {
		this.stocks = stocks;
	}




	@Override
	public String toString() {
		return "StockMarketBean [stockMarketId=" + stockMarketId + ", stockMarketName=" + stockMarketName + ", stocks="
				+ stocks + "]";
	}
	
	
	
	

}
