package com.xworkz.workzapp;

import com.xworkz.workzapp.machine.Geaser;

public class MachineUtil {

	public static void main(String[] args) {

		Geaser machine = new Geaser();//
		machine.onAndOff();
	}
}
