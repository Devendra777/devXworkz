package com.xworkz.workzapp.machine;

public class Geaser extends Machine {

	@Override
	public void onAndOff() {
		// TODO Auto-generated method stub
		System.out.println("");
	}

	
	
	

}
