package com.xworkz.workzapp.machine;

public abstract class Machine {
 
	
	public	abstract void onAndOff() ;
	
	public void performTask()
	{
		System.out.println("");
	}

}
