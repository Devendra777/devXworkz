package com.xworkz.workzapp;
import com.xworkz.workzapp.shop.Automobile;
import com.xworkz.workzapp.shop.Bakery;
import com.xworkz.workzapp.shop.Shop;

public class ShopUtil {
	
	
	public static void main(String[] args) {
		Shop automobileShop = new Automobile();
		automobileShop.serve();
		Shop bakeryShop = new Bakery();
		bakeryShop.serve();
		bakeryShop.store();
	}

}
