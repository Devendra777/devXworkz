package com.xworkz.workzapp.shop;

public class Automobile extends Shop{

	@Override
	public void serve() {
		// TODO Auto-generated method stub
		System.out.println("parts of the vehicles");
	}

}
