package com.xworkz.workzapp.shop;

public abstract class Shop {
	
	public abstract void serve() ;

	public void store()
	{
		System.out.println("Storing the items");
	}
}
