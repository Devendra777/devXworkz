package com.xworkz.workzapp.shop;

public abstract class Bakery extends Shop{

	
}
