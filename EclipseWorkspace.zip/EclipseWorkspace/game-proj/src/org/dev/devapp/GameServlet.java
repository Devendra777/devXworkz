package org.dev.devapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/games")
public class GameServlet extends GenericServlet{
	
	
	
	public GameServlet() {
		System.out.println("Servlet Object is created by JEE Container");
	}
	
	


	
	
@Override
public void destroy() {
	System.out.println("Closing all the costly resources");
}



@Override
public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
	System.out.println("Processing the client request");
	String name=	req.getParameter("nm");
	String type =   req.getParameter("tp");
	
	Integer noOfPlayers = Integer.parseInt(req.getParameter("np"));
	
	
	PrintWriter printWriter = resp.getWriter();
	resp.setContentType("text/html");
	printWriter.print("Thank you for choosing "+name+" game");
	// TODO Auto-generated method stub
	
}
	

@Override
public void init(ServletConfig config) throws ServletException {
// TODO Auto-generated method stub
super.init(config);
System.out.println("Initializing the resources of Servlet Object");
}
	
}
