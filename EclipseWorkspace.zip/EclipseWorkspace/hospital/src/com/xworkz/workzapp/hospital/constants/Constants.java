package com.xworkz.workzapp.hospital.constants;

public class Constants {

	
	
	public static final String RAJAJINGAR = "Rajajinagar";
	public static final String VIJAYANAGAR = "Vijayanagar";
	public static final String KRPURAM = "Krpuram";
}
