package com.dev.devapp.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.dev.devapp.dto.GroceryDTO;

public class GroceryDAOImpl implements GroceryDAO {

	@Override
	public void createGrocery(GroceryDTO dto) {
		SessionFactory factory = null;
		Session session = null;
		// TODO Auto-generated method stub
		// 3 COmponents ----- COnfiguration , SessionFactory , Session
		try {
			Configuration configuration = new Configuration();
			configuration.configure();
			configuration.addAnnotatedClass(GroceryDTO.class);
			factory = configuration.buildSessionFactory();
			session = factory.openSession();
			Transaction transaction = session.beginTransaction();
			session.save(dto);
			transaction.commit();

		} catch (HibernateException e) {
			// TODO: handle exception
		} finally {
			if (session != null) {
				session.close();
			}

			if (factory != null) {
				factory.close();
			}

		}
	}

}
