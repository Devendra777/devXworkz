package com.dev.devapp.dao;

import com.dev.devapp.dto.GroceryDTO;

public interface GroceryDAO {
	
        public void createGrocery(GroceryDTO dto);
      

}
