package com.dev.devapp.dto;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class Product {
	
	
	
	private int pro_id;
	private String name;
	
	@ManyToOne  // it is the bi-direction of OneToMany
	@JoinColumn(name="I_id")
	private InVoice inVoice;

}
