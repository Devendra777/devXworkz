package com.dev.devapp.dto;

import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

public class Customer {
	
	
	
	private int customerId;
	private String name;
	
	@OneToOne
	@JoinColumn(name="customer_id")
	private InVoice inVoice;

}
