package com.dev.devapp.dto;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;


@Entity
public class InVoice implements Serializable {

	@Id
	@Column
	private int groceryId;
	private String name;
	private String itemName;
	private int quantity;
	@OneToOne(cascade=CascadeType.ALL  ,fetch=FetchType.EAGER)
	@PrimaryKeyJoinColumn
	private Customer cost;
	
	@OneToMany(cascade=CascadeType.ALL  ,fetch=FetchType.EAGER)
	@JoinColumn(name="pro_id")
	private List<Product> product;

	public GroceryDTO() {
		System.out.println("DTO created");
	}

	public int getGroceryId() {
		return groceryId;
	}

	public void setGroceryId(int groceryId) {
		this.groceryId = groceryId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
