package com.dev.devapp.tester;

import com.dev.devapp.dao.GroceryDAO;
import com.dev.devapp.dao.GroceryDAOImpl;
import com.dev.devapp.dto.GroceryDTO;

public class Tester {
	
	
	public static void main(String[] args) {
		
		
		GroceryDTO dto = new GroceryDTO();
		dto.setGroceryId(3);
		dto.setName("ShopNSave");
		dto.setItemName("TeaPowder");
		dto.setQuantity(35);
		
		GroceryDAO dao = new GroceryDAOImpl() ;
		dao.createGrocery(dto);
		
		
	}

}
