package com.dev.devapp.util;

import com.dev.devapp.dao.PaytmDAO;
import com.dev.devapp.dao.PaytmDAOImpl;
import com.dev.devapp.dto.PaytmDTO;

public class Tester {

	public static void main(String[] args) {
		
		PaytmDTO dto = new PaytmDTO();
		dto.setPaytmId(90);
		dto.setAccountHolder("raja");

		
		
		
		PaytmDAO paytmDAO = new PaytmDAOImpl();
		paytmDAO.savePaytmDetails(dto);
		/*
		 * paytmDAO.getPaytmDetails(1); paytmDAO.updatePinNumberById(7890, 5);
		 */
	}
}
