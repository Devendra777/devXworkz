package com.dev.devapp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="paytm_details")
public class PaytmDTO implements Serializable{
	
	@Id
	@Column(name="paytm_id")
	private int paytmId;
	@Column(name="paytm_account_holder")
	private String accountHolder;
	@Column(name="paytm_pin_number")
	private int pinNumber;
	@Column(name="paytm_city")
	private String city;
	
	public PaytmDTO() {
		System.out.println(this.getClass().getSimpleName()+"created ");
	}

	public int getPaytmId() {
		return paytmId;
	}

	public void setPaytmId(int paytmId) {
		this.paytmId = paytmId;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "PaytmDTO [paytmId=" + paytmId + ", accountHolder=" + accountHolder + ", pinNumber=" + pinNumber
				+ ", city=" + city + "]";
	}
	
	

	
}
