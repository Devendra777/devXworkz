package com.dev.devapp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.dev.devapp.dto.PaytmDTO;

public class PaytmDAOImpl implements PaytmDAO {

	@Override
	public void savePaytmDetails(PaytmDTO paytmDTO) {
		Configuration configuration = new Configuration();
		configuration.configure();
		configuration.addAnnotatedClass(PaytmDTO.class);
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(paytmDTO);
		transaction.commit();
		session.close();
		factory.close();
	}

	@Override
	public void getPaytmDetails(int id) {
		Configuration configuration = new Configuration();
		configuration.configure();
		configuration.addAnnotatedClass(PaytmDTO.class);
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		//Transaction transaction = session.beginTransaction();
	PaytmDTO dto= 	session.get(PaytmDTO.class,id);
	System.out.println(dto.getAccountHolder());
	//	transaction.commit();
		session.close();
		factory.close();
	}

	@Override
	public void updatePinNumberById(int pinNumber, int id) {
		Configuration configuration = new Configuration();
		configuration.configure();
		configuration.addAnnotatedClass(PaytmDTO.class);
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		PaytmDTO dtoFromDB= 	session.get(PaytmDTO.class,id);
		Transaction transaction = session.beginTransaction();
		dtoFromDB.setPinNumber(pinNumber);
		session.update(dtoFromDB);
		transaction.commit();
		session.close();
		factory.close();
	}

}
