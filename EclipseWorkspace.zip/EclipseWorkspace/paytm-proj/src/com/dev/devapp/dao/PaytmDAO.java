package com.dev.devapp.dao;

import com.dev.devapp.dto.PaytmDTO;

public interface PaytmDAO {

	
	
	public void savePaytmDetails(PaytmDTO paytmDTO);
	public void getPaytmDetails(int  id);
	public void updatePinNumberById(int pinNumber,int id);
	
}
