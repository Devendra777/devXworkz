package com.xworkz.workzapp.util;

import com.xworkz.workzapp.god.God;
import com.xworkz.workzapp.god.Shiva;

public class GodUtil {

	public static void main(String[] args) {
		//upcasting
		God god = new Shiva();
		//downcasting 
	     Shiva shiva=   (Shiva) god;
		god.bless();
       System.out.println(god.address);
	}
}
