package com.xworkz.workzapp.god;

public class Shiva extends God{
	
	public  String address="Murudeshwara";
	
	public void bless()
	{
		System.out.println("Unconditional Blessings");
	}

}
