package com.xworkz.workzapp.god;

public class God {
	 
	public  String address="Kailasa";
	
	
	public void bless()
	{
		System.out.println("Give blessings");
	}
	
	

}
