package org.dev.devapp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/firstServlet")
public class FirstServlet extends HttpServlet{
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		
		/*
		 * req.setAttribute("name", name); req.setAttribute("place",place);
		 */
		
		/*
		 * Person person = new Person(); person.setId(1);
		 * person.setAddress("vijayanagar"); person.setName("Dev");
		 * 
		 * Person person1 = new Person(); person1.setId(2);
		 * person1.setAddress("vijayanagar"); person1.setName("Dev");
		 * 
		 * Person person3 = new Person(); person3.setId(3);
		 * person3.setAddress("vijayanagar"); person3.setName("Dev");
		 */
		
		
		List<Person> persons =  Arrays.asList(new Person(1, "Dev","Vijayanagr"), new Person(2, "Dev1","Vijayanagr2"),new Person(3, "Dev3","Vijayanagr3"));
		
		String name="Devendra";
		
		System.out.println(persons);
		
		req.setAttribute("persons", persons);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("data1.jsp");
		dispatcher.forward(req, resp);
		
		
	}
	
	

}
