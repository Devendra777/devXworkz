package com.dev.devapp.register;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

public class RegisterServlet extends GenericServlet {
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
                ServletConfig config  =    getServletConfig();
          config.getInitParameter("key");
		String name = req.getParameter("nm");
		String mobileNo = req.getParameter("mobileNo");
		String age = req.getParameter("age");
		String email = req.getParameter("email");

		PrintWriter printWriter = res.getWriter();

		res.setContentType("text/html");
		printWriter.print("Thank you " + name);

	}

}
