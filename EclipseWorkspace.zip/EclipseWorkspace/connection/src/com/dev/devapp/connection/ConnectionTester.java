package com.dev.devapp.connection;

import java.sql.Connection;

public class ConnectionTester {
	public static void main(String[] args) {

		Connection connection = Connect.getConnect();
		System.out.println(connection);
		Connect.closeConnection();
		Connection connection1 = Connect.getConnect();
		System.out.println(connection1);
		Connect.closeConnection();
		Connection connection2 = Connect.getConnect();
		System.out.println(connection2);

	}

}
