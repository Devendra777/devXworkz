package com.xworkz.xworkzapp;


import com.xworkz.xworkzapp.dto.CityDTO;

public class CityTester {
	public static void main(String[] args) {
		System.out.println("Main method started");

		CityDTO cityDTO = new CityDTO();
		cityDTO.setCityName("Bengaluru");
		System.out.println(cityDTO.getCityName());
		System.out.println("Main method ended");
	}

}
