package com.xworkz.xworkzapp.dto;

public class CityDTO {

	private String cityName;

	public CityDTO() {
		System.out.println("CityDTO object is created");
	}

	public String getCityName() {
		return cityName;
	}
	
	public void setCityName(String name)
	{
		
		cityName = name;
	}

}
