package com.xworkz.workzapp.util;

import com.xworkz.workzapp.dto.CarDTO;
import com.xworkz.workzapp.showroom.Showroom;

public class ShowRoomUtil {

	public static void main(String[] args) {
		
	System.out.println("Main method started");
		Showroom showroom = new Showroom();
		CarDTO carDTO = new CarDTO();
		carDTO.setName("XL6");
		carDTO.setModel("higherEnd");
		carDTO.setPrice(15000000.00);
		CarDTO carDTO1 = new CarDTO();
		carDTO1.setName("seltos");
		carDTO1.setModel("MidEnd");
		carDTO1.setPrice(17000000.00);
		CarDTO carDTO2 = new CarDTO();
		carDTO2.setName("Balero");
		carDTO2.setModel("higherEnd");
		carDTO2.setPrice(11000000.00);

		showroom.addCars(carDTO);
		showroom.addCars(carDTO1);
		showroom.addCars(carDTO2);

		showroom.displayCars();
		showroom.deleteCarByName("seltos");
		//showroom.UpdateCarPriceByName("Balero", 800000.00);
		showroom.displayCars();
		System.out.println("main method ended ");

	}

}
