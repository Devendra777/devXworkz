package com.xworkz.workzapp.showroom;

import com.xworkz.workzapp.dto.CarDTO;

public class Showroom {

	public CarDTO carDTO[] = new CarDTO[3];
	public int currentIndex;

	public Showroom() {
		System.out.println("showroom object  created");
	}

	public void addCars(CarDTO carDTO) {

		if (carDTO != null) {
			System.out.println(this.currentIndex);
			this.carDTO[currentIndex] = carDTO;
			this.currentIndex++;

		} else if (carDTO == null) {

			System.out.println("car dto is not added");

		}

	}

	public void displayCars() {
		System.out.println("Showing cars details");
		for (int i = 0; i < carDTO.length; i++) {
			if (carDTO[i] != null) {
				System.out.println(carDTO[i].getName() + " "
			                            + carDTO[i].getPrice() + " "+
						carDTO[i].getModel());
			}
		}
		System.out.println(carDTO.length);
		System.out.println("end of Showing cars details");

	}
	
	
	public  void      deleteCarByName(String name)
	{
	      System.out.println("Starting with deleting the car by name");
	     for (int i = 0; i < carDTO.length; i++) {
	    	 if (carDTO[i] != null) {
	    		 if(carDTO[i].getName().equals(name))
	    		 {
					carDTO[i] = null;
	    		 }
	    	 }
		}
	}
	
	public void UpdateCarPriceByName(String name, double price) {
		System.out.println("Starting with deleting the car by name");
		for (int i = 0; i < carDTO.length; i++) {
			if (carDTO[i] != null) {
				if (carDTO[i].getName() ==  name) {
					carDTO[i].setPrice(price);
					carDTO[i].setModel("lowerEnd");
					System.out.println("price updated");
				}

			}
		}
	}
}
