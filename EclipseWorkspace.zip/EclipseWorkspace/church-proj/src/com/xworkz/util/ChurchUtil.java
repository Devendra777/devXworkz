package com.xworkz.util;

import com.xworkz.church.Church;

public class ChurchUtil {

	public static void main(String[] args) {

		Church church = new Church("Kerala", "St Mary's Church", 45);

		/*
		 * church.setName("St.Joseph's Church"); church.setAddress("Goa");
		 * church.setNoOfFathersAndSisters(1);
		 */

		System.out.println(church.getAddress() + " " + church.getName() + " " + church.getNoOfFathersAndSisters());
	}

}
