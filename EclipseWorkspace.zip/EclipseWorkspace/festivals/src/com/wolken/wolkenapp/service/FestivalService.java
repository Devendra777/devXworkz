package com.wolken.wolkenapp.service;

import java.sql.SQLException;
import java.util.List;

import com.wolken.wolkenapp.dto.FestvalsDTO;

public interface FestivalService {

	public void validateAndSave(FestvalsDTO dto) throws SQLException ;

	public List<FestvalsDTO> getAllFestivals() throws SQLException ;
}
