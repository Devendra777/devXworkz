package com.wolken.wolkenapp.service;

import java.sql.SQLException;
import java.util.List;

import com.wolken.wolkenapp.dao.FestivalDAO;
import com.wolken.wolkenapp.dao.FestivalDAOImpl;
import com.wolken.wolkenapp.dto.FestvalsDTO;

public class FestivalServiceImpl implements FestivalService {

	public FestivalDAO festivalDAO = new FestivalDAOImpl();

	@Override
	public void validateAndSave(FestvalsDTO dto) throws SQLException {
		// TODO Auto-generated method stub
		if (dto != null) {
			festivalDAO.save(dto);
		}

	}

	@Override
	public List<FestvalsDTO> getAllFestivals() throws SQLException {
 
		return 	festivalDAO.getFestivals();
	}

}
