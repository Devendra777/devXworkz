package com.wolken.wolkenapp.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.wolken.wolkenapp.dto.FestvalsDTO;

public interface FestivalDAO {

	public void save(FestvalsDTO dto) throws SQLException ;

	public List<FestvalsDTO> getFestivals() throws SQLException ;

}
