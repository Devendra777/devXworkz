package com.wolken.wolkenapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dev.devapp.connection.Connect;
import com.wolken.wolkenapp.dto.FestvalsDTO;

public class FestivalDAOImpl implements FestivalDAO {

	public Connection connection = Connect.getConnect();

	@Override
	public void save(FestvalsDTO dto) throws SQLException {
		// TODO Auto-generated method stub
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("insert into jokes.festival_table  values (?, ? , ?,  ?)")) {
			preparedStatement.setInt(1, dto.getFestivalId());
			preparedStatement.setString(2, dto.getFestivalName());
			preparedStatement.setString(3, dto.getMonth());
			preparedStatement.setInt(4, dto.getNoOfDays());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		}
	}

	@Override
	public List<FestvalsDTO> getFestivals() throws SQLException {
		List<FestvalsDTO> dtos = new ArrayList<FestvalsDTO>();
		try (PreparedStatement preparedStatement = connection.prepareStatement("select * from jokes.festival_table")) {
			try (	ResultSet  resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					FestvalsDTO dto = new FestvalsDTO();
					dto.setFestivalId(resultSet.getInt(1));
					dto.setFestivalName(resultSet.getString(2));
					dto.setMonth(resultSet.getString(3));
					dto.setNoOfDays(resultSet.getInt(4));
					dtos.add(dto);

					//resultSet.close();
				}
				preparedStatement.close();
			}
			connection.close();
			return dtos;
		}
	}
}