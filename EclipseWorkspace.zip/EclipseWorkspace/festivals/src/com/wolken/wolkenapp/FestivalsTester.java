package com.wolken.wolkenapp;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.dev.devapp.connection.Connect;
import com.wolken.wolkenapp.dto.FestvalsDTO;
import com.wolken.wolkenapp.service.FestivalService;
import com.wolken.wolkenapp.service.FestivalServiceImpl;

public class FestivalsTester {

	public static void main(String[] args) throws SQLException {

		FestivalService festivalService = new FestivalServiceImpl();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		for (int i = 0; i < size; i++) {
			FestvalsDTO dto = new FestvalsDTO();

			System.out.println("Enter the id");
			int id = sc.nextInt();

			System.out.println("Enter the name");
			String name = sc.next();
			System.out.println("Enter the month");
			String month = sc.next();
			System.out.println("Enter the days");
			int days = sc.nextInt();
			dto.setFestivalId(id);
			dto.setFestivalName(name);
			dto.setMonth(month);
			dto.setNoOfDays(days);
			festivalService.validateAndSave(dto);
		}

		List<FestvalsDTO> dtos = festivalService.getAllFestivals();

		dtos.forEach(System.out::println);

	}

}
