package com.wolken.wolkenapp.dto;

public class FestvalsDTO {

	private int festivalId;
	private String festivalName;
	private int noOfDays;
	private String month;

	public int getFestivalId() {
		return festivalId;
	}

	public void setFestivalId(int festivalId) {
		this.festivalId = festivalId;
	}

	public String getFestivalName() {
		return festivalName;
	}

	public void setFestivalName(String festivalName) {
		this.festivalName = festivalName;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	@Override
	public String toString() {
		return "FestvalsDTO [festivalId=" + festivalId + ", festivalName=" + festivalName + ", noOfDays=" + noOfDays
				+ ", month=" + month + "]";
	}

}
