package com.xworkz.xworkzapp.hotel;

public class Taj extends Hotel{
	
	public String address ="City";
	
	
	@Override
	public void serveFood() {
		System.out.println("serving food with  Veg and Non-veg");
	}
	

}
