package com.xworkz.xworkzapp.hotel;

public class Hotel {

	public String address ="HighWays";
	public String type;

	public void serveFood() {

		System.out.println("serving food with Veg");

	}


}
