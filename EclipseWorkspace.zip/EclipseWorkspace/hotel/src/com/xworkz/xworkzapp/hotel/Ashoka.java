package com.xworkz.xworkzapp.hotel;

public class Ashoka extends Hotel{
	
	
	@Override
	public void serveFood()
	{
		
		System.out.println("Serving food in Train");
		
	}

}
