package com.xworkz.xworkzapp;

import com.xworkz.xworkzapp.hotel.Ashoka;
import com.xworkz.xworkzapp.hotel.Hotel;
import com.xworkz.xworkzapp.hotel.Taj;

public class HotelUtil {
	
	
	public static void main(String[] args) {
		
		// upcasting
		Hotel hotel = new Ashoka();
		hotel.serveFood();
		
		
	}

}
