package com.dev.devapp;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Joke {

	public static void procedure(int i, String name) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		try (Connection con = DriverManager
	.getConnection("jdbc:mysql://localhost:3306/jokes?user=root&password=Rohith782912");) {
			try (CallableStatement cstmt = con.prepareCall("call joke(?,?)");) {
				cstmt.setInt(1, i);
				cstmt.setString(2, name);
				cstmt.execute();
				cstmt.close();
				con.close();

			}
		}

	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Id");
		int i = sc.nextInt();
		System.out.println("Enter the Name");
		String name = sc.next();

		try {
			procedure(i, name);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
	}

}
