package com.xworkz.songs;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/songs", loadOnStartup = 78, initParams = {
		@WebInitParam(name = "name", value = "Songs"),
})
public class SongsServlet extends HttpServlet {

	public SongsServlet() {
		System.out.println("SongsServlet obhect is created");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		
	
		String songName = req.getParameter("songName");
		String featuring = req.getParameter("featuring");
		String singer = req.getParameter("singer");
		String duration = req.getParameter("duration");
		String lang = req.getParameter("lang");
		String lyricist = req.getParameter("lyricist");

		PrintWriter printWriter = resp.getWriter();
		printWriter.write("thank you for selecting " + songName + " " );
	
	}

}
