package com.xworkz.xworkzapp.waterpark;

import com.xworkz.xworkzapp.park.ManagerDTO;
import com.xworkz.xworkzapp.park.WorkersDTO;

public class Waterpark {

	public ManagerDTO manager;
	public WorkersDTO[] workersDTOs;
	public int index;

	public void addManager(String name, long contactNo) {
		System.out.println("Adding the manager by name and contactNo");
		if (name != null && contactNo > 0)
			this.manager = new ManagerDTO(name, contactNo);
		System.out.println("Added  the manager by name and contactNo");
	}

	public void addManager(ManagerDTO dto) {
		System.out.println("Adding manager directly");
		if (dto != null)
			this.manager = dto;
		else {
			System.out.println("Manager not added : null");
		}
	}

	public void addWorkers(WorkersDTO workersDTO) {
		System.out.println("");
		if (workersDTO != null) {
			workersDTOs[index++] = workersDTO;
		}
	}

	public void removeManager() {
		System.out.println("Removing Manager bcoz he is not good with managing the rides ");
		this.manager = null;
		System.out.println("Removed the manager");
	}

	
	public void displayManager() {
		System.out.println("Displaying all the managers");
		System.out.println(this.manager.getName());
		System.out.println(this.manager.getContactNo());
		System.out.println("displayed Manager");
	}

	public void showWorkers() {
		for (WorkersDTO workersDTO : workersDTOs) {
			if (workersDTO != null)
				System.out.println(workersDTO.getName() + " " + workersDTO.getWorkerId());
		}
	}

}
