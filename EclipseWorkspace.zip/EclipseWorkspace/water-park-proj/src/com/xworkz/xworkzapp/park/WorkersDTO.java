package com.xworkz.xworkzapp.park;

public class WorkersDTO {

	private String name;
	private int workerId;

	public void setName(String name) {
		this.name = name;
	}

	public void setWorkerId(int workerId) {
		this.workerId = workerId;
	}

	public String getName() {
		return name;
	}

	public int getWorkerId() {
		return workerId;
	}

}
