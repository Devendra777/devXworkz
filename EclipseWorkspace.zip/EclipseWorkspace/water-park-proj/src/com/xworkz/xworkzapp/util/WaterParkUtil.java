package com.xworkz.xworkzapp.util;

import com.xworkz.xworkzapp.park.ManagerDTO;
import com.xworkz.xworkzapp.park.WorkersDTO;
import com.xworkz.xworkzapp.waterpark.Waterpark;

public class WaterParkUtil {

	public static void main(String[] args) {

		Waterpark waterpark = new Waterpark();

		ManagerDTO managerDTO = new ManagerDTO("GUBE", 345345345L);
		System.out.println(managerDTO.getContactNo() + " " + managerDTO.getName());
		waterpark.addManager(managerDTO);
		waterpark.displayManager();
		WorkersDTO dto = new WorkersDTO();
		dto.setName("Devendra");
		dto.setWorkerId(345);
		WorkersDTO dto1 = new WorkersDTO();
		dto1.setName("Rahul");
		dto1.setWorkerId(367);

		waterpark.workersDTOs = new WorkersDTO[2];
		waterpark.addWorkers(dto);
		waterpark.addWorkers(dto1);

		
		waterpark.showWorkers();

		// waterpark.removeManager();
		// waterpark.displayManager();

	}

}
