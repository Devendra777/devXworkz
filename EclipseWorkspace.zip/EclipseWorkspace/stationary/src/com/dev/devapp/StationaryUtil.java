package com.dev.devapp;

import java.io.FileNotFoundException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;

import com.dev.devapp.bean.StationaryBean;

public class StationaryUtil {
	
	
	public static void main(String[] args) throws FileNotFoundException {
		/*InputStream inputStream = new FileInputStream("resources/context.xml");
		
		BeanFactory  applicationContext  = new XmlBeanFactory((Resource) inputStream);
		*/
		ApplicationContext  applicationContext = new ClassPathXmlApplicationContext("resources/context.xml");
		
		StationaryBean bean = applicationContext.getBean(StationaryBean.class);
		System.out.println(bean);
		System.out.println(bean.getAddress() + "   "+ bean.getOwnerName());
		
		StationaryBean bean1 = applicationContext.getBean(StationaryBean.class);
		System.out.println(bean1);
	}

}
