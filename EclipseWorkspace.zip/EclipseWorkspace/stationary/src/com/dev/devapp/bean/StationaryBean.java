package com.dev.devapp.bean;

import java.io.Serializable;

public class StationaryBean implements Serializable {

	public StationaryBean() {
		// TODO Auto-generated constructor stub
	}
	private String stationaryId;
	private String stationaryName;
	private String address;
	private String ownerName;

	
	public void provideItems() {
		System.out.println("invoked provideItems");
	}
	
	
	public String getStationaryId() {
		return stationaryId;
	}

	public void setStationaryiId(String stationaryiId) {
		this.stationaryId = stationaryiId;
	}

	public String getStationaryName() {
		return stationaryName;
	}

	public void setStationaryName(String stationaryName) {
		this.stationaryName = stationaryName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

}
