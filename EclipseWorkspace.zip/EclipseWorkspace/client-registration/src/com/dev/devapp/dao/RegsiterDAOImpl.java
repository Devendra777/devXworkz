package com.dev.devapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dev.devapp.dto.RegisterDTO;
import com.dev.devapp.service.RegisterService;

public class RegsiterDAOImpl implements RegsiterDAO{

	@Override
	public void save(RegisterDTO dto) {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/jokes?user=root&password=Rohith782912");
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into user_details values(?,?,?,?)");
			preparedStatement.setInt(1, 8);
			preparedStatement.setString(2, dto.getName());
			preparedStatement.setString(3, dto.getAge());
			preparedStatement.setString(4, dto.getMobileNo());
			preparedStatement.executeUpdate();
			preparedStatement.close();
			connection.close();
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


}
