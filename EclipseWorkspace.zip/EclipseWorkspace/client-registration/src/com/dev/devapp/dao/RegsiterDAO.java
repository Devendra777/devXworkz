package com.dev.devapp.dao;

import com.dev.devapp.dto.RegisterDTO;

public interface RegsiterDAO {
	
	public void save(RegisterDTO dto);

}
