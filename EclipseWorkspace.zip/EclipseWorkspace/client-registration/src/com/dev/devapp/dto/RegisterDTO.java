package com.dev.devapp.dto;

import java.io.Serializable;

public class RegisterDTO implements Serializable {

	private int registerId;
	private String name;
	private String mobileNo;
	private String age;
	private String email;

	public RegisterDTO() {
		System.out.println(this.getClass().getSimpleName()+ "object is created");
	}
	public int getRegisterId() {
		return registerId;
	}

	public void setRegisterId(int registerId) {
		this.registerId = registerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "RegisterDTO [registerId=" + registerId + ", name=" + name + ", mobileNo=" + mobileNo + ", age=" + age
				+ ", email=" + email + "]";
	}

}
