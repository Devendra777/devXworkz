package com.dev.devapp;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.dev.devapp.dto.RegisterDTO;
import com.dev.devapp.service.RegisterService;
import com.dev.devapp.service.RegsiterServiceImpl;
public class RegisterServlet extends GenericServlet {
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Initialize the resources of RegsiterServlet");
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		System.out.println("Service method is invoked");
		String name = req.getParameter("nm");
		String mobileNo = req.getParameter("mobileNo");
		String age = req.getParameter("age");
		String email = req.getParameter("email");

		PrintWriter printWriter = res.getWriter();

		
		res.setContentType("text/html");
		printWriter.print("Thank you " + name);
		
		RegisterDTO dto = new RegisterDTO();
		dto.setName(name);
		dto.setMobileNo(mobileNo);
		dto.setAge(age);
		dto.setEmail(email);

		RegisterService registerService = new RegsiterServiceImpl() ;
		registerService.validateAndSave(dto);
	}
	
	
	@Override
	public void destroy() {
		System.out.println("close all the costly resources");
	}
}
