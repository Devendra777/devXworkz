package com.dev.devapp.service;

import com.dev.devapp.dao.RegsiterDAO;
import com.dev.devapp.dao.RegsiterDAOImpl;
import com.dev.devapp.dto.RegisterDTO;

public class RegsiterServiceImpl  implements RegisterService{
	
	  private RegsiterDAO dao ; 

	  public RegsiterServiceImpl() {
		  dao  = new RegsiterDAOImpl();
	}
	  
	@Override
	public void validateAndSave(RegisterDTO dto) {
		
		if(dto != null)
		{
			if(dto.getEmail() != null)
			{
				dao.save(dto);
			}
		
		}
		
	}
	
	
	

}
