package com.dev.devapp.service;

import com.dev.devapp.dto.RegisterDTO;

public interface RegisterService {
	public void validateAndSave(RegisterDTO dto) ; 

}
