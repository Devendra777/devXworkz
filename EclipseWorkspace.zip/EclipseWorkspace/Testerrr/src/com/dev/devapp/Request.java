package com.dev.devapp;

public class Request {
	
	private String lobCtrgyNm;
public String getLobCtrgyNm() {
	return lobCtrgyNm;
}

public void setLobCtrgyNm(String lobCtrgyNm) {
	this.lobCtrgyNm = lobCtrgyNm;
}

@Override
public String toString() {
	return "Request [lobCtrgyNm=" + lobCtrgyNm + "]";
}

}
