package com.dev.devapp;

public class Test {
	
	public static void main(String[] args) {
		
	         char ch[]= {};
	         System.out.println(ch['j']);
	         System.out.println(ch['j']);
	         System.out.println(ch['$']);
	         System.out.println(ch['%']);
	}

}
