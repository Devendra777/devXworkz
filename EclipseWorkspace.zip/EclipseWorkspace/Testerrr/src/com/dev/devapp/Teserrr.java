package com.dev.devapp;

import java.util.ArrayList;
import java.util.List;

public class Teserrr {
	
	
	
	public static void main(String[] args) {
		int x=10;
		switch (key) {
		case value:
			System.out.println("ff");
			break;

		default:
			break;
		}

}
