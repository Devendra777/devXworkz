package com.wolken.wolkenapp;

import com.wolken.wolkenapp.game.GamesDTO;

public class GamesUtil {

	public static void main(String[] args) {
		GamesDTO games = new GamesDTO();
		games.setName("RoadRash");
		games.setNoOfPlayers(1);
		games.setType("offline");
		games.setRatings(5.0);
		System.out.println(
      games.getName()+ "  " + games.getNoOfPlayers() + "  " + games.getType() + " " + games.getRatings());

	}
}
