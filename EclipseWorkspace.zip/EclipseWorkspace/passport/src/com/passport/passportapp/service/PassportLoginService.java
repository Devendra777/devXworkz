package com.passport.passportapp.service;

import com.passport.passportapp.dto.LoginDTO;
import com.passport.passportapp.dto.PassportDTO;

public interface PassportLoginService {

PassportDTO validatePassport(LoginDTO dto);
	
	
	

}
