package com.passport.passportapp.service;

import com.passport.passportapp.dto.PassportDTO;

public interface PassportRegistrationService {

	public boolean validateAndPersistPassportDetails(PassportDTO passportDTO);
}
