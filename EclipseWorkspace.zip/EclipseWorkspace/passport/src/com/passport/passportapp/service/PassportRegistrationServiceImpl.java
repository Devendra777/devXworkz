package com.passport.passportapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.passport.passportapp.dao.PassportRegistrationDAO;
import com.passport.passportapp.dto.PassportDTO;

@Service
public class PassportRegistrationServiceImpl implements PassportRegistrationService{
	
	@Autowired
	private PassportRegistrationDAO dao;
	
	public PassportRegistrationServiceImpl() {
		System.out.println(this.getClass().getSimpleName() + " created");
	}

	@Override
	public boolean validateAndPersistPassportDetails(PassportDTO passportDTO) {
		
		return dao.persistPassportDetails(passportDTO);
	}

}
