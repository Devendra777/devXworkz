package com.passport.passportapp.service;

import com.passport.passportapp.dao.PassportLoginDAO;
import com.passport.passportapp.dto.LoginDTO;
import com.passport.passportapp.dto.PassportDTO;

public class PassportLoginServiceImpl implements PassportLoginService{
	
	
	private PassportLoginDAO dao;
	
	public PassportLoginServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public PassportDTO validatePassport(LoginDTO dto) {
		
		return dao.getPassportByLoginIdAndPassword(dto);
	}
	
	

}
