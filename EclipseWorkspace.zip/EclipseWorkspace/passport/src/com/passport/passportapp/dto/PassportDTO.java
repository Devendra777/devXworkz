package com.passport.passportapp.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "passport_table")
@NamedQueries(
		@NamedQuery(name= "getLoginIdAndPassport",query = "select dto from PassportDTO dto where dto.loginId=: lId and dto.password =: ps ")
		)
public class PassportDTO implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "passport_id")
	private int passportId;
	@Column(name = "passport_office")

	private String office;
	@Column(name = "passport_location")
	private String selectLocation;
	@Column(name = "given_name")
	private String givenName;
	@Column(name = "sur_name")
	private String surName;
	@Column(name = "DOB")
	private String dateOfBirth;
	@Column(name = "email_Id")
	private String emailId;
	@Column(name = "login_id")
	private String loginId;
	@Column(name = "password")
	private String password;
	@Column(name = "confirm_password")
	private String confirmPassword;

	public PassportDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getPassportId() {
		return passportId;
	}

	public void setPassportId(int passportId) {
		this.passportId = passportId;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getSelectLocation() {
		return selectLocation;
	}

	public void setSelectLocation(String selectLocation) {
		this.selectLocation = selectLocation;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

}
