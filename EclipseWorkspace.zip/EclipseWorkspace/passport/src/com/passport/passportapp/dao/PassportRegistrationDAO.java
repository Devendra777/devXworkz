package com.passport.passportapp.dao;

import com.passport.passportapp.dto.PassportDTO;

public interface PassportRegistrationDAO {

	boolean persistPassportDetails(PassportDTO passportDTO);

}
