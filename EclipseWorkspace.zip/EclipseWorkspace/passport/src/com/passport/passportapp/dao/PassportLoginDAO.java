package com.passport.passportapp.dao;

import com.passport.passportapp.dto.LoginDTO;
import com.passport.passportapp.dto.PassportDTO;

public interface PassportLoginDAO {

	PassportDTO getPassportByLoginIdAndPassword(LoginDTO dto);
	

}
