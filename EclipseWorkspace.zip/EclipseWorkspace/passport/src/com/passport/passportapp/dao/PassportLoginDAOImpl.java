package com.passport.passportapp.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.passport.passportapp.dto.LoginDTO;
import com.passport.passportapp.dto.PassportDTO;

public class PassportLoginDAOImpl implements PassportLoginDAO {

	@Autowired
	private SessionFactory factory;

	@Override
	public PassportDTO getPassportByLoginIdAndPassword(LoginDTO dto) {

		Session session = factory.openSession();
		session.beginTransaction();
		if (dto != null) {
			Query query = session.getNamedQuery("");
			query.setParameter("lId", dto.getLoginId());
			query.setParameter("ps", dto.getPassword());
			PassportDTO passportDTO = (PassportDTO) query.uniqueResult();

			return passportDTO;

		}
		return null;

	}

}
