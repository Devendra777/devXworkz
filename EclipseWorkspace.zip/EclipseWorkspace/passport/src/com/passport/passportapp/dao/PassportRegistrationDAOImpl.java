package com.passport.passportapp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.passport.passportapp.dto.PassportDTO;

@Repository
public class PassportRegistrationDAOImpl implements PassportRegistrationDAO{
	
	@Autowired
	private SessionFactory factory;

	@Override
	public boolean persistPassportDetails(PassportDTO passportDTO) {
	boolean dateSaved = false;
	
		Session session = factory.openSession();
		session.beginTransaction();
		if(passportDTO != null ) {
		session.save(passportDTO);
		dateSaved = true;
		}
		session.getTransaction().commit();
		
		return dateSaved;
	}

}
