package com.passport.passportapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.passport.passportapp.dto.LoginDTO;
import com.passport.passportapp.dto.PassportDTO;
import com.passport.passportapp.service.PassportLoginService;


@Controller
@RequestMapping("/")
public class PassportLoginController {

	@Autowired
	private PassportLoginService service;

	public PassportLoginController() {
		// TODO Auto-generated constructor stub
	}

	@RequestMapping(value = "/login.all")
	public ModelAndView getLoginDetails(@ModelAttribute LoginDTO dto) {
		PassportDTO passportDTO = null;
		if (dto != null && !dto.getLoginId().isEmpty() && !dto.getPassword().isEmpty()) {
			passportDTO = service.validatePassport(dto);

			if ((passportDTO.getLoginId() != null && passportDTO.getLoginId().equals(dto.getLoginId()))
					|| passportDTO.getPassword() != null && passportDTO.getPassword().equals(dto.getPassword())) {
				return new ModelAndView("PassportLogin", "loginMsg", "Thank you " + dto.getLoginId() + "for Login");
			} else {
				return new ModelAndView("PassportLogin", "passportMsg", "Invalid LoginId or Passowrd");
			}

		}
		return null;

	}
}
