package com.passport.passportapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.passport.passportapp.dto.PassportDTO;
import com.passport.passportapp.service.PassportRegistrationService;

@Controller
@RequestMapping("/")
public class PassportRegistrationController {

	@Autowired
	private PassportRegistrationService service;

	public PassportRegistrationController() {
		System.out.println(this.getClass().getSimpleName() + " created");
	}

	@RequestMapping(value = "/registration.all", method = RequestMethod.POST)
	public ModelAndView createPassportDetails(@ModelAttribute PassportDTO dto) {

		if (dto != null && !dto.getLoginId().isEmpty() && !dto.getEmailId().isEmpty()) {
			service.validateAndPersistPassportDetails(dto);
			return new ModelAndView("PassportRegistration", "passportMsg",
					"Thank you " + dto.getGivenName() + "for Registering");
		} else {
			return new ModelAndView("PassportRegistration", "passportMsg", "Please Enter the Email Id");
		}

	}

	


	
	
	
}
