package com.dev.devapp;

public class Util{
	
	
	public Util() {
		// TODO Auto-generated constructor stub
		System.out.println(this.getClass().getCanonicalName() + " OBject is created");
	}
	
	public static void main(String[] args) {
		String name = "KRS";
		// String literals
		String nm1 = "KRS";
		// one instance is crea		String name = "KRS"; //one  instance is created
		System.out.println(name.equals(nm1)); // false
		System.out.println(name == nm1); //false
		String nm = new String("KRS");
		System.out.println(name.equals(nm)); // true
		System.out.println(name == nm); // false
		
		String baba = new String("KRS");
		System.out.println(nm == baba);
		
		StringBuilder buffer= new StringBuilder("Keerthi Suresh");
		System.out.println(buffer);
		 buffer.append(" M");
		 System.out.println(buffer);
		
	}

	
	

}
