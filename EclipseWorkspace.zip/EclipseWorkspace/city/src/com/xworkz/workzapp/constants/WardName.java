package com.xworkz.workzapp.constants;

public enum WardName {

	
	
	RAJAJINAGAR , VIJAYANAGAR , KRPURAM ;
}
