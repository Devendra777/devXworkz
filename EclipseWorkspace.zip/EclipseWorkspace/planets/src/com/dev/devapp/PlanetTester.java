package com.dev.devapp;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dev.devapp.bean.PlanetBean;

public class PlanetTester {
	
	
	public static void main(String[] args) {
		
		
		//Spring Container
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("context.xml");
    	PlanetBean bean = 	 applicationContext.getBean(PlanetBean.class);
    	bean.getLife();
	    System.out.println(bean);
	    Integer integer = (Integer)    applicationContext.getBean("integer");
	    System.out.println(integer.intValue());
	}

}
