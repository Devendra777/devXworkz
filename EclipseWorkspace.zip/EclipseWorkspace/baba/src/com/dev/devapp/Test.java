package com.dev.devapp;

public class Test {
	
	
	final static int i=10;
	
	public static void main(String[] args) {
		
		
		String s1= new String("Devendra");
		i=34;
		System.out.println(i);
		
		String s2 =  new String("h"); 
		System.out.println(s2);
		
	}

}
