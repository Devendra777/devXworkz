package com.wolken.wolkenapp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class ExceptionTester {

	public static void main(String[] args) throws ClassNotFoundException {
		System.out.println("main started");
		method1();

	}

	public static void method1() throws ClassNotFoundException {
		System.out.println("inside method1");
		method2();
	}

	public static void method2() throws ClassNotFoundException {
		System.out.println("inside method2");
		method3();
	}

	public static void method3() throws ClassNotFoundException {
		System.out.println("inside method3");

		System.out.println("method3 started");

		System.out.println("method3 ended ");

	}

}
