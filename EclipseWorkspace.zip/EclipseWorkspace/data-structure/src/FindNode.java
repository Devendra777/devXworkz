
public class FindNode {
	int val;
	FindNode next;

	FindNode(int x) {
		val = x;
		next = null;
	}

	public class Solution {

		public FindNode getIntersectionNode(FindNode headA, FindNode headB) {
			if (headA == null || headB == null) {
				return null;
			}
			int lengthA = getLength(headA);
			int lengthB = getLength(headB);
			int difference = lengthA - lengthB;

			if (difference == 0) {
				FindNode currentA = headA;
				FindNode currentB = headB;
				while (currentA != null || currentB != null) {
					if (currentA == currentB) {
						return currentA;
					}
					currentA = currentA.next;
					currentB = currentB.next;
				}
				return null;
			} else if (difference > 0) {
				return getPoint(difference, headA, headB);
			} else {
				return getPoint(Math.abs(difference), headB, headA);
			}
		}

		/* Calculate and return the length of the linked list */
		private int getLength(FindNode head) {
			FindNode current = head;
			int length = 0;
			while (current != null) {
				length++;
				current = current.next;
			}
			return length;
		}

		/*
		 * Find and return the intersection node when length of two linked lists are
		 * different.
		 */
		private FindNode getPoint(int diff, FindNode headLong, FindNode headShort) {
			FindNode currentLong = headLong;
			while (diff != 0) {
				diff--;
				currentLong = currentLong.next;
			}
			FindNode currentShort = headShort;
			while (currentLong != null || currentShort != null) {
				if (currentLong == currentShort) {
					return currentLong;
				}
				currentLong = currentLong.next;
				currentShort = currentShort.next;
			}
			return null;
		}
	}
}
