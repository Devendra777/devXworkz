package com.dev.devapp;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;

public class Insta {
	


		public static void main(String[] args) {
			
			
//    Date to String
				Date date = new Date();
				System.out.println(date);
				SimpleDateFormat  dateFormat = new SimpleDateFormat("MM/dd/YYYY");
				 
				System.out.println( dateFormat.format(date));
				    
				  
			
		//MM/dd/YYYY , "dd-M-yyyy" ,  "dd MMMM yyyy" , 	dd MMMM yyyy zzzz ,  E,dd MMM yyyy HH:mm:ss z	  
				
			
				
			// Alternate way 	
				 DateFormat dateFormat2 = DateFormat.getDateInstance();
				 System.out.println(dateFormat2);
				 
				 Calendar  calendar = Calendar.getInstance();
				    System.out.println(calendar.getTime());
				
				    // using format() for conversion
			String 	string =     dateFormat2.format(calendar.getTime());
					System.out.println(string);
					
					
			//LocalDate , LocalTime , LocalDateTime , DateTimeFormatter		
					// String to Date
					
					
					SimpleDateFormat  dateFormat1 = new SimpleDateFormat("MM/dd/yyyy");
				 Date date2;
				try {
					date2 = dateFormat1.parse("10/15/2021");
					System.out.println(date2);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 
			
				
			     System.out.println(LocalDateTime.now());
		}
		
	
}
