package com.dev.devapp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CollectionOfInteger {
	
	
	
	public static void main(String[] args) {
		
	
	     List<Integer> integers = new ArrayList<Integer>();
	     integers.add(123);  //123
	     integers.add(12); // 12
	     integers.add(23);  
	     integers.add(4);
	     integers.add(8);
	     integers.add(4);
	     integers.add(10);
	     integers.add(11);
	     integers.add(45);
	     integers.add(78);
	     
	     
        integers.stream().filter(d -> d%2 == 0).forEach(System.out::println);
	
	       
	     
	     
	     
	     //without streams 
		/*
		 * List<Integer> integers2 = getData(integers); for (Integer integer :
		 * integers2) { System.out.println(integer); }
		 */
	}
	
	
	public static List<Integer> getData(List<Integer> integers){
		List<Integer> integers2 = new ArrayList<Integer>();
		
		for (Integer integer : integers) {
			System.out.println(integer);
			if(integer >= 15) {
				integers2.add(integer);
			}
		}
		return integers2;
		
	}
}
