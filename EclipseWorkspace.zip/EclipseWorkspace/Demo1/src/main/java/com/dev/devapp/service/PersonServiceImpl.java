package com.dev.devapp.service;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

import com.dev.devapp.model.Person;
import com.dev.devapp.model.Response;


@Path("/person")
@Consumes(MediaType.APPLICATION_XML)
public class PersonServiceImpl implements PersonService{
	
	private static Map<Integer,Person> persons = new HashMap<Integer,Person>();

	
	@Path("/add")
	@POST
	public Response addPerson(Person p) {
		
		Response response = new Response();
		
		if(persons.get(p.getId()) !=null)
		{
			response.setStatus(false);
			response.setMessage("Person Already Exists");
			return response;
		}
		
		persons.put(p.getId(),p);
		response.setStatus(true);
		response.setMessage("Person created successfully");
		
		return response;
	}

	public Response deletePerson(int id) {
		return null;
	}

	public Person getPerson(int id) {
		return null;
	}

	public Person[] getAllPersons() {
		return null;
	}
	
	
	
	

}
