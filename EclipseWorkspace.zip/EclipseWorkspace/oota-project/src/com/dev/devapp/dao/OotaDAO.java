package com.dev.devapp.dao;

import java.util.List;

import com.dev.devapp.dto.OotaDTO;

public interface OotaDAO {
	
	public void saveOota(OotaDTO  dto);
	public List<OotaDTO> getOota(String name);


}
