package com.dev.devapp.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.dev.devapp.dto.OotaDTO;

public class OotaDAOImpl implements OotaDAO {

	@Override
	public void saveOota(OotaDTO dto) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction tx = null;
		try {
			StandardServiceRegistry standardServiceRegistry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
			Metadata metadata = metadataSources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(dto);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}

			if (sessionFactory != null) {
				sessionFactory.close();
			}

		}

	}
//      sslee
	/*
	 * @Override public List<OotaDTO> getOota(String name) { SessionFactory
	 * sessionFactory = null; Session session = null; OotaDTO ootaDTO = null; try {
	 * StandardServiceRegistry standardServiceRegistry = new
	 * StandardServiceRegistryBuilder().configure().build(); MetadataSources
	 * metadataSources = new MetadataSources(standardServiceRegistry); Metadata
	 * metadata = metadataSources.getMetadataBuilder().build(); sessionFactory =
	 * metadata.getSessionFactoryBuilder().build(); session =
	 * sessionFactory.openSession(); // prepare the query Query query =
	 * session.createQuery("from OotaDTO o"); // processing the query ootaDTO =
	 * (OotaDTO) query.list();
	 * 
	 * 
	 * } catch (HibernateException e) {
	 * 
	 * e.printStackTrace(); } finally { if (session != null) { session.close(); }
	 * 
	 * if (sessionFactory != null) { sessionFactory.close(); }
	 * 
	 * } // return ootaDTO;
	 * 
	 * }
	 */
	
	
	public List<Object[]> getOotaPlaceByName()
	{
		SessionFactory sessionFactory = null;
		Session session = null;
		List<Object[]> place = null;
		try {
			StandardServiceRegistry standardServiceRegistry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
			Metadata metadata = metadataSources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
			session = sessionFactory.openSession();
			// create the query
			Query query = session.createQuery("select oo.place,oo.type from OotaDTO oo where oo.type='"++"'");
			// processing the query
			place =   query.list();
			for (Object[] objects : place) {
				for (Object objects2 : objects) {
					System.out.println(objects2);
				}
			}

		} catch (HibernateException e) {

			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}

			if (sessionFactory != null) {
				sessionFactory.close();
			}

		}

		
		return place;
		
	}


	@Override
	public List<OotaDTO> getOota(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}