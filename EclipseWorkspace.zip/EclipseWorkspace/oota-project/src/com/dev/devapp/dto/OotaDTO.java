package com.dev.devapp.dto;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "oota_table")
public class OotaDTO implements Serializable {

	@Id
	@GenericGenerator(name = "ref", strategy = "increment")
	@GeneratedValue(generator = "ref")
	private int ootaId;
	private String name;
	private String place;
	private String type;

	public int getOotaId() {
		return ootaId;
	}

	public void setOotaId(int ootaId) {
		this.ootaId = ootaId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "OotaDTO [ootaId=" + ootaId + ", name=" + name + ", place=" + place + ", type=" + type + "]";
	}

}
