package com.dev.devapp.util;

import com.dev.devapp.dao.OotaDAO;
import com.dev.devapp.dao.OotaDAOImpl;
import com.dev.devapp.dto.OotaDTO;

public class Tester {
	
	
	
	
	public static void main(String[] args) {
		
		
		OotaDTO dto = new OotaDTO();
		dto.setName("chicken65");
		dto.setPlace("Restuarant");
		dto.setType("nonVeg");
		
		OotaDAOImpl ootaDAO  = new OotaDAOImpl();
		//ootaDAO.saveOota(dto);
	 //ootaDAO.getOota("kabab");
	ootaDAO.getOotaPlaceByName();
	}

}
