class Terminal {

public  int terminalId;
public  String name ; 

@Override
public String toString(){
return "Terminal -[terminalId = "+ this.terminalId +" , name = " +  this.name+"]";
}

}