package com.wellpoint.pc2dash.data.dao;

import static com.wellpoint.pc2dash.util.Constants.GRP;
import static com.wellpoint.pc2dash.util.Constants.PGM;
import static com.wellpoint.pc2dash.util.Constants.LINE_OF_BUSINESS;
import static com.wellpoint.pc2dash.util.Constants.MARKET;
import static com.wellpoint.pc2dash.util.Constants.NEW_LINE;
import static com.wellpoint.pc2dash.util.Constants.PROV_GRP_ID_ALL;
import static com.wellpoint.pc2dash.util.Constants.COMMA;
import static com.wellpoint.pc2dash.util.Constants.DATA_FORMAT_FOR_RX;
import static com.wellpoint.pc2dash.util.Constants.DATA_FORMAT_FOR_ASC_PERF_RATE;
import static com.wellpoint.pc2dash.util.Constants.DATA_FORMAT;
import static com.wellpoint.pc2dash.util.Constants.SINGLE_WHITE_SPACE;
import static com.wellpoint.pc2dash.util.Constants.AND_OPERATOR;
import static com.wellpoint.pc2dash.util.Constants.PERCENT_SIGN;
import static com.wellpoint.pc2dash.util.Constants.DASHES;
import static com.wellpoint.pc2dash.util.Constants.COC_ASC;
import static com.wellpoint.pc2dash.util.Constants.COC_IP;
import static com.wellpoint.pc2dash.util.Constants.COC_SOC;
import static com.wellpoint.pc2dash.util.Constants.COC_RX;
import static com.wellpoint.pc2dash.util.Constants.COC_EBC;
import static com.wellpoint.pc2dash.util.Constants.COC_LAB;
import static com.wellpoint.pc2dash.util.Constants.COC_SPL;
import static com.wellpoint.pc2dash.util.Constants.COC_PAER;
import static com.wellpoint.pc2dash.util.Constants.SORT_DESC;
import static com.wellpoint.pc2dash.util.Constants.N;
import static com.wellpoint.pc2dash.util.Constants.Y;
import static com.wellpoint.pc2dash.util.Constants.BOOL_TRUE;
import static com.wellpoint.pc2dash.util.Constants.BOOL_FALSE;
import static com.wellpoint.pc2dash.util.Constants.ALIAS_PAT_SMRY_FACT;
import static com.wellpoint.pc2dash.util.Constants.MEDICARE;
import static com.wellpoint.pc2dash.util.Constants.MEDICARE_ADVANTAGE;
import static com.wellpoint.pc2dash.util.Constants.A;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;

import com.wellpoint.pc2dash.action.costOpportunity.GetCostOpportunitySummaryRequest;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmry50PctBenchmarkComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmry50PctImprovComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmry50PctPMPMImprovComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmry75PctBenchmarkComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmry75PctImprovComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmry75PctPMPMImprovComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmryABRatioComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmryChainedComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmryCurrentPerformancePercentileComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmryMtrcNmComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmryTotlOpportunityComparator;
import com.wellpoint.pc2dash.comparator.costOpportunity.COCSmryTotlOpportunityPMPMComparator;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.AppProperty;
import com.wellpoint.pc2dash.dto.costOpportunity.CostOpportunityBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.COCSmryMinCriteriaEnum;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QueryConstants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

/**
 * 
 * @author AF21145
 *
 */
public class CostOpportunitySummaryFactsDao extends AbstractDao {
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CostOpportunitySummaryFactsDao.class);
	private BigDecimal vMemberMonths = BigDecimal.ZERO;
	private BigDecimal vTotalMembers = BigDecimal.ZERO;
	private Map<String, BigDecimal> memberMonthMap;
	private Map<String, BigDecimal> totalMemberMap;
	private static final String METRIC_CD = "metricCode";
	private static final String METRIC_NM = "metricName";
	private static final String COST_OPPORTUNITY = "totalOpportunity";
	private static final String COST_OPPORTUNITY_PMPM = "totalOpportunityPMPM";
	private static final String PCT_75_IMPROV_PMPM = "seventyFivePercentImprovementPMPM";
	private static final String PCT_50_IMPROV_PMPM = "fiftyPercentImprovementPMPM";
	private static final String ACTUAL_BNCHMRK_RATIO = "actualBenchmarkRatio";
	private static final String PCTL_BNCHMRK_90 = "percentileBenchmark90";
	private static final String PCTL_BNCHMRK_75 = "percentileBenchmark75";
	private static final String PCTL_BNCHMRK_50 = "percentileBenchmark50";
	private static final String PCT_75_IMPROV = "seventyFivePercentImprovement";
	private static final String PCT_50_IMPROV = "fiftyPercentImprovement";
	private static final String TOTL_ASC_AMT = "COST_OPRTNTY_AMT";
	private static final String ALIAS_ASC_CATGRY = "ASMRY";
	private static final String ALIAS_COC_SMRY = "SMRY";
	private static final String ALIAS_COC_LIER = "LIER";
	private static final String ALIAS_IP_SMRY = "IPSMRY";
	private static final String ALIAS_PAT_SMRY_FACT = "PSF";
	private static final String ALIAS_SOC_SMRY = "SOCSMRY";
	private static final String MEM_MNTH = "vMbrMonths";
	private static final String TOTL_MBR = "vTotalMembers";
	private static final String TOTL_TC_INPAT_DAY_CNT = "TOTL_TC_INPAT_DAY_CNT";
	private static final String TOTL_EXPECTED_DAYS = "TOTL_EXPECTED_DAYS";
	private static final String TOTL_EXPECTED_DAYS_50 = "TOTL_EXPECTED_DAYS_50";
	private static final String TOTL_EXPECTED_DAYS_75 = "TOTL_EXPECTED_DAYS_75";
	private static final String MBR_MNTH = "MEM_MNTH";
	private static final String TOTL_MEMBER = "TOTL_MEMBER";
	private static final String MULTIPLEBENCHMARKINDICATOR = "MULTIPLEBENCHMARKINDICATOR";
	private static final String COC_PAER_MIN_TOTL_SCRPT = "COC_PAER_MIN_TOTL_SCRPT";
	private static final String CURRENT_PERFORMANCE_PERCENTILE = "currentPerformancePercentile";
	private static final String CURRENT_PERFORMANCE_RATE = "currPerfRate";
	private static final String ACTUAL_BENCHMARK_RATIO = "actualBenchmarkRatio";
	private static final String IPSMRY1 = "IPSMRY1";
	private static final String LOB_DESC = "LOB_DESC";

	private static final BigDecimal PERF_RATE_100_FACTOR = BigDecimal.valueOf(100);
	private static final BigDecimal PERF_RATE_1000_FACTOR = BigDecimal.valueOf(1000);
	private static final BigDecimal PERF_RATE_12K_FACTOR = BigDecimal.valueOf(12000);
	private static final String LS = "LS";
	private static final String s = "s";

	private boolean isGroupSuppressed;
	private boolean isMarketSuppressed;
	private boolean isProgramSuppressed;
	private boolean isLOBSuppressed;
	private boolean isAllSuppressed;
	private boolean isAnySuppressed;
	private Map<String, Boolean> vMinimumCriteriaMap;
	private CommonQueries cq = new CommonQueries();

	/**
	 * Parameterized Constructor to initialize common parameters
	 * 
	 * @param request
	 */
	public CostOpportunitySummaryFactsDao(GetCostOpportunitySummaryRequest request) {

		memberMonthMap = getMemberMonth(request);
		totalMemberMap = getTotalMember(request);
		vMemberMonths = null != memberMonthMap.get(MEM_MNTH) ? memberMonthMap.get(MEM_MNTH) : BigDecimal.ZERO;
		vTotalMembers = null != totalMemberMap.get(TOTL_MBR) ? totalMemberMap.get(TOTL_MBR) : BigDecimal.ZERO;
		vMinimumCriteriaMap = getMinimumCriteriaByMetric(request);
	}

	/**
	 * Method to determine Minimum Criteria of all Metric
	 * 
	 * @param request
	 * @return
	 */
	private Map<String, Boolean> getMinimumCriteriaByMetric(GetCostOpportunitySummaryRequest request) {
		Map<String, Boolean> returnMap = new HashMap<String, Boolean>();

		returnMap.put(COC_RX, cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request,
				COCSmryMinCriteriaEnum.valueOf(COC_RX).getMinimumCriteriaBean()));
		returnMap.put(COC_LAB, cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request,
				COCSmryMinCriteriaEnum.valueOf(COC_LAB).getMinimumCriteriaBean()));
		returnMap.put(COC_ASC, cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request,
				COCSmryMinCriteriaEnum.valueOf(COC_ASC).getMinimumCriteriaBean()));
		returnMap.put(COC_EBC, cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request,
				COCSmryMinCriteriaEnum.valueOf(COC_EBC).getMinimumCriteriaBean()));
		returnMap.put(COC_SPL, cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request,
				COCSmryMinCriteriaEnum.valueOf(COC_SPL).getMinimumCriteriaBean()));
		returnMap.put(COC_IP, cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request,
				COCSmryMinCriteriaEnum.valueOf(COC_IP).getMinimumCriteriaBean()));
		returnMap.put(COC_SOC, cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request,
				COCSmryMinCriteriaEnum.valueOf(COC_SOC).getMinimumCriteriaBean()));
		returnMap.put(COC_PAER, getPAERMinimumCriteria(vMemberMonths));

		return returnMap;
	}

	/**
	 * Minimum Criteria Logic for PAER
	 * 
	 * @param vMemberMonths2
	 * @return
	 */
	private Boolean getPAERMinimumCriteria(BigDecimal vMemberMonths2) {

		BigDecimal vMinPAERCCnt = BigDecimal.ZERO;
		StringBuilder query = buildQueryForPAERMinCriteria();

		try {
			cn = Database.getConnection(Constants.SNOWFLAKE_DATASOURCE);
			prepareStatement(logger, query.toString());
			executeQuery(logger, query.toString());

			while (rs.next()) {

				vMinPAERCCnt = null != rs.getString(COC_PAER_MIN_TOTL_SCRPT) ? rs.getBigDecimal(COC_PAER_MIN_TOTL_SCRPT)
						: BigDecimal.ZERO;

			}
		} catch (Exception e) {
			logger.error("Error in getPAERMinimumCriteria", e);
		} finally {
			close();
		}

		return (vMemberMonths2.compareTo(vMinPAERCCnt) < 0);
	}

	/**
	 * Method exposed to the service layer for fetching records.
	 * 
	 * @param request
	 * @param exportFlag
	 * @return
	 * @throws SQLException
	 */
	public List<CostOpportunityBean> getCOCSummarydata(GetCostOpportunitySummaryRequest request, boolean exportFlag)
			throws SQLException {
		List<CostOpportunityBean> metricList = new ArrayList<CostOpportunityBean>();
		showAll = StringUtil.isInternalUser(request);
		String metricCode;
		String metricName;

		if (null != request.getAppPrptyList()) {

			for (AppProperty prop : request.getAppPrptyList()) {
				resetLevelSuppression();

				List<CostOpportunityBean> objCostOpportunityBeanList = null;// Re-initialize for individual metric
				metricCode = prop.getComment();
				metricName = prop.getValue();

				checkSuppression(request, metricName);
				if (null != metricCode) {
					if (COC_ASC.equals(metricCode)) {
						BigDecimal totalOpportunity = fetchASCOpportunityFromCategory(request);
						objCostOpportunityBeanList = fetchRecordsForMetric(request, metricCode, metricName,
								totalOpportunity, exportFlag);
					} else if (COC_IP.equals(metricCode)) {
						objCostOpportunityBeanList = fetchRecordsForIPMetric(request, metricCode, metricName,
								exportFlag);
					} else if (COC_SOC.equals(metricCode)) {
						objCostOpportunityBeanList = fetchRecordsForSOCMetric(request, metricCode, metricName,
								exportFlag);
					} else {
						objCostOpportunityBeanList = fetchRecordsForMetric(request, metricCode, metricName,
								BigDecimal.ZERO, exportFlag);
					}
					if (null != objCostOpportunityBeanList && !objCostOpportunityBeanList.isEmpty()) {// null check to
																										// master list
						metricList.addAll(objCostOpportunityBeanList);
					}
				}
			}
			if (null != metricList && !metricList.isEmpty()) {
				maskAndFilterRecordsforMetric(metricList, request, exportFlag);
				sortResultListByUserRequest(metricList, request.getSort());
			}
		}
		return metricList;
	}

	/**
	 * Method to reset the level suppression
	 */
	private void resetLevelSuppression() {
		isGroupSuppressed = false;
		isMarketSuppressed = false;
		isProgramSuppressed = false;
		isLOBSuppressed = false;
		isAllSuppressed = false;
	}

	/**
	 * Method to check the suppression for each metric
	 * 
	 * @param request
	 * @param metricName
	 */
	private void checkSuppression(GetCostOpportunitySummaryRequest request, String metricName) {
		if (!MapUtils.isEmpty(request.getSuppression())) {
			request.setTapId(metricName);
			if (request.getSuppression().containsKey(metricName)) {
				isGroupSuppressed = !StringUtil.isSuppressedTAPGRPsEmpty(request)
						&& (StringUtil.hasAllSuppression(request) == 0);
				isMarketSuppressed = !StringUtil.isSuppressedTAPMKTEmpty(request);
				isProgramSuppressed = !StringUtil.isSuppressedTAPPGMsEmpty(request);
				isLOBSuppressed = !StringUtil.isSuppressedTAPLOBsEmpty(request);
				isAllSuppressed = !StringUtil.isSuppressedTAPALLEmpty(request);

				isAnySuppressed = isGroupSuppressed || isMarketSuppressed || isProgramSuppressed || isLOBSuppressed
						|| isAllSuppressed;

			}
			if (isGroupSuppressed || isMarketSuppressed || isProgramSuppressed || isLOBSuppressed || isAllSuppressed) {
				isAnySuppressed = true;
			} else {
				isAnySuppressed = false;
			}
		}
	}

	/**
	 * Method to obtain ASC metric Record
	 * 
	 * @param request
	 * @return
	 */
	private BigDecimal fetchASCOpportunityFromCategory(GetCostOpportunitySummaryRequest request) {
		BigDecimal totalASCAmount = BigDecimal.ZERO;

		StringBuilder query = new StringBuilder()
				.append(" SELECT NVL ( SUM(COST_OPRTNTY_AMT) , 0 )  AS COST_OPRTNTY_AMT ") // Modified as part of defect
																							// PCMSP-29511 - 2018Q4
				.append(" FROM( ")
				.append(" SELECT CASE WHEN SUM(ASMRY.COST_OPRTNTY_AMT) < 0 then 0.00 else SUM(ASMRY.COST_OPRTNTY_AMT) end as  COST_OPRTNTY_AMT ")
				.append(" FROM   COC_ASC_CTGRY_SMRY AS ASMRY ")
				.append(" JOIN  POIT_USER_SCRTY_ACS AS PUSA ON (  ASMRY.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
				.append(" AND CASE WHEN  PUSA.PROV_ORG_TAX_ID = '0' ")
				.append(" THEN   ASMRY.PROV_ORG_TAX_ID ELSE  PUSA.PROV_ORG_TAX_ID  END = ASMRY.PROV_ORG_TAX_ID )")
				.append(" WHERE    PUSA.SESN_ID = ? ").append(" AND    PUSA.ENTTLMNT_HASH_KEY  = ? ");

		setFiltersWithoutSuppression(query, request, ALIAS_ASC_CATGRY, true);

		query.append(" GROUP BY ASMRY.SUB_MTRC_NM, ASMRY.SUB_MTRC_CD) ");

		try {
			cn = Database.getConnection(Constants.SNOWFLAKE_DATASOURCE);
			int i = 0;

			prepareStatement(logger, query.toString());

			buildPreparedStatementWithOutSuppression(request, "ALL", i);

			executeQuery(logger, query.toString());

			while (rs.next()) {
				totalASCAmount = rs.getBigDecimal(TOTL_ASC_AMT);
			}
		} catch (Exception e) {
			logger.error("Error in fetchASCOpportunityFromCategory", e);
		} finally {
			close();
		}

		return totalASCAmount;
	}

	/**
	 * Method to fetch Record for In-patient Utilization Metric
	 * 
	 * @param request
	 * @param metricCode
	 * @param metricName
	 * @return
	 */
	private List<CostOpportunityBean> fetchRecordsForIPMetric(GetCostOpportunitySummaryRequest request,
			String metricCode, String metricName, boolean exportFlag) {
		List<CostOpportunityBean> resultList = new ArrayList<CostOpportunityBean>();

		StringBuilder query = new StringBuilder().append(" SELECT 'Inpatient Utilization' AS metricName, ")
				.append(" 'IP' AS metricCode  ,").append(" LOB_DESC, ").append(" MRKT_CD, ")
				.append(" COST_OPRTNTY_AMT as totalOpportunity, ")
				.append(" seventyFivePercentImprovement, fiftyPercentImprovement, totalOpportunityPMPM,")
				.append(" seventyFivePercentImprovementPMPM, ").append(" fiftyPercentImprovementPMPM, ")
				.append(" percentileBenchmark90, ").append(" percentileBenchmark75, ")
				.append(" percentileBenchmark50, ")

				.append(" currPerfRate , BNCHMRK_PCTILE_NBR AS currentPerformancePercentile,  ")
				.append(" CASE WHEN percentileBenchmark90=0 THEN NULL ELSE currPerfRate/percentileBenchmark90 END AS actualBenchmarkRatio ")
				.append(" FROM (  ")

				.append(" SELECT ").append(" G.LOB_DESC, ")

				.append(" MRKT_CD,").append(" COST_OPRTNTY_AMT, ")
				.append(" seventyFivePercentImprovement, fiftyPercentImprovement, totalOpportunityPMPM,")
				.append(" seventyFivePercentImprovementPMPM, ").append(" fiftyPercentImprovementPMPM, ")
				.append(" percentileBenchmark90, ").append(" percentileBenchmark75, ")
				.append(" percentileBenchmark50, ").append(" currPerfRate ,")

				.append(" BNCHMRK_PCTILE_NBR,").append(" BNCHMRK_PCTAG_AMT, ")
				.append(" row_number() OVER (PARTITION BY G.LOB_DESC order by ABS(BNCHMRK_PCTAG_AMT- currPerfRate) ASC,   BNCHMRK_PCTILE_NBR DESC) AS pctl_row_num ")
				.append(" FROM (  ").append(" SELECT  ")

				.append(" SUM(COST_OPRTNTY_AMT) AS COST_OPRTNTY_AMT, ")
				.append(" SUM(seventyFivePercentImprovement) AS seventyFivePercentImprovement, ")

				.append(" SUM(fiftyPercentImprovement) AS fiftyPercentImprovement, ")
				.append(" SUM(totalOpportunityPMPM) AS totalOpportunityPMPM, ")
				.append(" SUM(seventyFivePercentImprovementPMPM) AS seventyFivePercentImprovementPMPM, ")
				.append(" SUM(fiftyPercentImprovementPMPM) AS fiftyPercentImprovementPMPM, ")
				.append(" MAX(BNCHMRK_90_PCTILE_SMRY) AS percentileBenchmark90, ")
				.append(" MAX(BNCHMRK_75_PCTILE_SMRY) AS percentileBenchmark75, ")
				.append(" MAX(BNCHMRK_50_PCTILE_SMRY)  AS percentileBenchmark50, ")
				.append(" MAX(currPerfRate_SMRY) / MAX(TOTL_MBR_MNTHS) AS currPerfRate, " + " LOB_DESC, "
						+ " MRKT_CD   " + " FROM ( " + " SELECT " + " SUB_MTRC_NM, "
						+ " SUM(COST_OPRTNTY_AMT) AS COST_OPRTNTY_AMT, "
						+ " SUM(seventyFivePercentImprovement) AS seventyFivePercentImprovement, "
						+ " SUM(fiftyPercentImprovement) AS fiftyPercentImprovement, ")

				.append(" SUM(totalOpportunityPMPM) AS totalOpportunityPMPM, ")
				.append(" SUM(seventyFivePercentImprovementPMPM) AS seventyFivePercentImprovementPMPM, ")
				.append(" SUM(fiftyPercentImprovementPMPM) AS fiftyPercentImprovementPMPM, ")
				.append(" SUM(INPAT_DAY_CNT) AS INPAT_DAY_CNT, ").append(" SUM(ADMT_CNT) AS ADMT_CNT, ")
				.append(" MAX(TOTL_MBR_MNTHS) AS TOTL_MBR_MNTHS, ")
				.append(" SUM(NBR_ADMTS_ABV_BNCHMRK_90) AS NBR_ADMTS_ABV_BNCHMRK_90, ")
				.append(" CASE WHEN SUM(ADMT_CNT)=0 THEN NULL ELSE SUM(INPAT_DAY_CNT)/ SUM(ADMT_CNT) END AS AVG_LOS, ")
				.append(" MAX(AGE_MBR_MNTHS) AS AGE_MBR_MNTHS, ")
				.append(" ((SUM(percentileBenchmark90)*MAX(AGE_MBR_MNTHS))/ MAX(TOTL_MBR_MNTHS)) AS BNCHMRK_90_PCTILE_SMRY, ")
				.append(" ((SUM(percentileBenchmark75)*MAX(AGE_MBR_MNTHS))/ MAX(TOTL_MBR_MNTHS)) AS BNCHMRK_75_PCTILE_SMRY, ")
				.append(" ((SUM(percentileBenchmark50)*MAX(AGE_MBR_MNTHS))/ MAX(TOTL_MBR_MNTHS)) AS BNCHMRK_50_PCTILE_SMRY, ")
				.append(" SUM(currPerfRate)*MAX(AGE_MBR_MNTHS) AS currPerfRate_SMRY, ").append(" LOB_DESC, MRKT_CD ")
				.append(" FROM ( ").append(" SELECT  ").append(" LOB_DESC, ").append(" SUB_MTRC_NM, ")
				.append(" CTGRY_NM, ")
				.append(" CASE WHEN COST_OPRTNTY_AMT<0  THEN 0 ELSE COST_OPRTNTY_AMT END AS COST_OPRTNTY_AMT, ")
				.append(" CASE WHEN seventyFivePercentImprovement<0  THEN 0 ELSE seventyFivePercentImprovement END AS seventyFivePercentImprovement, ")
				.append(" CASE WHEN fiftyPercentImprovement<0  THEN 0 ELSE fiftyPercentImprovement END AS fiftyPercentImprovement, ")
				.append(" CASE WHEN totalOpportunityPMPM<0  THEN 0 ELSE totalOpportunityPMPM END AS totalOpportunityPMPM, ")
				.append(" CASE WHEN seventyFivePercentImprovementPMPM<0  THEN 0 ELSE seventyFivePercentImprovementPMPM END AS seventyFivePercentImprovementPMPM,")
				.append(" CASE WHEN fiftyPercentImprovementPMPM<0  THEN 0 ELSE fiftyPercentImprovementPMPM END AS fiftyPercentImprovementPMPM, ")
				.append(" AGE_MBR_MNTHS, ").append(" ADMT_CNT, ").append(" SVRTY_SCOR_NBR, ").append(" currPerfRate, ")
				.append(" percentileBenchmark90, ").append(" percentileBenchmark75, ")
				.append(" percentileBenchmark50, ")
				.append(" CASE WHEN ROUND(NBR_ADMTS_ABV_BNCHMRK_90)< 0 THEN 0 ELSE ROUND(NBR_ADMTS_ABV_BNCHMRK_90) END AS NBR_ADMTS_ABV_BNCHMRK_90, ")
				.append(" ALWD_COST_PER_ADMT, ").append(" INPAT_DAY_CNT, ").append(" AVG_LOS, ")
				.append(" TOTL_MBR_MNTHS, ").append(" MRKT_CD ").append(" FROM ( ").append(" SELECT ")
				.append(" SUB_MTRC_NM,").append(" CTGRY_NM, ").append(" TOTL_ALWD_AMT, ").append(" ADMT_CNT, ")
				.append(" INPAT_DAY_CNT, ").append(" percentileBenchmark90, ").append(" percentileBenchmark75, ")
				.append("  percentileBenchmark50, ").append("AGE_MBR_MNTHS, ").append("SVRTY_SCOR_NBR,")
				.append(" ALWD_COST_PER_ADMT, ")
				.append(" ADMT_CNT-((percentileBenchmark90*SVRTY_SCOR_NBR)*(AGE_MBR_MNTHS/12000))AS NBR_ADMTS_ABV_BNCHMRK_90, ")
				.append("ADMT_CNT-((percentileBenchmark75*SVRTY_SCOR_NBR)*(AGE_MBR_MNTHS/12000)) AS NBR_ADMTS_ABV_BNCHMRK_75,")
				.append(" ADMT_CNT-((percentileBenchmark50*SVRTY_SCOR_NBR)*(AGE_MBR_MNTHS/12000)) AS NBR_ADMTS_ABV_BNCHMRK_50,")
				.append(" ALWD_COST_PER_ADMT*NBR_ADMTS_ABV_BNCHMRK_90 AS COST_OPRTNTY_AMT, ")
				.append(" ALWD_COST_PER_ADMT*NBR_ADMTS_ABV_BNCHMRK_75 AS seventyFivePercentImprovement, ")
				.append(" ALWD_COST_PER_ADMT*NBR_ADMTS_ABV_BNCHMRK_50 AS fiftyPercentImprovement, ")
				.append(" TOTL_MBR_MNTHS, ")
				.append(" CASE WHEN TOTL_MBR_MNTHS=0 THEN NULL ELSE COST_OPRTNTY_AMT/TOTL_MBR_MNTHS END AS totalOpportunityPMPM, ")
				.append(" CASE WHEN TOTL_MBR_MNTHS=0 THEN NULL ELSE seventyFivePercentImprovement/TOTL_MBR_MNTHS END AS seventyFivePercentImprovementPMPM,")
				.append(" CASE WHEN TOTL_MBR_MNTHS=0 THEN NULL ELSE fiftyPercentImprovement/TOTL_MBR_MNTHS END AS fiftyPercentImprovementPMPM, ")
				.append(" CASE WHEN SVRTY_SCOR_NBR=0 OR AGE_MBR_MNTHS=0 THEN NULL ELSE ((ADMT_CNT/SVRTY_SCOR_NBR)/AGE_MBR_MNTHS)*12000 END AS currPerfRate, ")
				.append(" AVG_LOS,LOB_DESC, MRKT_CD ").append(" FROM( ").append(" SELECT  ").append(" A.LOB_DESC, ")
				.append(" SUB_MTRC_NM, ").append("CTGRY_NM, ").append("SUM(TOTL_ALWD_AMT) AS TOTL_ALWD_AMT,")
				.append("SUM(ADMT_CNT) AS ADMT_CNT,").append(" SUM(INPAT_DAY_CNT) AS INPAT_DAY_CNT, ")
				.append("AVG(BNCHMRK_90_PCTILE_AMT) AS percentileBenchmark90,")
				.append("AVG(BNCHMRK_75_PCTILE_AMT) AS percentileBenchmark75,")
				.append("AVG(BNCHMRK_50_PCTILE_AMT) AS percentileBenchmark50,")
				.append("MAX(B.AGE_MBR_MNTHS) AS AGE_MBR_MNTHS,")

				.append("MAX(B.TOTL_MBR_MNTHS) AS TOTL_MBR_MNTHS,").append("MAX(B.SVRTY_SCOR_NBR) AS SVRTY_SCOR_NBR,")
				.append(" MAX(ALWD_COST_PER_ADMT) AS ALWD_COST_PER_ADMT, ")
				.append(" CASE WHEN SUM(ADMT_CNT)=0 THEN NULL ELSE SUM(INPAT_DAY_CNT)/ SUM(ADMT_CNT) END AS AVG_LOS,")
				.append(" substr(A.PI_PGM_ID,1,2) AS MRKT_CD ").append(" from COC_IP_UTL_CTGRY_SMRY A ")
				.append(" INNER JOIN  ").append(" ( ").append(" SELECT  ").append(" GRP_RISK_SCOR.LOB_DESC, ")
				.append(" GRP_RISK_SCOR.AGE_GRP_NM, ").append(" GRP_RISK_SCOR.AGE_MBR_MNTHS, ")
				.append(" GRP_RISK_SCOR.TOTL_MBRS, ").append(" GRP_RISK_SCOR.GRP_AVG_RISK_SCOR, ")
				.append(" POP_RISK_SCOR.POP_AVG_RISK_SCOR_NBR, ")
				.append(" SUM(GRP_RISK_SCOR.AGE_MBR_MNTHS) OVER (PARTITION BY GRP_RISK_SCOR.LOB_DESC) AS TOTL_MBR_MNTHS, ")
				.append(" CASE WHEN POP_RISK_SCOR.POP_AVG_RISK_SCOR_NBR=0 THEN NULL ELSE CAST(GRP_RISK_SCOR.GRP_AVG_RISK_SCOR/POP_RISK_SCOR.POP_AVG_RISK_SCOR_NBR AS DECIMAL(18,2)) END AS SVRTY_SCOR_NBR ")
				.append(" FROM ").append(" (SELECT ").append(" LOB_DESC, ")
				.append(" CASE WHEN AGE_NBR<18 THEN 'Pediatric' ELSE 'Adult' END AS AGE_GRP_NM, ")
				.append(" NVL(SUM(MM.MBR_MNTH_12_CNT),0) AS AGE_MBR_MNTHS, ")
				.append(" COUNT(DISTINCT PSF.MSTR_CNSMR_DIM_KEY) AS TOTL_MBRS, ")
				.append(" SUM(RETRO_WGTD_RISK_NBR) AS GRP_RISK_SCOR, ")
				.append(" CASE WHEN COUNT(DISTINCT PSF.MSTR_CNSMR_DIM_KEY) =0 THEN NULL ELSE SUM(RETRO_WGTD_RISK_NBR)/COUNT(DISTINCT PSF.MSTR_CNSMR_DIM_KEY) END AS GRP_AVG_RISK_SCOR  ")
				.append(" FROM     PAT_SMRY_FACT PSF    ").append(" left join       MSTR_CNSMR_MBR_MNTH_FACT MM  ")
				.append(" ON MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY   ")
				.append(" and  MM.RCRD_STTS_CD = 'ACT'    ").append(" left join       MSTR_CNSMR_DIM MCD  ")
				.append(" ON  MCD.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY   ")
				.append(" and  MCD.RCRD_STTS_CD = 'ACT'   ");
		query.append(QueryConstants.getPoitUserTableJoin("PSF")).append("Where " + QueryConstants.getPoitTableWhere())
				.append("  PSF.ATRBN_STTS_CD = 'ACTIVE'   ");

		if (!showAll && null != request.getAppPrptyList()) {
			setFiltersWithSuppression(query, request, metricCode, metricName, ALIAS_PAT_SMRY_FACT, BOOL_TRUE);
		} else {
			setFiltersWithoutSuppression(query, request, ALIAS_PAT_SMRY_FACT, BOOL_TRUE);
		}
		query.append("   GROUP BY 1,2) GRP_RISK_SCOR  ").append(" INNER JOIN  ").append(" (  ")
				.append(" SELECT DISTINCT  ").append(" LOB_DESC,  ")
				.append(" CASE WHEN AGE_NBR<18 THEN 'Pediatric' ELSE 'Adult' END AS AGE_GRP_NM,  ")
				.append(" AVG(MCD.RETRO_WGTD_RISK_NBR) OVER (PARTITION BY LOB_DESC,AGE_GRP_NM) AS POP_AVG_RISK_SCOR_NBR  ")
				.append(" from     PAT_SMRY_FACT PSF     ").append(" left join       MSTR_CNSMR_DIM MCD   ")
				.append(" ON  MCD.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY    ")
				.append(" and  MCD.RCRD_STTS_CD = 'ACT'  ").append("  WHERE  PSF.ATRBN_STTS_CD = 'ACTIVE'   ")
				.append("  ) POP_RISK_SCOR  ").append(" ON GRP_RISK_SCOR.LOB_DESC = POP_RISK_SCOR.LOB_DESC   ")
				.append(" AND GRP_RISK_SCOR.AGE_GRP_NM = POP_RISK_SCOR.AGE_GRP_NM  ").append(" ) B  ")
				.append(" ON A.SUB_MTRC_NM = B.AGE_GRP_NM   ").append(" AND  A.LOB_DESC = B.LOB_DESC  ");
		query.append(QueryConstants.getPoitUserTableJoin("A")).append("where  pusa.sesn_id = ? ")
				.append("and pusa.enttlmnt_hash_key = ? ");
		if (!showAll && null != request.getAppPrptyList()) {
			setFiltersWithSuppression(query, request, metricCode, metricName, A, BOOL_TRUE);
		} else {
			setFiltersWithoutSuppression(query, request, A, BOOL_TRUE);
		}
		query.append(" GROUP BY ").append(" SUB_MTRC_NM, ").append(" CTGRY_NM, ").append(" A.LOB_DESC, ")
				.append(" MRKT_CD ").append(" ) C ").append(" ) D ").append(" ) E ")
				.append(" GROUP BY SUB_MTRC_NM,LOB_DESC,MRKT_CD ").append(" )F ").append(" GROUP BY LOB_DESC,MRKT_CD ")
				.append(" ) G ").append(" INNER JOIN ").append(" ( ")
				.append(" SELECT IPSMRY1.LOB_DESC, CBD.MRKT_ST_CD, CBD.BNCHMRK_PCTILE_NBR,CBD.BNCHMRK_PCTAG_AMT  ")
				.append(" from  COC_BNCHMRK_DATA CBD   ").append(" join  COC_IP_UTL_CTGRY_SMRY  IPSMRY1  ")
				.append(" on  CBD.SUB_MTRC_NM = IPSMRY1.SUB_MTRC_NM   ")
				.append(" AND CBD.COC_MTRC_NM = IPSMRY1.CTGRY_NM   ")
				.append(" AND CBD.lob_desc  = CASE WHEN IPSMRY1.lob_desc='UniCare' THEN 'Commercial'  ")
				.append("  WHEN IPSMRY1.lob_desc='Medicare-Medicaid Plan' THEN 'Medicare Advantage'  ")
				.append("                   ELSE IPSMRY1.lob_desc END ")
				.append(" AND substr(IPSMRY1.PI_PGM_ID,1,2) = CBD.MRKT_ST_CD   ")
				.append(" AND CBD.RULE_ID  = IPSMRY1.RULE_ID  ");
		query.append(QueryConstants.getPoitUserTableJoin("IPSMRY1")).append(" where  pusa.sesn_id = ? ")
				.append("and pusa.enttlmnt_hash_key = ? ");
		if (!showAll && null != request.getAppPrptyList()) {
			setFiltersWithSuppression(query, request, metricCode, metricName, IPSMRY1, BOOL_TRUE);
		} else {
			setFiltersWithoutSuppression(query, request, IPSMRY1, BOOL_TRUE);
		}
		query.append(" group by  IPSMRY1.LOB_DESC, CBD.MRKT_ST_CD, CBD.BNCHMRK_PCTILE_NBR,CBD.BNCHMRK_PCTAG_AMT  ")
				.append(" ) I  ").append(" ON I.MRKT_ST_CD =G.MRKT_CD  ").append(" AND I.LOB_DESC =G.LOB_DESC ")
				.append(" ) M  ").append(" WHERE pctl_row_num=1  ");

		try {

			cn = Database.getConnection(Constants.SNOWFLAKE_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());
			buildPreparedStatement(request, metricCode, metricName, i);
			executeQuery(logger, query.toString());
			resultList = convertResultsetToBeanIP(rs, request, exportFlag);

		} catch (Exception e) {
			resultList = null;
			logger.error("Error in fetchRecordsForIPMetric", e);

		} finally {
			close();
		}

		return resultList;
	}

	private List<CostOpportunityBean> convertResultsetToBeanIP(ResultSet rs, GetCostOpportunitySummaryRequest request,
			boolean exportFlag) throws SQLException {

		List<CostOpportunityBean> results = new ArrayList<CostOpportunityBean>();
		BigDecimal vTotalOpportunity = BigDecimal.ZERO;
		BigDecimal vTotalOpportunityPMPM = BigDecimal.ZERO;
		BigDecimal vCurrentPerformaceRate = BigDecimal.ZERO;
		BigDecimal vPctlBenchmark90 = BigDecimal.ZERO;
		BigDecimal vPctlBenchmark75 = BigDecimal.ZERO;
		BigDecimal vPctlBenchmark50 = BigDecimal.ZERO;
		BigDecimal vActualBenchmarkRatio = BigDecimal.ZERO;
		BigDecimal v75PctImprovement = BigDecimal.ZERO;
		BigDecimal v50PctImprovement = BigDecimal.ZERO;
		BigDecimal v75PctImprovementPMPM = BigDecimal.ZERO;
		BigDecimal v50PctImprovementPMPM = BigDecimal.ZERO;
		String vCurrentPerformacePercentile = null;
		String vMetricCode = null;
		String vMetricName = null;
		String vDataFormat = null;

		while (rs.next()) {
			CostOpportunityBean item = new CostOpportunityBean();

			vMetricCode = null != rs.getString(METRIC_CD) ? rs.getString(METRIC_CD) : DASHES;
			vMetricName = null != rs.getString(METRIC_NM) ? rs.getString(METRIC_NM) + NEW_LINE : DASHES;

			vTotalOpportunity = null != rs.getString(COST_OPPORTUNITY)
					? rs.getBigDecimal(COST_OPPORTUNITY).setScale(2, BigDecimal.ROUND_HALF_UP)
					: BigDecimal.ZERO;
			vTotalOpportunityPMPM = null != rs.getString(COST_OPPORTUNITY_PMPM)
					? rs.getBigDecimal(COST_OPPORTUNITY_PMPM).setScale(2, BigDecimal.ROUND_HALF_UP)
					: BigDecimal.ZERO;

			vCurrentPerformaceRate = null != rs.getString(CURRENT_PERFORMANCE_RATE)
					? rs.getBigDecimal(CURRENT_PERFORMANCE_RATE)
					: BigDecimal.ZERO;
			if (null != rs.getString(CURRENT_PERFORMANCE_PERCENTILE)) {
				vCurrentPerformacePercentile = exportFlag ? rs.getString(CURRENT_PERFORMANCE_PERCENTILE).concat("th")
						: rs.getString(CURRENT_PERFORMANCE_PERCENTILE);
			} else {
				vCurrentPerformacePercentile = DASHES;
			}

			vPctlBenchmark90 = rs.getBigDecimal(PCTL_BNCHMRK_90);

			vPctlBenchmark50 = rs.getBigDecimal(PCTL_BNCHMRK_50);
			vPctlBenchmark75 = rs.getBigDecimal(PCTL_BNCHMRK_75);

			if (COC_IP.equalsIgnoreCase(vMetricCode) || COC_PAER.equalsIgnoreCase(vMetricCode)
					|| COC_RX.equalsIgnoreCase(vMetricCode) || COC_EBC.equalsIgnoreCase(vMetricCode)) {
				v75PctImprovement = null != rs.getString(PCT_75_IMPROV)
						? rs.getBigDecimal(PCT_75_IMPROV).setScale(2, BigDecimal.ROUND_HALF_UP)
						: BigDecimal.ZERO;
				v50PctImprovement = null != rs.getString(PCT_50_IMPROV)
						? rs.getBigDecimal(PCT_50_IMPROV).setScale(2, BigDecimal.ROUND_HALF_UP)
						: BigDecimal.ZERO;

				v75PctImprovementPMPM = null != rs.getString(PCT_75_IMPROV_PMPM)
						? rs.getBigDecimal(PCT_75_IMPROV_PMPM).setScale(2, BigDecimal.ROUND_HALF_UP)
						: BigDecimal.ZERO;
				v50PctImprovementPMPM = null != rs.getString(PCT_50_IMPROV_PMPM)
						? rs.getBigDecimal(PCT_50_IMPROV_PMPM).setScale(2, BigDecimal.ROUND_HALF_UP)
						: BigDecimal.ZERO;
			}

			vActualBenchmarkRatio = null != rs.getString(ACTUAL_BENCHMARK_RATIO)
					? rs.getBigDecimal(ACTUAL_BENCHMARK_RATIO).setScale(2, BigDecimal.ROUND_HALF_UP)
					: BigDecimal.ZERO;
			vDataFormat = getDataFormat(vMetricCode);

			item.setMetricCode(vMetricCode);
			item.setMetricName(vMetricName);
			item.setCurrentPerformanceRate(getFormattedRates(vCurrentPerformaceRate, vMetricCode, exportFlag));
			item.setCurrentPerformancePercentile(vCurrentPerformacePercentile);

			item.setPercentileBenchmark90(getFormattedRates(vPctlBenchmark90, vMetricCode, exportFlag));

			item.setPercentileBenchmark50(getFormattedRates(vPctlBenchmark50, vMetricCode, exportFlag));
			item.setPercentileBenchmark75(getFormattedRates(vPctlBenchmark75, vMetricCode, exportFlag));

			if (!exportFlag) {
				item.setTotalOpportunity(vTotalOpportunity.toString());
				item.setTotalOpportunityPMPM(vTotalOpportunityPMPM.toString());
				item.setActualBenchmarkRatio(vActualBenchmarkRatio.toString());
				item.setDataFormat(vDataFormat);
				item.setFiftyPercentImprovement(v50PctImprovement.toString());
				item.setFiftyPercentImprovementPMPM(v50PctImprovementPMPM.toString());
				item.setSeventyFivePercentImprovement(v75PctImprovement.toString());
				item.setSeventyFivePercentImprovementPMPM(v75PctImprovementPMPM.toString());
			}

			else {
				item.setTotalOpportunity(StringUtil.convertStringToDecimalCurrency(
						vTotalOpportunity.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
				item.setTotalOpportunityPMPM(StringUtil.convertStringToDecimalCurrency(
						vTotalOpportunityPMPM.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
				item.setActualBenchmarkRatio(StringUtil.convertStringToCommaBigDecimal(
						vActualBenchmarkRatio.setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));
				item.setFiftyPercentImprovement(StringUtil.convertStringToDecimalCurrency(
						v50PctImprovement.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
				item.setFiftyPercentImprovementPMPM(StringUtil.convertStringToDecimalCurrency(
						v50PctImprovementPMPM.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
				item.setSeventyFivePercentImprovement(StringUtil.convertStringToDecimalCurrency(
						v75PctImprovement.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
				item.setSeventyFivePercentImprovementPMPM(StringUtil.convertStringToDecimalCurrency(
						v75PctImprovementPMPM.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));

			}
			if (null != rs.getString(LOB_DESC)) {
				if (rs.getString(LOB_DESC).equals(MEDICARE_ADVANTAGE)) {
					item.setLob(MEDICARE);
				} else {
					item.setLob(rs.getString(LOB_DESC));
				}
			}
			results.add(item);

		}
		return results;

	}

	/**
	 * Method to fetch Record for SOC Metric
	 * 
	 * @param request
	 * @param metricCode
	 * @param metricName
	 * @return
	 */
	private List<CostOpportunityBean> fetchRecordsForSOCMetric(GetCostOpportunitySummaryRequest request,
			String metricCode, String metricName, boolean exportFlag) {
		List<CostOpportunityBean> resultList = new ArrayList<CostOpportunityBean>();

		StringBuilder query = new StringBuilder().append(" select C.* from  ( ").append(" select A.*, ").append(
				" row_number() over (PARTITION BY A.metricCode ORDER BY ABS(A.currPerfRate - BNCHMRK_PCTAG_AMT) ASC, currentPerformancePercentile DESC) AS pctl_row_num ")
				.append(" from	( ").append(" SELECT   D.MTRC_CD as metricCode").append(" ,D.MTRC_NM    AS metricName ")
				.append(" ,SUM(D.TOTALOPPORTUNITYSOC) AS totalOpportunity ")
				.append(" ,SUM(D.NON_PREF_SITE_CLMS_CNT) as nonPrefSiteClmsCnt  ")
				.append(" ,SUM(D.TOTAL_CLAIM_COUNT) as totalClmsCnt , LOB_DESC  ")
				.append(" ,case when  MULTIPLEBENCHMARKINDICATOR = 'N' ").append(" then  max(D.BNCHMRK_PCTILE_90_NBR) ")
				.append(" else  0.00 end  AS percentileBenchmark90  ").append(" ,D.MULTIPLEBENCHMARKINDICATOR   ")
				.append(" ,case when  MULTIPLEBENCHMARKINDICATOR = 'N' ").append(" then  max(D.BNCHMRK_PCTILE_75_NBR) ")
				.append(" else  0.00 end  AS percentileBenchmark75  ")
				.append(" ,case when  MULTIPLEBENCHMARKINDICATOR = 'N' ").append(" then  max(D.BNCHMRK_PCTILE_50_NBR) ")
				.append(" else  0.00 end  AS percentileBenchmark50  ")
				.append(" ,cast(SUM(D.NON_PREF_SITE_CLMS_CNT) AS DECIMAL(18,4))*100/SUM(D.TOTAL_CLAIM_COUNT) currPerfRate ")
				.append(" ,case when  MULTIPLEBENCHMARKINDICATOR = 'N' ")
				.append(" then  BNCHMRK_PCTILE_NBR else  0 end as currentPerformancePercentile ")
				.append(" ,case when  MULTIPLEBENCHMARKINDICATOR = 'N' ").append(" then  max(D.BNCHMRK_PCTAG_AMT) ")
				.append(" else  0.00 end as BNCHMRK_PCTAG_AMT ").append(" FROM   (    ")
				.append(" SELECT   'SOC' AS MTRC_CD ,'Specialty Rx Site of Care' AS MTRC_NM, CBD.BNCHMRK_PCTILE_90_NBR AS BNCHMRK_PCTILE_90_NBR ")
				.append(" ,CBD.BNCHMRK_PCTILE_75_NBR AS BNCHMRK_PCTILE_75_NBR ")
				.append(" ,CBD.BNCHMRK_PCTILE_50_NBR AS BNCHMRK_PCTILE_50_NBR ").append(" , CASE  ")
				.append(" WHEN  SUM(NVL(COST_OPRTNTY_AMT,0))>0 ").append(" THEN  SUM(NVL(COST_OPRTNTY_AMT,0))  ")
				.append(" ELSE  0.00 END AS TOTALOPPORTUNITYSOC ").append(" , CASE  ")
				.append(" WHEN COUNT(*) OVER (PARTITION BY CBD.COC_MTRC_CD,CBD.BNCHMRK_PCTILE_NBR) <= 1  ")
				.append(" THEN   'N'   ").append(" ELSE   'Y'   END  AS MULTIPLEBENCHMARKINDICATOR ")
				.append(" ,SUM(SOCSMRY.TOTL_CLMS_NBR) as TOTAL_CLAIM_COUNT ")
				.append(" ,SUM(SOCSMRY.NON_PRFRD_SITE_CLMS_NBR) as NON_PREF_SITE_CLMS_CNT ")
				.append(" ,CBD.COC_MTRC_CD,CBD.BNCHMRK_PCTILE_NBR,CBD.BNCHMRK_PCTAG_AMT , LOB_DESC ")
				.append(" FROM   COC_SOC_PROV_DRUG_SMRY AS SOCSMRY    ")
				.append(" join  PGM_DIM PGM  ON SOCSMRY.PGM_DIM_KEY = PGM.PGM_DIM_KEY and  PGM.RCRD_STTS_CD = 'ACT' ")
				.append(" JOIN    (    ").append(" SELECT  DISTINCT ")
				.append("  max(case when BNCHMRK_PCTILE_NBR=90 THEN BNCHMRK_PCTAG_AMT ELSE NULL END) OVER (PARTITION BY COC_MTRC_CD,MRKT_ST_CD) AS BNCHMRK_PCTILE_90_NBR")
				.append(" ,max(case when BNCHMRK_PCTILE_NBR=75 THEN BNCHMRK_PCTAG_AMT ELSE NULL END) OVER (PARTITION BY COC_MTRC_CD,MRKT_ST_CD) AS BNCHMRK_PCTILE_75_NBR")
				.append(" ,max(case when BNCHMRK_PCTILE_NBR=50 THEN BNCHMRK_PCTAG_AMT ELSE NULL END) OVER (PARTITION BY COC_MTRC_CD,MRKT_ST_CD) AS BNCHMRK_PCTILE_50_NBR")
				.append(" ,COC_MTRC_CD, MRKT_ST_CD, BNCHMRK_PCTILE_NBR, BNCHMRK_PCTAG_AMT ")
				.append(" FROM  COC_BNCHMRK_DATA  ").append(" WHERE  COC_MTRC_CD =  'SOC' ")
				.append(" AND  SUB_MTRC_CD = 'SMRY'  ").append(" AND  RCRD_STTS_CD = 'ACT' ")
				.append(" AND  BNCHMRK_IND_CD = 'R' ").append(" ) AS CBD ON CBD.MRKT_ST_CD=SUBSTR(PGM.PGM_ID, 1, 2) ")
				.append(" JOIN    POIT_USER_SCRTY_ACS PUSA ON (SOCSMRY.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
				.append(" AND     ").append(" CASE   ").append(" WHEN      PUSA.PROV_ORG_TAX_ID = '0' ")
				.append(" THEN      SOCSMRY.PROV_ORG_TAX_ID   ")
				.append(" ELSE      PUSA.PROV_ORG_TAX_ID END = SOCSMRY.PROV_ORG_TAX_ID) ")
				.append(" WHERE    PUSA.SESN_ID = ? AND pusa.enttlmnt_hash_key = ?  ");

		if (!showAll && null != request.getAppPrptyList()) {
			setFiltersWithSuppression(query, request, metricCode, metricName, ALIAS_SOC_SMRY, BOOL_TRUE);
		} else {
			setFiltersWithoutSuppression(query, request, ALIAS_SOC_SMRY, BOOL_TRUE);
		}

		query.append(" GROUP BY  CBD.COC_MTRC_CD, CBD.BNCHMRK_PCTILE_90_NBR, CBD.BNCHMRK_PCTILE_75_NBR  ")
				.append(" ,CBD.BNCHMRK_PCTILE_50_NBR, CBD.BNCHMRK_PCTILE_NBR, CBD.BNCHMRK_PCTAG_AMT , LOB_DESC ) D ")
				.append(" group by MTRC_CD,MTRC_NM,MULTIPLEBENCHMARKINDICATOR, BNCHMRK_PCTILE_NBR , LOB_DESC ) A ")
				.append("  	) C where pctl_row_num=1  ");

		try {

			cn = Database.getConnection(Constants.SNOWFLAKE_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());
			buildPreparedStatement(request, metricCode, metricName, i);
			executeQuery(logger, query.toString());
			resultList = convertResultsetToBean(rs, request, exportFlag);
		} catch (Exception e) {
			resultList = null;
			logger.error("Error in fetchRecordsForSOCMetric", e);

		} finally {
			close();
		}

		return resultList;

	}

	/**
	 * Method to fetch record for individual Metric
	 * @param request
	 * @param metricCode
	 * @param metricName
	 * @param totalOpportunity
	 * @return
	 */
	private List<CostOpportunityBean> fetchRecordsForMetric(GetCostOpportunitySummaryRequest request, String metricCode, String metricName, BigDecimal totalOpportunity,
		boolean exportFlag) {
		List<CostOpportunityBean> resultList = new ArrayList<CostOpportunityBean>();

		StringBuilder query = new StringBuilder()
			.append(" SELECT C.* ")
			.append(" FROM (SELECT A.*, ")
			.append(" ROW_NUMBER() OVER (PARTITION BY A.metriccode , A.LOB_desc ");
			query.append("  ORDER BY Abs(A.currperfrate - bnchmrk_pctag_amt) asc ")
			.append(" ,currentPerformancePercentile desc) AS pctl_row_num ")
			.append("  FROM ( ")
			.append(" SELECT metricCode , lob_desc ");
			query.append("   ,metricName ")
			.append(" ,SUM(totalOpportunity) as totalOpportunity ")
			.append(" , SUM(totalOpportunity50) AS  fiftyPercentImprovement ")
			.append(" , SUM(totalOpportunity75) AS  seventyFivePercentImprovement ")
		    .append(" ,case WHEN MULTIPLEBENCHMARKINDICATOR = 'N' then max(percentileBenchmark90) else 0.00 end as percentileBenchmark90 ")
			.append(" ,case WHEN MULTIPLEBENCHMARKINDICATOR = 'N' then max(percentileBenchmark50) else 0.00 end as percentileBenchmark50 ")
			.append(" ,case WHEN MULTIPLEBENCHMARKINDICATOR = 'N' then max(percentileBenchmark75) else 0.00 end as percentileBenchmark75 ")
			.append(" ,SUM(PRFRMN_RT_NMRTR_NBR) AS PRFRMN_RT_NMRTR_NBR ")
			.append(" ,SUM(PRFRMN_RT_DNMNTR_NBR) AS PRFRMN_RT_DNMNTR_NBR ")
			.append(" ,MULTIPLEBENCHMARKINDICATOR AS MULTIPLEBENCHMARKINDICATOR ");
		if (null != metricCode && COC_PAER.equals(metricCode)) {			
			query.append(" ,CAST(Sum(prfrmn_rt_nmrtr_nbr) AS DECIMAL(18, 4)) * ").append(PERF_RATE_12K_FACTOR).append(" / Sum(prfrmn_rt_dnmntr_nbr) currPerfRate ");
		} else if (null != metricCode && COC_EBC.equals(metricCode)) {			
			query.append(" ,CAST(Sum(prfrmn_rt_nmrtr_nbr) AS DECIMAL(18, 4)) * ").append(PERF_RATE_1000_FACTOR).append(" / Sum(prfrmn_rt_dnmntr_nbr) currPerfRate ");
		} else if (null != metricCode && (COC_ASC.equals(metricCode) || COC_LAB.equals(metricCode) || COC_SPL.equals(metricCode))) {
			query.append(" ,CAST(Sum(prfrmn_rt_nmrtr_nbr) AS DECIMAL(18, 4)) * ").append(PERF_RATE_100_FACTOR).append(" / Sum(prfrmn_rt_dnmntr_nbr) currPerfRate ");
		} else {
			query.append(" ,CAST(Sum(prfrmn_rt_nmrtr_nbr) AS DECIMAL(18, 4)) / Sum(prfrmn_rt_dnmntr_nbr) currPerfRate ");
		}
		query.append(" ,case when  MULTIPLEBENCHMARKINDICATOR = 'N' then  BNCHMRK_PCTILE_NBR else  0 end as currentPerformancePercentile ")
			 .append(" ,case when  MULTIPLEBENCHMARKINDICATOR = 'N' then  max(BNCHMRK_PCTAG_AMT) else  0.00 end as BNCHMRK_PCTAG_AMT ");
		
		//from clause starts here
		query.append(" FROM ( ")
			.append(" SELECT SMRY.MTRC_CD as metricCode, SMRY.MTRC_NM as metricName ");
			if(null != metricCode && COC_PAER.equals(metricCode)) {
			query.append(" , CASE WHEN TCA.COST_OPRTNTY_AMT < 0 THEN  0 ELSE  TCA.COST_OPRTNTY_AMT END  AS totalOpportunity  ");
			} else {
			query.append(" ,SUM( CASE WHEN SMRY.COST_OPRTNTY_AMT < 0 THEN  0 ELSE  SMRY.COST_OPRTNTY_AMT END ) AS totalOpportunity  ");	
			}
			query.append(" ,SUM( CASE WHEN SMRY.COST_OPRTNTY_50_AMT < 0 THEN  0 ELSE  SMRY.COST_OPRTNTY_50_AMT END ) AS totalOpportunity50  ")
			.append(" ,SUM( CASE WHEN SMRY.COST_OPRTNTY_75_AMT < 0 THEN  0 ELSE  SMRY.COST_OPRTNTY_75_AMT END ) AS totalOpportunity75  ")
			.append(" ,SMRY.BNCHMRK_90_PCTILE_AMT AS percentileBenchmark90  ")
			.append(" ,SMRY.BNCHMRK_50_PCTILE_AMT AS percentileBenchmark50  ")
			.append(" ,SMRY.BNCHMRK_75_PCTILE_AMT AS percentileBenchmark75  ")
			.append(" ,SUM(SMRY.PRFRMN_RT_NMRTR_NBR) AS PRFRMN_RT_NMRTR_NBR  ")
			.append(" ,SUM(SMRY.PRFRMN_RT_DNMNTR_NBR) AS PRFRMN_RT_DNMNTR_NBR  ")
			.append(" ,CASE WHEN COUNT(*) OVER (PARTITION BY smry.LOB_DESC , " );
           query.append("  SMRY.MTRC_CD, CBD.BNCHMRK_PCTILE_NBR) <= 1 THEN 'N' ")
			.append(" ELSE 'Y' END AS MULTIPLEBENCHMARKINDICATOR ")
			.append(" ,CBD. BNCHMRK_PCTILE_NBR, CBD.BNCHMRK_PCTAG_AMT   ,  smry.LOB_DESC  ")	;
			query.append(" FROM  COC_OPRTNTY_SMRY SMRY 	")
			.append(" join PGM_DIM PGM ON SMRY.PGM_DIM_KEY = PGM.PGM_DIM_KEY and PGM.RCRD_STTS_CD = 'ACT' ");
		if(COC_EBC.equals(metricCode)) {
			query.append(" JOIN (SELECT CBD_I.mrkt_st_cd, CBD_I.prov_grp_id, CBD_I.bnchmrk_pctile_nbr ")
				 .append(" ,Coalesce(Round((CAST(Sum(CBD_I.srvc_cnt * CBD_I.bnchmrk_pctag_amt) AS DECIMAL(18, 4)) / Nullif(CAST(Max(totl_member) AS DECIMAL(18, 4) ) , 0) ), 2), 0.00) AS BNCHMRK_PCTAG_AMT ")
				 .append(" FROM (SELECT  CBD.mrkt_st_cd,	SMRY.prov_grp_id, CBD.sub_mtrc_cd, CBD.bnchmrk_pctile_nbr ")
				 .append(" ,Max(CBD.bnchmrk_pctag_amt) BNCHMRK_PCTAG_AMT, CAST(Sum(SMRY.mbr_elgbl_slct_srvc_cnt) AS DECIMAL(18, 2)) AS SRVC_CNT ")
				 .append(" FROM coc_bnchmrk_data CBD JOIN pgm_dim PGM ON CBD.mrkt_st_cd = Substr(pgm_id, 1, 2) AND PGM.rcrd_stts_cd = 'ACT' ")
				 .append(" JOIN coc_ebc_ctgry_smry SMRY ON CBD.sub_mtrc_cd = SMRY.sub_mtrc_cd AND PGM.pgm_dim_key = SMRY.pgm_dim_key ")
				 .append(" where CBD.COC_MTRC_CD =  '").append(metricCode).append("'AND CBD.rcrd_stts_cd = 'ACT' ");
			if (!showAll && null != request.getAppPrptyList()) {
				setFiltersWithSuppression(query, request, metricCode, metricName, ALIAS_COC_SMRY, BOOL_FALSE);
			}
			else {
				setFiltersWithoutSuppression(query, request, ALIAS_COC_SMRY, BOOL_FALSE);
			}
			query.append(" GROUP BY CBD.mrkt_st_cd, SMRY.prov_grp_id, CBD.sub_mtrc_cd, CBD.bnchmrk_pctile_nbr) CBD_I ")
				.append(" JOIN ( SELECT Substr(PSF.pgm_id, 1, 2) AS MRKT_ST_CD, PSF.prov_grp_id, COUNT(DISTINCT PSF.mstr_cnsmr_dim_key) AS TOTL_MEMBER ")
				.append(" FROM pat_smry_fact PSF WHERE  PSF.atrbn_stts_cd = 'ACTIVE' ");
				if (!showAll && null != request.getAppPrptyList()) {
					setFiltersWithSuppression(query, request, metricCode, metricName, "PSF", BOOL_FALSE);
				}
				else {
					setFiltersWithoutSuppression(query, request, ALIAS_PAT_SMRY_FACT, BOOL_FALSE);
				}
			query.append(" GROUP BY Substr(PSF.pgm_id, 1, 2), PSF.prov_grp_id) PSF ")
				.append(" ON CBD_I.mrkt_st_cd = PSF.mrkt_st_cd AND PSF.prov_grp_id = CBD_I.prov_grp_id ")
				.append(" GROUP  BY CBD_I.mrkt_st_cd, CBD_I.prov_grp_id, bnchmrk_pctile_nbr) CBD ")
				.append(" ON CBD.mrkt_st_cd = Substr(PGM.pgm_id, 1, 2) AND CBD.prov_grp_id = SMRY.prov_grp_id ");
		} else if( COC_LAB.equals(metricCode)) {
			query.append(" join (select MRKT_ST_CD, BNCHMRK_PCTILE_NBR, Max(bnchmrk_pctag_amt) AS BNCHMRK_PCTAG_AMT ");		
			query.append(" from COC_BNCHMRK_DATA ");
			query.append(" where COC_MTRC_CD =  '").append(metricCode).append("' and RCRD_STTS_CD = 'ACT' AND sub_mtrc_cd = 'SMRY' "); 
			query.append(" group by MRKT_ST_CD, BNCHMRK_PCTILE_NBR) CBD ON CBD.MRKT_ST_CD = Substr(PGM.pgm_id, 1, 2) ");
		} else {
			query.append(" JOIN (SELECT mrkt_st_cd, prov_grp_id, bnchmrk_pctile_nbr , lob_desc  ");   

			if(COC_SPL.equals(metricCode)) {
				query.append(" ,COALESCE(ROUND((CAST(SUM(EPSD_CNT * BNCHMRK_PCTAG_AMT) AS DECIMAL(18, 4)) / NULLIF(CAST(SUM(EPSD_CNT) AS DECIMAL(18,4)),0)),2),0.00) AS BNCHMRK_PCTAG_AMT ")
					.append(" FROM ( select  SMRY.LOB_DESC, CBD.MRKT_ST_CD, SMRY.PROV_GRP_ID, CBD.SUB_MTRC_CD, CBD.BNCHMRK_PCTILE_NBR ")
					.append(" ,MAX(CBD.BNCHMRK_PCTAG_AMT) BNCHMRK_PCTAG_AMT, CAST(SUM(SMRY.EPSD_CNT) AS DECIMAL(18,2)) AS EPSD_CNT ")
					.append(" from COC_BNCHMRK_DATA CBD ")
					.append(" join PGM_DIM PGM ON CBD.MRKT_ST_CD = SUBSTR(PGM.PGM_ID, 1, 2) and PGM.RCRD_STTS_CD = 'ACT' ")
					.append(" join COC_SPCLTY_CTGRY_SMRY SMRY ON CBD.SUB_MTRC_CD=SMRY.SUB_MTRC_CD ");	
			} else if(COC_RX.equals(metricCode)) {
				query.append(" ,COALESCE(ROUND((CAST(SUM(RX_CNT * BNCHMRK_PCTAG_AMT) AS DECIMAL(18, 4)) / NULLIF(CAST(SUM(RX_CNT) AS DECIMAL(18,4)),0)),2),0.00) AS BNCHMRK_PCTAG_AMT ")
				.append(" FROM ( select  SMRY.LOB_DESC,CBD.MRKT_ST_CD, SMRY.PROV_GRP_ID, CBD.SUB_MTRC_CD, CBD.BNCHMRK_PCTILE_NBR ")
				.append(" ,MAX(CBD.BNCHMRK_PCTAG_AMT) BNCHMRK_PCTAG_AMT, CAST(SUM(SMRY.TOTL_SCRPT_NBR) AS DECIMAL(18,2)) AS RX_CNT ")
				.append(" from COC_BNCHMRK_DATA CBD ")
				.append(" join PGM_DIM PGM ON CBD.MRKT_ST_CD = SUBSTR(PGM.PGM_ID, 1, 2) and PGM.RCRD_STTS_CD = 'ACT' ")
				.append(" join COC_RX_CTGRY_SMRY SMRY ON CBD.SUB_MTRC_CD=SMRY.SUB_MTRC_CD ");	
			} else if(COC_PAER.equals(metricCode)) {
				query.append(" , COALESCE(ROUND((CAST(SUM(MBR_MNTH_CNT * BNCHMRK_PCTAG_AMT) AS DECIMAL(18, 4)) / NULLIF(CAST(SUM(MBR_MNTH_CNT) AS DECIMAL(18,4)),0)),2),0.00) AS BNCHMRK_PCTAG_AMT ")
				.append(" FROM ( select  SMRY.LOB_DESC,CBD.MRKT_ST_CD, SMRY.PROV_GRP_ID, CBD.SUB_MTRC_CD, CBD.BNCHMRK_PCTILE_NBR ")
				.append(" ,MAX(CBD.BNCHMRK_PCTAG_AMT) BNCHMRK_PCTAG_AMT, CAST(SUM(SMRY.MBR_MNTH_CNT) AS DECIMAL(18,2)) AS MBR_MNTH_CNT ")
				.append(" from COC_BNCHMRK_DATA CBD ")
				.append(" join PGM_DIM PGM ON CBD.MRKT_ST_CD = SUBSTR(PGM.PGM_ID, 1, 2) and PGM.RCRD_STTS_CD = 'ACT' ")
				.append(" join COC_LIER_CTGRY_SMRY SMRY ON CBD.SUB_MTRC_CD=SMRY.SUB_MTRC_CD ");
			} else if(COC_ASC.equals(metricCode)) {
				query.append(" ,COALESCE(ROUND((CAST(SUM(SRGRY_CNT * BNCHMRK_PCTAG_AMT) AS DECIMAL(18, 4)) / NULLIF(CAST(SUM(SRGRY_CNT) AS DECIMAL(18,4)),0)),2),0.00) AS BNCHMRK_PCTAG_AMT ")
				.append(" FROM ( select  SMRY.LOB_DESC, CBD.MRKT_ST_CD, SMRY.PROV_GRP_ID, CBD.SUB_MTRC_CD, CBD.BNCHMRK_PCTILE_NBR ")
				.append(" ,MAX(CBD.BNCHMRK_PCTAG_AMT) BNCHMRK_PCTAG_AMT, CAST(SUM(SMRY.SRGRY_CNT) AS DECIMAL(18,2)) AS SRGRY_CNT ")
				.append(" from COC_BNCHMRK_DATA CBD ")
				.append(" join PGM_DIM PGM ON CBD.MRKT_ST_CD = SUBSTR(PGM.PGM_ID, 1, 2) and PGM.RCRD_STTS_CD = 'ACT' ")
				.append(" join COC_ASC_CTGRY_SMRY SMRY ON CBD.SUB_MTRC_CD=SMRY.SUB_MTRC_CD ");		
			}	

			query.append(" and CBD.BNCHMRK_IND_CD=SMRY.BNCHMRK_CD and PGM.PGM_DIM_KEY = SMRY.PGM_DIM_KEY ");
			if(COC_PAER.equals(metricCode)) {
		   query.append(" and   CBD.lob_desc  =  ")
			    .append(" case   ")
         		.append(" when  SMRY.lob_desc='UniCare'  ") 
	                 .append(" then  'Commercial'     ")
	                 .append(" when  SMRY.lob_desc='Medicare-Medicaid Plan'  ")
	                 .append(" then  'Medicare Advantage' else  SMRY.lob_desc END  ")
				.append(" JOIN POIT_USER_SCRTY_ACS AS PUSA ON ( ")
				.append(" SMRY.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
				.append(" AND CASE ")
				.append(" WHEN  PUSA.PROV_ORG_TAX_ID = '0' THEN  SMRY.PROV_ORG_TAX_ID ")
				.append(" ELSE  PUSA.PROV_ORG_TAX_ID ")
				.append(" END = SMRY.PROV_ORG_TAX_ID ")
				.append("	) ")
		   .append(" where     pusa.sesn_id = ?   ")
			.append(" and  pusa.enttlmnt_hash_key = ?   ")
			.append(" and COC_MTRC_CD =  '").append(metricCode);
		   
				}
			if(!COC_PAER.equals(metricCode)) {
			query.append(" where COC_MTRC_CD =  '").append(metricCode);
			}
		
			query.append("' and CBD.RCRD_STTS_CD = 'ACT'  "); 
			if (!showAll && null != request.getAppPrptyList()) {
				setFiltersWithSuppression(query, request, metricCode, metricName, ALIAS_COC_SMRY, BOOL_FALSE);
			}
			else {
				setFiltersWithoutSuppression(query, request, ALIAS_COC_SMRY, BOOL_FALSE);
			}
			query.append(" group by CBD.MRKT_ST_CD, CBD.SUB_MTRC_CD, CBD.BNCHMRK_PCTILE_NBR ");
			query.append(" ,SMRY.PROV_GRP_ID ,  SMRY.LOB_DESC  ")	
				.append("  ) ")
				.append(" group by   MRKT_ST_CD,PROV_GRP_ID,BNCHMRK_PCTILE_NBR  , lob_desc  " );
			query.append(" ) CBD ")
				.append(" ON CBD.MRKT_ST_CD=SUBSTR(PGM.PGM_ID, 1, 2) ")
				.append(" AND CBD.PROV_GRP_ID=SMRY.PROV_GRP_ID ");
		}			
         if(COC_PAER.equals(metricCode)) {
        	 query.append(" and   CBD.lob_desc  =  ")
			    .append(" case   ")
      		.append(" when  SMRY.lob_desc='UniCare'  ") 
	                 .append(" then  'Commercial'     ")
	                 .append(" when  SMRY.lob_desc='Medicare-Medicaid Plan'  ")
	                 .append(" then  'Medicare Advantage' else  SMRY.lob_desc END  ");
         }
		if(!COC_PAER.equals(metricCode)) {
		query.append(" JOIN POIT_USER_SCRTY_ACS AS PUSA ON ( ")
			.append(" SMRY.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
			.append(" AND CASE ")
			.append(" WHEN  PUSA.PROV_ORG_TAX_ID = '0' THEN  SMRY.PROV_ORG_TAX_ID ")
			.append(" ELSE  PUSA.PROV_ORG_TAX_ID ")
			.append(" END = SMRY.PROV_ORG_TAX_ID ")
			.append("	) ");
		}
		if(null != metricCode && COC_PAER.equals(metricCode)) {
			query.append("  left join    ")
			.append("   (select   lob_desc, SUM(  ")
			.append(" case   ")
			.append(" 			when  SMRY.COST_OPRTNTY_AMT < 0  ")
			.append(" 			then   0  ")
			.append(" 			else   SMRY.COST_OPRTNTY_AMT    ")
			.append("    END) as COST_OPRTNTY_AMT  ")
			.append(" from (  ")
			.append(" select   s.lob_desc, s.SUB_MTRC_CD,  s.SUB_MTRC_NM,s.RULE_ID,s.bnchmrk_cd,MRKT_ST_CD,PGM_MRKT_CNT,  ")
			 
			.append("   case    ")
			.append(" 		when  (s.SUB_MTRC_CD ='A'  ")
			.append(" 	and  ILV.MEM_MNTH_ADLT < ( ")
			.append(" select  distinct APLCTN_PRPTY_VAL_TXT  ")
			.append(" from  APLCTN_PRPTY  ")
			.append(" where  APLCTN_PRPTY_NM = 'COC_PAER_MIN_TOTL_SCRPT'  ")
			.append(" 	and  APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG'))  or (s.SUB_MTRC_CD ='P'  ")
			.append(" 	and  ILV.MEM_MNTH_PED < ( ")
			.append(" select  distinct APLCTN_PRPTY_VAL_TXT  ")
			.append(" from  APLCTN_PRPTY  ")
			.append(" where  APLCTN_PRPTY_NM = 'COC_PAER_MIN_TOTL_SCRPT'  ")
			.append(" 	and  APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG'))   ")
			.append(" 		then  -1.00  ")
			.append("   else  (    ")
			.append(" case     ")
			.append(" 		when  s.SUB_MTRC_CD ='A'  ")
			.append(" 	and  ILV.MEM_MNTH_ADLT > 0  ")
			.append(" 		then   (cast(sum(LIER_VST_CNT) as decimal (18,4)) / cast(ILV.MEM_MNTH_ADLT as decimal (18,4)) * 12000)     ")
			.append(" 		when  s.SUB_MTRC_CD ='P'  ")
			.append(" 	and  ILV.MEM_MNTH_PED > 0  ")
			.append(" 		then   (cast(sum(LIER_VST_CNT) as decimal (18,4)) / cast(ILV.MEM_MNTH_PED as decimal (18,4)) * 12000)     ")
			.append(" 		else  0.00 end )   end as CURRENT_PERF_RATE,  ")
			.append(" case     ")
			.append(" 		when  (s.SUB_MTRC_CD ='A'  ")
			.append(" 	and  ILV.MEM_MNTH_ADLT < ( ")
			.append(" select  distinct APLCTN_PRPTY_VAL_TXT  ")
			.append(" from  APLCTN_PRPTY  ")
			.append(" where  APLCTN_PRPTY_NM = 'COC_PAER_MIN_TOTL_SCRPT'  ")
			.append(" 	and  APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG'))  or (s.SUB_MTRC_CD ='P'  ")
			.append(" 	and  ILV.MEM_MNTH_PED < ( ")
			.append(" select  distinct APLCTN_PRPTY_VAL_TXT  ")
			.append(" from  APLCTN_PRPTY  ")
			.append(" where  APLCTN_PRPTY_NM = 'COC_PAER_MIN_TOTL_SCRPT'  ")
			.append(" 	and  APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG'))   ")
			.append(" 		then  -1.00 ")
			.append("         when s.SUB_MTRC_CD ='A' and (cast(sum(LIER_VST_CNT) as decimal (18,4)) / cast(ILV.MEM_MNTH_ADLT as decimal (18,4)) * 12000) < max(s.BNCHMRK_90_PCTILE_AMT) then 0.00 ")
			.append("         when s.SUB_MTRC_CD ='P' and (cast(sum(LIER_VST_CNT) as decimal (18,4)) / cast(ILV.MEM_MNTH_PED as decimal (18,4)) * 12000)  < max(s.BNCHMRK_90_PCTILE_AMT) then 0.00   ")
			.append("   else case ")
			.append(" 		when  sum(s.COST_OPRTNTY_AMT) >=0  ")
			.append(" 		then  cast(sum(s.COST_OPRTNTY_AMT) as Decimal(18,4))  ")
			.append(" 		else  0.00 end end as COST_OPRTNTY_AMT, ")
			.append("   case    ")
			.append(" 		when  (s.SUB_MTRC_CD ='A'  ")
			.append(" 	and  ILV.MEM_MNTH_ADLT < ( ")
			.append(" select  distinct APLCTN_PRPTY_VAL_TXT  ")
			.append(" from  APLCTN_PRPTY  ")
			.append(" where  APLCTN_PRPTY_NM = 'COC_PAER_MIN_TOTL_SCRPT'  ")
			.append(" 	and  APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG'))  or (s.SUB_MTRC_CD ='P'  ")
			.append(" 	and  ILV.MEM_MNTH_PED < ( ")
			.append(" select  distinct APLCTN_PRPTY_VAL_TXT  ")
			.append(" from  APLCTN_PRPTY  ")
			.append(" where  APLCTN_PRPTY_NM = 'COC_PAER_MIN_TOTL_SCRPT'  ")
			.append(" 	and  APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG'))   ")
			.append(" 		then  -1.00   ")
			.append(" 		else  max(s.BNCHMRK_90_PCTILE_AMT) end as BNCHMRK_90_PCTILE_AMT,   ")
			.append("    count(*) over () as row_cnt   ")
			.append(" from   coc_lier_ctgry_smry s   ")
			.append(" join (   ")
			.append(" select  ls.lob_desc,  NVL(SUM( ")
			.append(" case   ")
			.append(" 		when  LS.SUB_MTRC_CD='A'  ")
			.append(" 		then  LS.MBR_MNTH_CNT  ")
			.append(" 		else  0 END),  0) AS MEM_MNTH_ADLT,  NVL( SUM( ")
			.append(" case   ")
			.append(" 		when  LS.SUB_MTRC_CD='P'  ")
			.append(" 		then  LS.MBR_MNTH_CNT  ")
			.append(" 		else  0 END),  0) AS MEM_MNTH_PED,  NVL( SUM(LS.MBR_MNTH_CNT), 0) AS MEM_MNTH_TOTL  ")
			.append(" from  COC_LIER_CTGRY_SMRY LS  ")
			.append(" join  poit_user_scrty_acs pusa on (  LS.prov_grp_id = pusa.prov_grp_id   ")
			.append(" 	and    ")
			.append(" case    ")
			.append(" 		when   pusa.prov_org_tax_id = '0'  ")
			.append(" 		then   LS.prov_org_tax_id   ")
			.append(" 		else   pusa.prov_org_tax_id  end = LS.prov_org_tax_id  )   ")
			.append(" where     pusa.sesn_id = ?   ")
			.append(" and  pusa.enttlmnt_hash_key = ?   ");
			if (!showAll && null != request.getAppPrptyList()) {
				setFiltersWithSuppression(query, request, metricCode, metricName,LS, BOOL_TRUE);
			}
			else {
				setFiltersWithoutSuppression(query, request,LS, BOOL_TRUE);
			}
	   query.append(" group by ls.lob_desc) as ilv  on  s.lob_desc = ilv.lob_desc  ")
			.append(" join    ( Select distinct  LOB_DESC, sum(MEM_MNTH_PMPM_TOTL) over() as MEM_MNTH_PMPM_TOTL, max(pgm_mrkt_cnt) over() as pgm_mrkt_cnt,   ")
			.append(" case   ")
			.append(" 		when  max(pgm_mrkt_cnt) over() =1  ")
			.append(" 		then  substr(pgm_id,1,2)  ")
			.append(" 		else  substr(prov_grp_id,1,2) end as MRKT_ST_CD  ")
			.append(" from  (   ")
			.append(" select  psf.LOB_DESC , psf.prov_grp_id, psf.pgm_id, NVL( SUM(MM.MBR_MNTH_12_CNT), 0) AS MEM_MNTH_PMPM_TOTL, DENSE_RANK() OVER(ORDER  BY (substr(pgm_id,1,2)))  as pgm_mrkt_cnt   ")
			.append(" from     PAT_SMRY_FACT PSF      ")
			.append(" 	inner join   MSTR_CNSMR_DIM MCD   ON  MCD.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY ")
			.append(" and   MCD.RCRD_STTS_CD = 'ACT'  ")
			.append(" inner join       MSTR_CNSMR_MBR_MNTH_FACT MM ON  MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY    ")
			.append(" 	and    MM.RCRD_STTS_CD = 'ACT'  ")
			
			.append(" 	and  PSF.ATRBN_STTS_CD = 'ACTIVE'  ") ;  
	   query.append(" join  poit_user_scrty_acs pusa on ( PSF.prov_grp_id = pusa.prov_grp_id  ")
		.append(" 	and   ")
		.append(" case   ")
		.append(" 		when  pusa.prov_org_tax_id = '0'  ")
		.append(" 		then  PSF.prov_org_tax_id  ")
		.append(" 		else  pusa.prov_org_tax_id end = PSF.prov_org_tax_id )   ")
	   .append(" where     pusa.sesn_id = ?   ")
		.append(" and  pusa.enttlmnt_hash_key = ?   ");
			if (!showAll && null != request.getAppPrptyList()) {
				setFiltersWithSuppression(query, request, metricCode, metricName,ALIAS_PAT_SMRY_FACT, BOOL_TRUE);
			}
			else {
				setFiltersWithoutSuppression(query, request,ALIAS_PAT_SMRY_FACT, BOOL_TRUE);
			}
			query.append(" group by  psf.prov_grp_id, psf.pgm_id , PSF.LOB_DESC )) as ILV1 on ILV1.LOB_DESC =  s.lob_desc ")
			.append(" join  poit_user_scrty_acs pusa on (  s.prov_grp_id = pusa.prov_grp_id   ")
			.append(" 	and    ")
			.append(" case    ")
			.append(" 		when   pusa.prov_org_tax_id = '0'  ")
			.append(" 		then   s.prov_org_tax_id   ")
			.append(" 		else   pusa.prov_org_tax_id  end = s.prov_org_tax_id  )   ")
			.append(" where     pusa.sesn_id = ?   ")
			.append(" and  pusa.enttlmnt_hash_key = ?   ");
			if (!showAll && null != request.getAppPrptyList()) {
				setFiltersWithSuppression(query, request, metricCode, metricName,s, BOOL_TRUE);
			}
			else {
				setFiltersWithoutSuppression(query, request,s, BOOL_TRUE);
			}
			query.append(" group by    s.lob_desc,s.SUB_MTRC_CD, s.SUB_MTRC_NM ,ILV.MEM_MNTH_ADLT ,ILV.MEM_MNTH_PED, ILV.MEM_MNTH_TOTL, ILV1.MEM_MNTH_PMPM_TOTL,s.RULE_ID,s.bnchmrk_cd,PGM_MRKT_CNT, MRKT_ST_CD )SMRY  group by smry.lob_desc) TCA on CBD.LOB_DESC=TCA.LOB_DESC ");
			query.append(" JOIN POIT_USER_SCRTY_ACS AS PUSA ON ( ")
			.append(" SMRY.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
			.append(" AND CASE ")
			.append(" WHEN  PUSA.PROV_ORG_TAX_ID = '0' THEN  SMRY.PROV_ORG_TAX_ID ")
			.append(" ELSE  PUSA.PROV_ORG_TAX_ID ")
			.append(" END = SMRY.PROV_ORG_TAX_ID ")
			.append("	) ");
		}
		
			
		query.append(" WHERE   PUSA.SESN_ID = ? ")
			.append(" and   PUSA.ENTTLMNT_HASH_KEY  = ? ")
			.append(" AND SMRY.MTRC_CD = '").append(metricCode).append("' ");
	
		if (!showAll && null != request.getAppPrptyList()) {
			setFiltersWithSuppression(query, request, metricCode, metricName, ALIAS_COC_SMRY, BOOL_TRUE);
		}
		else {
			setFiltersWithoutSuppression(query, request, ALIAS_COC_SMRY, BOOL_TRUE);
		}
		query.append(" GROUP BY SMRY.MTRC_CD  ,SMRY.MTRC_NM, ");
		if(null != metricCode && COC_PAER.equals(metricCode)) {
		query.append(" TCA.COST_OPRTNTY_AMT, ");
			}
		query.append(" SMRY.BNCHMRK_90_PCTILE_AMT, SMRY.BNCHMRK_50_PCTILE_AMT ");		
		query.append(" , SMRY.BNCHMRK_75_PCTILE_AMT, CBD.BNCHMRK_PCTILE_NBR,CBD.BNCHMRK_PCTAG_AMT , SMRY.LOB_DESC ) ");
		query.append(" GROUP BY   metricCode, metricName, MULTIPLEBENCHMARKINDICATOR ,BNCHMRK_PCTILE_NBR , lob_desc ");	
		query.append("  ) A  ")		
		.append(" ) C ")
		.append(" WHERE pctl_row_num=1 ");
			
		try {

			cn = Database.getConnection(Constants.SNOWFLAKE_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());
			buildPreparedStatement(request, metricCode, metricName, i);
			executeQuery(logger, query.toString());
			resultList = convertResultsetToBean(rs, request, exportFlag);
		}
		catch (Exception e) {
			resultList = null;
			logger.error("Error in fetchRecordsForMetric", e);

		}
		finally {
			close();
		}


		return resultList;
	}

	/**
	 * Method to Sort the data based on user request (uses comparator chains)
	 * 
	 * @param resultList
	 * @param sortingList
	 */
	private void sortResultListByUserRequest(List<CostOpportunityBean> resultList, List<QuerySort> sortingList) {
		COCSmryChainedComparator comparatorList = new COCSmryChainedComparator(
				new COCSmryTotlOpportunityComparator(SORT_DESC));

		if (null != sortingList) {
			for (QuerySort sortItem : sortingList) {
				String dir = sortItem.getDirection().replaceAll("\"", "");
				String property = sortItem.getProperty();

				if (null != property && METRIC_NM.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmryMtrcNmComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && COST_OPPORTUNITY.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmryTotlOpportunityComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && PCT_75_IMPROV.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmry75PctImprovComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && PCT_50_IMPROV.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmry50PctImprovComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && COST_OPPORTUNITY_PMPM.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmryTotlOpportunityPMPMComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && PCT_75_IMPROV_PMPM.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmry75PctPMPMImprovComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && PCT_50_IMPROV_PMPM.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmry50PctPMPMImprovComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && PCTL_BNCHMRK_75.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmry75PctBenchmarkComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && PCTL_BNCHMRK_50.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmry50PctBenchmarkComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && ACTUAL_BNCHMRK_RATIO.equals(property))
					comparatorList = new COCSmryChainedComparator(new COCSmryABRatioComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
				else if (null != property && CURRENT_PERFORMANCE_PERCENTILE.equals(property))
					comparatorList = new COCSmryChainedComparator(
							new COCSmryCurrentPerformancePercentileComparator(dir),
							new COCSmryTotlOpportunityComparator(SORT_DESC));
			}
		}
		Collections.sort(resultList, comparatorList);
	}

	/**
	 * Method to mask & filter unwanted records
	 * 
	 * @param resultList
	 * @param metricCode
	 * @param request
	 */
	private void maskAndFilterRecordsforMetric(List<CostOpportunityBean> resultList,
			GetCostOpportunitySummaryRequest request, boolean exportFlag) {
		for (CostOpportunityBean costOppBean : resultList) {
			applyMinimumCriteria(costOppBean);
			applySOCNonPrefCheck(costOppBean, request);
			applyBenhmarkPerformanceCheck(costOppBean, exportFlag);

		}
	}

	/**
	 * Method to apply filters on the basis of Benchmark & current performance Rate
	 * 
	 * @param costOppBean
	 * @param exportFlag
	 */
	private void applyBenhmarkPerformanceCheck(CostOpportunityBean costOppBean, boolean exportFlag) {
		// Check-1 : Multiple BenchMark Indicator
		if (null != costOppBean && null != costOppBean.getMultipleBenchMarkIndicator()
				&& Y.equals(costOppBean.getMultipleBenchMarkIndicator())) {
			costOppBean.setPercentileBenchmark90(DASHES);
			costOppBean.setPercentileBenchmark50(DASHES);
			costOppBean.setPercentileBenchmark75(DASHES);
			costOppBean.setCurrentPerformancePercentile(DASHES);
			costOppBean.setActualBenchmarkRatio(DASHES);
		} else if (null != costOppBean && null != costOppBean.getCurrentPerformanceRate()
				&& null != costOppBean.getPercentileBenchmark90()) {
			// Check-2 : 90th Percentile Benchmark or Current Performance Rate is not
			// defined
			if (DASHES.equals(costOppBean.getCurrentPerformanceRate())
					|| DASHES.equals(costOppBean.getPercentileBenchmark90())) {
				costOppBean.setActualBenchmarkRatio(DASHES);
			}
		}
	}

	/**
	 * Method to apply non-preferred site claim condition for SOC metric
	 * 
	 * @param costOppBean
	 * @param request
	 */
	private void applySOCNonPrefCheck(CostOpportunityBean costOppBean, GetCostOpportunitySummaryRequest request) {
		if (null != costOppBean.getMetricCode() && COC_SOC.equals(costOppBean.getMetricCode())) {
			if (cq.displayDashesBasedOnNonPrefClmCriteria(request)) {
				costOppBean.setTotalOpportunity(DASHES);
				costOppBean.setTotalOpportunityPMPM(DASHES);
			}
		}

	}

	/**
	 * Method to apply minimum criteria check
	 * 
	 * @param costOppBean
	 */
	private void applyMinimumCriteria(CostOpportunityBean costOppBean) {
		boolean isMinCriteriaNotMeet = vMinimumCriteriaMap.get(costOppBean.getMetricCode());
		if (isMinCriteriaNotMeet) {
			costOppBean.setActualBenchmarkRatio(DASHES);
			costOppBean.setCurrentPerformanceRate(DASHES);
			costOppBean.setPercentileBenchmark90(DASHES);
			costOppBean.setTotalOpportunity(DASHES);
			costOppBean.setTotalOpportunityPMPM(DASHES);
			costOppBean.setFiftyPercentImprovement(DASHES);
			costOppBean.setFiftyPercentImprovementPMPM(DASHES);
			costOppBean.setSeventyFivePercentImprovement(DASHES);
			costOppBean.setSeventyFivePercentImprovementPMPM(DASHES);
			costOppBean.setPercentileBenchmark50(DASHES);
			costOppBean.setPercentileBenchmark75(DASHES);
			costOppBean.setCurrentPerformancePercentile(DASHES);

		}

	}

	/**
	 * Parent Method to build prepared statement
	 * 
	 * @param request
	 * @param metricName
	 * @param i
	 * @throws SQLException
	 */
	private void buildPreparedStatement(GetCostOpportunitySummaryRequest request, String metricCode, int i)
			throws SQLException {
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (!showAll && null != request.getAppPrptyList()) {
			buildPreparedStatementWithSuppression(request, metricCode, i);
		} else {
			buildPreparedStatementWithOutSuppression(request, metricCode, i);
		}

	}

	/**
	 * Parent Method to build prepared statement
	 * 
	 * @param request
	 * @param metricName
	 * @param i
	 * @return i
	 * @throws SQLException
	 */
	private int buildPreparedStatementPassCount(GetCostOpportunitySummaryRequest request, String metricCode, int i)
			throws SQLException {
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (!showAll && null != request.getAppPrptyList()) {
			i = buildPreparedStatementWithSuppressionPassCount(request, metricCode, i);
		} else {
			i = buildPreparedStatementWithOutSuppressionPassCount(request, metricCode, i);
		}
		return i;
	}

	/**
	 * overloaded method to set metric specific parameters
	 * 
	 * @param request
	 * @param metricCode
	 * @param metricName
	 * @param i
	 * @throws SQLException
	 */
	private void buildPreparedStatement(GetCostOpportunitySummaryRequest request, String metricCode, String metricName,
			int i) throws SQLException {

		String[] array = null;

		/*
		 * if (null != metricCode && (COC_PAER.equalsIgnoreCase(metricCode))) {
		 * 
		 * if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(
		 * request, LINE_OF_BUSINESS))) { array =
		 * StringUtil.getUnsuppressedValuesForTapId(request,
		 * LINE_OF_BUSINESS).split(COMMA); for (String item : array) { ps.setString(++i,
		 * item); } }
		 * 
		 * if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(
		 * request, LINE_OF_BUSINESS))) { array =
		 * StringUtil.getUnsuppressedValuesForTapId(request,
		 * LINE_OF_BUSINESS).split(COMMA); for (String item : array) { ps.setString(++i,
		 * item); } } }
		 */
		if (null != metricCode && (COC_PAER.equalsIgnoreCase(metricCode))) {

			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());
		}

		if (null != metricCode && (COC_PAER.equalsIgnoreCase(metricCode) || COC_RX.equals(metricCode)
				|| COC_SPL.equals(metricCode) || COC_ASC.equals(metricCode) || COC_EBC.equals(metricCode))) {
			if (!showAll && null != request.getAppPrptyList()) {
				i = buildPreparedStatementWithSuppressionPassCount(request, metricCode, i);
			} else {
				i = buildPreparedStatementWithOutSuppressionPassCount(request, metricCode, i);
			}

		}

		if (null != metricCode && COC_EBC.equals(metricCode)) {
			if (!showAll && null != request.getAppPrptyList()) {
				i = buildPreparedStatementWithSuppressionPassCount(request, metricCode, i);
			} else {
				i = buildPreparedStatementWithOutSuppressionPassCount(request, metricCode, i);
			}
		}
		if (null != metricCode && COC_IP.equalsIgnoreCase(metricCode)) {
			i = buildPreparedStatementPassCount(request, metricCode, i);
			i = buildPreparedStatementPassCount(request, metricCode, i);
		}

		if (null != metricCode && (COC_PAER.equalsIgnoreCase(metricCode))) {

			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			if (!showAll && null != request.getAppPrptyList()) {
				i = buildPreparedStatementWithSuppressionPassCount(request, metricCode, i);
			} else {
				i = buildPreparedStatementWithOutSuppressionPassCount(request, metricCode, i);
			}
			
			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			if (!showAll && null != request.getAppPrptyList()) {
				i = buildPreparedStatementWithSuppressionPassCount(request, metricCode, i);
			} else {
				i = buildPreparedStatementWithOutSuppressionPassCount(request, metricCode, i);
			}

			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			if (!showAll && null != request.getAppPrptyList()) {
				i = buildPreparedStatementWithSuppressionPassCount(request, metricCode, i);
			} else {
				i = buildPreparedStatementWithOutSuppressionPassCount(request, metricCode, i);
			}
		}

		i = buildPreparedStatementPassCount(request, metricCode, i);
	}

	/**
	 * Method to append filters without suppression
	 * 
	 * @param request
	 * @param i
	 * @throws SQLException
	 */
	private void buildPreparedStatementWithOutSuppression(GetCostOpportunitySummaryRequest request, String metricCode,
			int i) throws SQLException {
		String[] array = null;

		if ("All".equalsIgnoreCase(metricCode)) {
			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, GRP))) {
			array = StringUtil.getUnsuppressedValuesForTapId(request, GRP).split(COMMA);
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, PGM))) {
			array = StringUtil.getUnsuppressedValuesForTapId(request, PGM).split(COMMA);
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS))) {
			array = StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS).split(COMMA);
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			array = request.getProvDimKeys().split(COMMA);
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			array = request.getOrgDimKeys().split(COMMA);
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (COC_IP.equalsIgnoreCase(metricCode)) {

			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, GRP))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, GRP).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, PGM))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, PGM).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				array = request.getProvDimKeys().split(COMMA);
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				array = request.getOrgDimKeys().split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, GRP))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, GRP).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, PGM))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, PGM).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				array = request.getProvDimKeys().split(COMMA);
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				array = request.getOrgDimKeys().split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
		}
	}

	/**
	 * Method to append filters without suppression
	 * 
	 * @param request
	 * @param i
	 * @return i
	 * @throws SQLException
	 */
	private int buildPreparedStatementWithOutSuppressionPassCount(GetCostOpportunitySummaryRequest request,
			String metricCode, int i) throws SQLException {
		String[] array = null;

		if ("All".equalsIgnoreCase(metricCode)) {
			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());
		}
		if (COC_IP.equalsIgnoreCase(metricCode)) {

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, GRP))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, GRP).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, PGM))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, PGM).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				array = request.getProvDimKeys().split(COMMA);
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				array = request.getOrgDimKeys().split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
		} else {
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, GRP))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, GRP).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, PGM))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, PGM).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS))) {
				array = StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS).split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				array = request.getProvDimKeys().split(COMMA);
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				array = request.getOrgDimKeys().split(COMMA);
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
		}

		return i;
	}

	/**
	 * Method to append filters with suppression
	 * 
	 * @param request
	 * @param metricName
	 * @param i
	 * @throws SQLException
	 */
	private void buildPreparedStatementWithSuppression(GetCostOpportunitySummaryRequest request, String metricCode,
			int i) throws SQLException {

		if (isAnySuppressed) {
			// Check-1: Group Level Suppression
			if (isGroupSuppressed)
				buildSuppressionClause(request, i, GRP);
			// Check-2: Market Level Suppression
			else if (isMarketSuppressed)
				buildSuppressionClause(request, i, MARKET);
			// Check-3: Program Level Suppression
			else if (isProgramSuppressed)
				buildSuppressionClause(request, i, PGM);
			// Check-4: LOB Level Suppression
			else if (isLOBSuppressed)
				buildSuppressionClause(request, i, LINE_OF_BUSINESS);
			// Check-5: All Level Suppression
			else if (isAllSuppressed)
				buildSuppressionClause(request, i, PROV_GRP_ID_ALL);
		} else {
			buildPreparedStatementWithOutSuppression(request, metricCode, i);
		}
	}

	/**
	 * Method to append suppression clauses
	 * 
	 * @param request
	 * @param i
	 * @param levelOfSuppression
	 * @throws SQLException
	 */
	private void buildSuppressionClause(GetCostOpportunitySummaryRequest request, int i, String levelOfSuppression)
			throws SQLException {
		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression))) {
			if (levelOfSuppression.equalsIgnoreCase(GRP) || levelOfSuppression.equalsIgnoreCase(MARKET)) {
				// Step-1 : set Provider Group ID
				for (String item : StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression).split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-2 : set Program ID
				for (String item : request.getProgramIds().split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-3 : set LOB ID
				for (String item : request.getLobIds().split(COMMA)) {
					ps.setString(++i, item);
				}
			} else if (levelOfSuppression.equalsIgnoreCase(LINE_OF_BUSINESS)) {
				// Step-1 : set Provider Group ID
				for (String item : request.getProvGrpIds().split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-2 : set Program ID
				for (String item : request.getProgramIds().split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-3 : set LOB ID
				for (String item : StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression).split(COMMA)) {
					ps.setString(++i, item);
				}
			} else if (levelOfSuppression.equalsIgnoreCase(PGM)) {
				// Step-1 : set Provider Group ID
				for (String item : request.getProvGrpIds().split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-2 : set Program ID
				for (String item : StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression).split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-3 : set LOB ID
				for (String item : request.getLobIds().split(COMMA)) {
					ps.setString(++i, item);
				}
			}
		}
	}

	/**
	 * Method to append filters with suppression
	 * 
	 * @param request
	 * @param metricName
	 * @param i
	 * @return i
	 * @throws SQLException
	 */
	private int buildPreparedStatementWithSuppressionPassCount(GetCostOpportunitySummaryRequest request,
			String metricCode, int i) throws SQLException {

		if (isAnySuppressed) {
			// Check-1: Group Level Suppression
			if (isGroupSuppressed)
				i = buildSuppressionClausePassCount(request, i, GRP);
			// Check-2: Market Level Suppression
			else if (isMarketSuppressed)
				i = buildSuppressionClausePassCount(request, i, MARKET);
			// Check-3: Program Level Suppression
			else if (isProgramSuppressed)
				i = buildSuppressionClausePassCount(request, i, PGM);
			// Check-4: LOB Level Suppression
			else if (isLOBSuppressed)
				i = buildSuppressionClausePassCount(request, i, LINE_OF_BUSINESS);
			// Check-5: All Level Suppression
			else if (isAllSuppressed)
				i = buildSuppressionClausePassCount(request, i, PROV_GRP_ID_ALL);
		} else {
			i = buildPreparedStatementWithOutSuppressionPassCount(request, metricCode, i);
		}
		return i;
	}

	/**
	 * Method to append suppression clauses
	 * 
	 * @param request
	 * @param i
	 * @param levelOfSuppression
	 * @return i
	 * @throws SQLException
	 */
	private int buildSuppressionClausePassCount(GetCostOpportunitySummaryRequest request, int i,
			String levelOfSuppression) throws SQLException {
		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression))) {
			if (levelOfSuppression.equalsIgnoreCase(GRP) || levelOfSuppression.equalsIgnoreCase(MARKET)) {
				// Step-1 : set Provider Group ID
				for (String item : StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression).split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-2 : set Program ID
				for (String item : request.getProgramIds().split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-3 : set LOB ID
				for (String item : request.getLobIds().split(COMMA)) {
					ps.setString(++i, item);
				}
			} else if (levelOfSuppression.equalsIgnoreCase(LINE_OF_BUSINESS)) {
				// Step-1 : set Provider Group ID
				for (String item : request.getProvGrpIds().split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-2 : set Program ID
				for (String item : request.getProgramIds().split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-3 : set LOB ID
				for (String item : StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression).split(COMMA)) {
					ps.setString(++i, item);
				}
			} else if (levelOfSuppression.equalsIgnoreCase(PGM)) {
				// Step-1 : set Provider Group ID
				for (String item : request.getProvGrpIds().split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-2 : set Program ID
				for (String item : StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression).split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-3 : set LOB ID
				for (String item : request.getLobIds().split(COMMA)) {
					ps.setString(++i, item);
				}
			}

			else if (levelOfSuppression.equalsIgnoreCase(PROV_GRP_ID_ALL)) {
				// Step-1 : set Provider Group ID
				for (String item : StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression).split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-2 : set Program ID
				for (String item : request.getProgramIds().split(COMMA)) {
					ps.setString(++i, item);
				}
				// Step-3 : set LOB ID
				for (String item : request.getLobIds().split(COMMA)) {
					ps.setString(++i, item);
				}
			}
		}
		return i;
	}

	/**
	 * Method to set filters without suppression
	 * 
	 * @param query
	 * @param request
	 */
	private void setFiltersWithoutSuppression(StringBuilder query, GetCostOpportunitySummaryRequest request,
			String alias, boolean isApplyIPORGFilters) {

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, GRP))) {
			query.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
					.append(".PROV_GRP_ID IN  (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
							StringUtil.getUnsuppressedValuesForTapId(request, GRP)) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, PGM))) {
			query.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
					.append(".PGM_DIM_KEY IN (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
							StringUtil.getUnsuppressedValuesForTapId(request, PGM)) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS))) {
			query.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
					.append(".LOB_DESC IN  (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
							StringUtil.getUnsuppressedValuesForTapId(request, LINE_OF_BUSINESS)) + ") ");
		}

		if (isApplyIPORGFilters) {
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				query.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias).append(".IP_DIM_KEY IN  ("
						+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") "); // Modified
																												// as
																												// part
																												// of
																												// defect
																												// PCMSP-29511
																												// -
																												// 2018Q4
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				query.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
						.append(".PROV_ORG_DIM_KEY IN  ("
								+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys()) + ") ");
			}
		}
	}

	/**
	 * Method to append filters with suppression
	 * 
	 * @param query
	 * @param request
	 * @param metricCode
	 * @param metricName
	 * @param alias
	 */
	private void setFiltersWithSuppression(StringBuilder query, GetCostOpportunitySummaryRequest request,
			String metricCode, String metricName, String alias, boolean isApplyIPORGFilters) {
		if (isAnySuppressed) {
			// Check-1: Group Level Suppression
			if (isGroupSuppressed)
				getSuppressionClause(query, metricName, request, GRP, alias);
			// Check-2: Market Level Suppression
			else if (isMarketSuppressed)
				getSuppressionClause(query, metricName, request, MARKET, alias);
			// Check-3: Program Level Suppression
			else if (isProgramSuppressed)
				getSuppressionClause(query, metricName, request, PGM, alias);
			// Check-4: LOB Level Suppression
			else if (isLOBSuppressed)
				getSuppressionClause(query, metricName, request, LINE_OF_BUSINESS, alias);
			// Check-5: All Level Suppression
			else if (isAllSuppressed)
				getSuppressionClause(query, metricName, request, PROV_GRP_ID_ALL, alias);
		} else {
			setFiltersWithoutSuppression(query, request, alias, isApplyIPORGFilters);
		}
	}

	/**
	 * Method to add suppression clause
	 * 
	 * @param query
	 * @param metricName
	 * @param request
	 * @param levelOfSuppression
	 * @param alias
	 */
	private void getSuppressionClause(StringBuilder query, String metricName, GetCostOpportunitySummaryRequest request,
			String levelOfSuppression, String alias) {
		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression))) {
			if (levelOfSuppression.equalsIgnoreCase(GRP) || levelOfSuppression.equalsIgnoreCase(MARKET)) {
				query.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
						.append(".PROV_GRP_ID IN (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
								StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression)) + ") ")
						.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
						.append(".PGM_DIM_KEY IN ("
								+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
						.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias).append(".LOB_DESC in ("
								+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
			} else if (levelOfSuppression.equalsIgnoreCase(LINE_OF_BUSINESS)) {
				query.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
						.append(".PROV_GRP_ID IN ("
								+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ")
						.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
						.append(".PGM_DIM_KEY IN ("
								+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
						.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias).append(
								".LOB_DESC in ("
										+ StringUtil.buildPlaceholdersFromCommaSeparatedList(
												StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression))
										+ ") ");
			} else if (levelOfSuppression.equalsIgnoreCase(PGM)) {
				query.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
						.append(".PROV_GRP_ID IN ("
								+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ")
						.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
						.append(".PGM_DIM_KEY IN (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
								StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression)) + ") ")
						.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias).append(".LOB_DESC in ("
								+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
			} else if (levelOfSuppression.equalsIgnoreCase(PROV_GRP_ID_ALL)) {
				query.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
						.append(".PROV_GRP_ID IN (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
								StringUtil.getUnsuppressedValuesForTapId(request, levelOfSuppression)) + ") ")
						.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias)
						.append(".PGM_DIM_KEY IN ("
								+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
						.append(SINGLE_WHITE_SPACE + AND_OPERATOR + SINGLE_WHITE_SPACE + alias).append(".LOB_DESC in ("
								+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
			}
		}
	}

	/**
	 * Method to convert ResultSet into bean
	 * 
	 * @param rs
	 * @param request
	 * @param exportFlag
	 * @return
	 * @throws SQLException
	 */
	private List<CostOpportunityBean> convertResultsetToBean(ResultSet rs, GetCostOpportunitySummaryRequest request,
			boolean exportFlag) throws SQLException {

		List<CostOpportunityBean> results = new ArrayList<CostOpportunityBean>();
		BigDecimal vTotalOpportunity = BigDecimal.ZERO;
		BigDecimal vTotalOpportunityPMPM = BigDecimal.ZERO;
		BigDecimal vCurrentPerformaceRate = BigDecimal.ZERO;
		BigDecimal vPctlBenchmark90 = BigDecimal.ZERO;
		BigDecimal vPctlBenchmark75 = BigDecimal.ZERO;
		BigDecimal vPctlBenchmark50 = BigDecimal.ZERO;
		BigDecimal vActualBenchmarkRatio = BigDecimal.ZERO;
		BigDecimal v75PctImprovement = BigDecimal.ZERO;
		BigDecimal v50PctImprovement = BigDecimal.ZERO;
		BigDecimal v75PctImprovementPMPM = BigDecimal.ZERO;
		BigDecimal v50PctImprovementPMPM = BigDecimal.ZERO;
		String vCurrentPerformacePercentile = null;
		String vMetricCode = null;
		String vMetricName = null;
		String vDataFormat = null;

		while (rs.next()) {
			CostOpportunityBean item = new CostOpportunityBean();

			vMetricCode = null != rs.getString(METRIC_CD) ? rs.getString(METRIC_CD) : DASHES;
			vMetricName = null != rs.getString(METRIC_NM) ? rs.getString(METRIC_NM) + NEW_LINE : DASHES;
			if (!(COC_IP.equalsIgnoreCase(vMetricCode))) {

				vTotalOpportunity = null != rs.getString(COST_OPPORTUNITY)
						? rs.getBigDecimal(COST_OPPORTUNITY).setScale(2, BigDecimal.ROUND_HALF_UP)
						: BigDecimal.ZERO;
				vTotalOpportunityPMPM = vMemberMonths.compareTo(BigDecimal.ZERO) > 0 ? vTotalOpportunity
						.divide(vMemberMonths, 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP)
						: BigDecimal.ZERO;

				vCurrentPerformaceRate = null != rs.getString(CURRENT_PERFORMANCE_RATE)
						? rs.getBigDecimal(CURRENT_PERFORMANCE_RATE)
						: BigDecimal.ZERO;
				if (null != rs.getString(CURRENT_PERFORMANCE_PERCENTILE)) {
					vCurrentPerformacePercentile = exportFlag
							? rs.getString(CURRENT_PERFORMANCE_PERCENTILE).concat("th")
							: rs.getString(CURRENT_PERFORMANCE_PERCENTILE);
				} else {
					vCurrentPerformacePercentile = DASHES;
				}

				vPctlBenchmark90 = getPctlBnchmark(vMetricCode, rs, TOTL_EXPECTED_DAYS, PCTL_BNCHMRK_90);

				vPctlBenchmark50 = getPctlBnchmark(vMetricCode, rs, TOTL_EXPECTED_DAYS_50, PCTL_BNCHMRK_50);
				vPctlBenchmark75 = getPctlBnchmark(vMetricCode, rs, TOTL_EXPECTED_DAYS_75, PCTL_BNCHMRK_75);

				if (COC_IP.equalsIgnoreCase(vMetricCode) || COC_PAER.equalsIgnoreCase(vMetricCode)
						|| COC_RX.equalsIgnoreCase(vMetricCode) || COC_EBC.equalsIgnoreCase(vMetricCode)) {
					v75PctImprovement = null != rs.getString(PCT_75_IMPROV)
							? rs.getBigDecimal(PCT_75_IMPROV).setScale(2, BigDecimal.ROUND_HALF_UP)
							: BigDecimal.ZERO;
					v50PctImprovement = null != rs.getString(PCT_50_IMPROV)
							? rs.getBigDecimal(PCT_50_IMPROV).setScale(2, BigDecimal.ROUND_HALF_UP)
							: BigDecimal.ZERO;

					v75PctImprovementPMPM = vMemberMonths.compareTo(BigDecimal.ZERO) > 0 ? v75PctImprovement
							.divide(vMemberMonths, 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP)
							: BigDecimal.ZERO;
					v50PctImprovementPMPM = vMemberMonths.compareTo(BigDecimal.ZERO) > 0 ? v50PctImprovement
							.divide(vMemberMonths, 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP)
							: BigDecimal.ZERO;
				}

				vActualBenchmarkRatio = vPctlBenchmark90.compareTo(BigDecimal.ZERO) > 0 ? vCurrentPerformaceRate
						.divide(vPctlBenchmark90, 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP)
						: BigDecimal.ZERO;
				vDataFormat = getDataFormat(vMetricCode);

				item.setMetricCode(vMetricCode);
				item.setMetricName(vMetricName);
				item.setCurrentPerformanceRate(getFormattedRates(vCurrentPerformaceRate, vMetricCode, exportFlag));
				item.setCurrentPerformancePercentile(vCurrentPerformacePercentile);

				item.setPercentileBenchmark90(getFormattedRates(vPctlBenchmark90, vMetricCode, exportFlag));

				item.setPercentileBenchmark50(getFormattedRates(vPctlBenchmark50, vMetricCode, exportFlag));
				item.setPercentileBenchmark75(getFormattedRates(vPctlBenchmark75, vMetricCode, exportFlag));

				item.setMultipleBenchMarkIndicator(
						null != rs.getString(MULTIPLEBENCHMARKINDICATOR) ? rs.getString(MULTIPLEBENCHMARKINDICATOR)
								: N);

				if (!exportFlag) {
					item.setTotalOpportunity(vTotalOpportunity.toString());
					item.setTotalOpportunityPMPM(vTotalOpportunityPMPM.toString());
					item.setActualBenchmarkRatio(vActualBenchmarkRatio.toString());
					item.setDataFormat(vDataFormat);
					if (COC_SOC.equalsIgnoreCase(vMetricCode) || COC_LAB.equalsIgnoreCase(vMetricCode)
							|| COC_ASC.equalsIgnoreCase(vMetricCode) || COC_SPL.equalsIgnoreCase(vMetricCode)) {
						item.setFiftyPercentImprovement(DASHES);
						item.setFiftyPercentImprovementPMPM(DASHES);
						item.setSeventyFivePercentImprovement(DASHES);
						item.setSeventyFivePercentImprovementPMPM(DASHES);
					} else {
						item.setFiftyPercentImprovement(v50PctImprovement.toString());
						item.setFiftyPercentImprovementPMPM(v50PctImprovementPMPM.toString());
						item.setSeventyFivePercentImprovement(v75PctImprovement.toString());
						item.setSeventyFivePercentImprovementPMPM(v75PctImprovementPMPM.toString());
					}

				} else {
					item.setTotalOpportunity(StringUtil.convertStringToDecimalCurrency(
							vTotalOpportunity.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					item.setTotalOpportunityPMPM(StringUtil.convertStringToDecimalCurrency(
							vTotalOpportunityPMPM.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					item.setActualBenchmarkRatio(StringUtil.convertStringToCommaBigDecimal(
							vActualBenchmarkRatio.setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));
					if (COC_SOC.equalsIgnoreCase(vMetricCode) || COC_LAB.equalsIgnoreCase(vMetricCode)
							|| COC_ASC.equalsIgnoreCase(vMetricCode) || COC_SPL.equalsIgnoreCase(vMetricCode)) {
						item.setFiftyPercentImprovement(DASHES);
						item.setFiftyPercentImprovementPMPM(DASHES);
						item.setSeventyFivePercentImprovement(DASHES);
						item.setSeventyFivePercentImprovementPMPM(DASHES);
					} else {
						item.setFiftyPercentImprovement(StringUtil.convertStringToDecimalCurrency(
								v50PctImprovement.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
						item.setFiftyPercentImprovementPMPM(StringUtil.convertStringToDecimalCurrency(
								v50PctImprovementPMPM.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
						item.setSeventyFivePercentImprovement(StringUtil.convertStringToDecimalCurrency(
								v75PctImprovement.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
						item.setSeventyFivePercentImprovementPMPM(StringUtil.convertStringToDecimalCurrency(
								v75PctImprovementPMPM.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
				}
				
				if (null != rs.getString(LOB_DESC)) {
					if (rs.getString(LOB_DESC).equals(MEDICARE_ADVANTAGE)) {
						item.setLob(MEDICARE);
					} else {
						item.setLob(rs.getString(LOB_DESC));
					}
				}
				results.add(item);
			}
		}
		return results;

	}

	/**
	 * 
	 * @param totalOpportunityAmt
	 * @param totlExpectedDays
	 * @param totlTCInpatientDays
	 * @return
	 * @throws SQLException
	 */
	private boolean isNotIPUtilData(String totalOpportunityAmt, String totlExpectedDays, String totlTCInpatientDays)
			throws SQLException {
		if (null == totalOpportunityAmt && null == totlExpectedDays && null == totlTCInpatientDays) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method to Format Data for Export
	 * 
	 * @param inputRate
	 * @param vMetricCode
	 * @param exportFlag
	 * @return
	 */
	private String getFormattedRates(BigDecimal inputRate, String vMetricCode, boolean exportFlag) {
		if (exportFlag) {
			if (null != vMetricCode && COC_RX.equals(vMetricCode)) {
				return StringUtil
						.convertStringToDecimalCurrency(inputRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			} else if (null != vMetricCode && (COC_ASC.equals(vMetricCode) || COC_SPL.equals(vMetricCode)
					|| COC_LAB.equals(vMetricCode) || COC_SOC.equals(vMetricCode))) {
				return StringUtil
						.convertStringToCommaBigDecimal(inputRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2)
						.concat(PERCENT_SIGN);
			} else
				return StringUtil
						.convertStringToCommaBigDecimal(inputRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2);
		} else
			return inputRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString();
	}

	/**
	 * Method to return Data Format for UX
	 * 
	 * @param vMetricCode
	 * @return
	 */
	private String getDataFormat(String vMetricCode) {
		if (null != vMetricCode && COC_RX.equals(vMetricCode))
			return DATA_FORMAT_FOR_RX;
		else if (null != vMetricCode && (COC_ASC.equals(vMetricCode) || COC_SPL.equals(vMetricCode)
				|| COC_LAB.equals(vMetricCode) || COC_SOC.equals(vMetricCode)))
			return DATA_FORMAT_FOR_ASC_PERF_RATE;
		else
			return DATA_FORMAT;
	}

	/**
	 * Method to obtain 90th, 75th ,50th Percentile Benchmark
	 * 
	 * @param vMetricCode
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private BigDecimal getPctlBnchmark(String vMetricCode, ResultSet rs, String totalExpectedDays, String benchMark)
			throws SQLException {
		if (null != vMetricCode && COC_IP.equals(vMetricCode)) {

			if (null != rs.getString(totalExpectedDays)) {
				return (rs.getBigDecimal(totalExpectedDays).compareTo(BigDecimal.ZERO) > 0
						&& vTotalMembers.compareTo(BigDecimal.ZERO) > 0)
								? (rs.getBigDecimal(totalExpectedDays).multiply(PERF_RATE_1000_FACTOR))
										.divide(vTotalMembers, 4, BigDecimal.ROUND_HALF_UP)
								: BigDecimal.ZERO;
			} else
				return BigDecimal.ZERO;
		} else {
			if (null != rs.getString(benchMark)) {
				return rs.getBigDecimal(benchMark);
			} else
				return BigDecimal.ZERO;
		}

	}

	/**
	 * The Method is intended to calculate Member Month for Cost Opportunity Summary
	 * SCreen
	 * 
	 * @param request
	 * @return
	 */
	private Map<String, BigDecimal> getMemberMonth(GetCostOpportunitySummaryRequest request) {

		Map<String, BigDecimal> returnMap = new HashMap<String, BigDecimal>();

		StringBuilder mbrMonth = new StringBuilder()
				.append(" select  	NVL(SUM(MM.MBR_MNTH_12_CNT),0) AS MEM_MNTH , LOB_DESC ")
				.append(" FROM  PAT_SMRY_FACT PSF ").append(" left join  MSTR_CNSMR_MBR_MNTH_FACT MM  ")
				.append(" ON MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY ").append(" and MM.RCRD_STTS_CD = 'ACT'  ")
				.append(" left join MSTR_CNSMR_DIM MCD   ")
				.append(" ON  MCD.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY     ")
				.append(" and  MCD.RCRD_STTS_CD = 'ACT' ")
				.append(QueryConstants.getPoitUserTableJoin(ALIAS_PAT_SMRY_FACT)).append(" where ")
				.append(" pusa.sesn_id = ? ").append(" and pusa.enttlmnt_hash_key = ? ")
				.append("   AND  PSF.ATRBN_STTS_CD = 'ACTIVE'   ");
		setFiltersWithoutSuppression(mbrMonth, request, ALIAS_PAT_SMRY_FACT, BOOL_TRUE);

		mbrMonth.append("group by LOB_DESC");

		try {
			cn = Database.getConnection(Constants.SNOWFLAKE_DATASOURCE);
			int i = 0;

			prepareStatement(logger, mbrMonth.toString());

			buildPreparedStatementWithOutSuppression(request, "All", i);

			executeQuery(logger, mbrMonth.toString());

			while (rs.next()) {
				returnMap.put(MEM_MNTH, rs.getBigDecimal(MBR_MNTH));
				break;
			}
		} catch (Exception e) {
			logger.error("Error in getMemberMonth", e);
		} finally {
			close();
		}

		return returnMap;
	}

	/**
	 * The Method is intended to calculate Total Member Month for Cost Opportunity
	 * Summary Screen
	 * 
	 * @param request
	 * @return
	 */
	private Map<String, BigDecimal> getTotalMember(GetCostOpportunitySummaryRequest request) {

		Map<String, BigDecimal> returnMap = new HashMap<String, BigDecimal>();

		StringBuilder query = new StringBuilder()
				.append(" SELECT COUNT(DISTINCT PSF.MSTR_CNSMR_DIM_KEY) AS TOTL_MEMBER ")
				.append(" FROM   PAT_SMRY_FACT PSF  ")
				.append(" LEFT JOIN   MSTR_CNSMR_MBR_MNTH_FACT MM ON  MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY  ")
				.append(" 	AND  MM.RCRD_STTS_CD = 'ACT'  ")
				.append(QueryConstants.getPoitUserTableJoin(ALIAS_PAT_SMRY_FACT)).append(" where ")
				.append(" pusa.sesn_id = ? ").append(" and pusa.enttlmnt_hash_key = ? ")
				.append(" and PSF.ATRBN_STTS_CD = 'ACTIVE'  ");

		setFiltersWithoutSuppression(query, request, ALIAS_PAT_SMRY_FACT, BOOL_TRUE);

		try {
			cn = Database.getConnection(Constants.SNOWFLAKE_DATASOURCE);
			int i = 0;

			prepareStatement(logger, query.toString());

			buildPreparedStatementWithOutSuppression(request, "All", i);

			executeQuery(logger, query.toString());

			while (rs.next()) {
				returnMap.put(TOTL_MBR, rs.getBigDecimal(TOTL_MEMBER));
			}
		} catch (Exception e) {
			logger.error("Error in getTotalMember", e);
		} finally {
			close();
		}

		return returnMap;
	}

	/**
	 * Method to get Query for Minimum Criteria for PAER Metric
	 * 
	 * @return
	 */
	private StringBuilder buildQueryForPAERMinCriteria() {
		return new StringBuilder().append(" select  distinct aplctn_prpty_val_txt as " + COC_PAER_MIN_TOTL_SCRPT)
				.append(" from  aplctn_prpty  ").append(" where  aplctn_prpty_nm = '" + COC_PAER_MIN_TOTL_SCRPT + "' ")
				.append(" and  aplctn_prpty_ownr_nm = 'MW_CONFIG' ");
	}

	/**
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	@Override
	public boolean read(Dto obj) throws Exception {
		return false;
	}

	/**
	 * @param obj
	 * @throws Exception
	 */
	@Override
	public void insert(Dto obj) throws Exception {

	}

	/**
	 * @param obj
	 * @throws Exception
	 */
	@Override
	public void update(Dto obj) throws Exception {
	}

	/**
	 * @param obj
	 * @throws Exception
	 */
	@Override
	public void delete(Dto obj) throws Exception {
	}
}
