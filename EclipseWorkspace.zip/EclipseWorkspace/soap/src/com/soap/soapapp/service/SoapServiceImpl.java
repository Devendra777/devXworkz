package com.soap.soapapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.soap.soapapp.dao.SoapDAO;
import com.soap.soapapp.dto.SoapDTO;

@Component
public class SoapServiceImpl implements SoapService{
	
	@Autowired
	private SoapDAO dao;
	
	public SoapServiceImpl() {
		System.out.println("service impl is created");
	}

	@Override
	public void validateAndCreateSoap(SoapDTO dto) {
		if(dto != null) {
			dao.createSoap(dto);
		}
	
		
	}
	
	

}
