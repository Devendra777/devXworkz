package com.soap.soapapp.service;

import com.soap.soapapp.dto.SoapDTO;


public interface SoapService {
	
	
	public void validateAndCreateSoap(SoapDTO dto);
	
	

}
