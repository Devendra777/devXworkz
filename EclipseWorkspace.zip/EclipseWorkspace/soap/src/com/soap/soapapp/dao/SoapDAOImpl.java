package com.soap.soapapp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.soap.soapapp.dto.SoapDTO;

@Component
public class SoapDAOImpl implements SoapDAO {


	@Autowired
	private SessionFactory factory;

	public SoapDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createSoap(SoapDTO dto) {
		Session session = null;
		try {
			session = factory.openSession();
			session.beginTransaction();
			session.save(dto);
			session.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			if (session.getTransaction() != null) {
				session.getTransaction().rollback();
				e.printStackTrace();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

}
