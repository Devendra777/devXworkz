package com.soap.soapapp.dao;

import com.soap.soapapp.dto.SoapDTO;

public interface SoapDAO {
	
	public void createSoap(SoapDTO dto);

}
