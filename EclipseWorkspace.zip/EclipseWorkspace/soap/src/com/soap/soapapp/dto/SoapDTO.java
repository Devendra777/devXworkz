package com.soap.soapapp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "soap_table")
public class SoapDTO implements Serializable {

	public SoapDTO() {
		// TODO Auto-generated constructor stub
		System.out.println("SoapDTO object is created");
	}

	@Id
	@Column(name = "soap_id")
	private int soapId;
	@Column(name = "soap_Name")
	private String soapName;
	@Column(name = "soap_color")
	private String soapColor;
	@Column(name = "soap_type")
	private String soapType;
	@Column(name = "soap_price")
	private String soapPrice;

	public int getSoapId() {
		return soapId;
	}

	public void setSoapId(int soapId) {
		this.soapId = soapId;
	}

	public String getSoapName() {
		return soapName;
	}

	public void setSoapName(String soapName) {
		this.soapName = soapName;
	}

	public String getSoapColor() {
		return soapColor;
	}

	public void setSoapColor(String soapColor) {
		this.soapColor = soapColor;
	}

	public String getSoapType() {
		return soapType;
	}

	public void setSoapType(String soapType) {
		this.soapType = soapType;
	}

	public String getSoapPrice() {
		return soapPrice;
	}

	public void setSoapPrice(String soapPrice) {
		this.soapPrice = soapPrice;
	}

	@Override
	public String toString() {
		return "SoapDTO [soapId=" + soapId + ", soapName=" + soapName + ", soapColor=" + soapColor + ", soapType="
				+ soapType + ", soapPrice=" + soapPrice + "]";
	}

}
