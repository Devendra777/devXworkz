package com.soap.soapapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.soap.soapapp.dto.SoapDTO;
import com.soap.soapapp.service.SoapService;

public class SoapApplication {
	
	
	public static void main(String[] args) {
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("resources/context.xml");
		
		SoapDTO dto = new SoapDTO();
		dto.setSoapId(6);
		dto.setSoapColor("red");
		dto.setSoapPrice("10");
		dto.setSoapType("bodyType");
		dto.setSoapName("lifebouy");
		
		SoapService   service = 	applicationContext.getBean(SoapService.class);
		service.validateAndCreateSoap(dto);
		
	}

}
