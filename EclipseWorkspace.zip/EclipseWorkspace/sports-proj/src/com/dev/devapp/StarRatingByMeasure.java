package com.dev.devapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StarRatingByMeasure {

	
	/*
	 * static int val=3;
	 * 
	 * static int getValue() { return val--; }
	 * 
	 * public static void main(String[] args) {
	 * 
	 * int n; for (int i = 0; i < 5; i++) { n=getValue(); assert n> 2;
	 * System.out.println(" " + n);
	 * 
	 * }
	 * 
	 * }
	 */
	
	
	public static void main(String[] args) {
		
		int[] array= {6,9,8};
		List<Integer> integers = new ArrayList<Integer>();
		integers.add(array[0]);
		integers.add(array[2]);
		integers.set(1, array[1]);
	integers.remove(0);
	System.out.println(integers);
	}
}
