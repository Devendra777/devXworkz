package com.dev.devapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Sports {

	public static void sportsBatch() throws ClassNotFoundException, SQLException {
		String sql = "insert into sports_table values(24201,'basketbal','outdoor',7)";
		String sql1 = "insert into sports_table values(28410,'chess','indoor',2)";
		String sql2 = "insert into sports_table values(216810,'gilidanda','outdoor',99)";
		String sql3 = "insert into sports_table values(233313,'laggori','outdoor',8)";
		try (Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/jokes?user=root&password=Rohith782912");) {
			con.setAutoCommit(false);
			try (Statement stmt = con.createStatement();) {
				stmt.addBatch(sql);
				stmt.addBatch(sql1);
				stmt.addBatch(sql2);
				stmt.addBatch(sql3);

				int a[] = stmt.executeBatch();
				for (int i : a) {
					System.out.print(i);
				}
				con.commit();
				stmt.close();
			}
			con.close();
			
		}

	}

	public static void main(String[] args) {

		try {
			Sports.sportsBatch();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
