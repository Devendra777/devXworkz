package com.dev.devapp;

import java.io.Serializable;

public class StarsRatingByMeasureJson implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2536802108303749782L;
	private int careOppId;
	private String measure;
	private String rating;


	public int getCareOppId() {
		return careOppId;
	}

	public void setCareOppId(int careOppId) {
		this.careOppId = careOppId;
	}

	public String getMeasure() {
		return measure;
	}

	public void setMeasure(String measure) {
		this.measure = measure;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "StarsRatingByMeasureJson [careOppId=" + careOppId + ", measure=" + measure + ", rating=" + rating + "]";
	}

}
