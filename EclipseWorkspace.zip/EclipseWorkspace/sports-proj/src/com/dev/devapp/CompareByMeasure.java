package com.dev.devapp;

import java.util.Comparator;

public class CompareByMeasure implements Comparator<StarsRatingByMeasureJson>{


	@Override
	public int compare(StarsRatingByMeasureJson o1, StarsRatingByMeasureJson o2) {
		// TODO Auto-generated method stub
		return o1.getMeasure().compareTo(o2.getMeasure());
	}

}
