package com.xworkz.xworkzapp;

import com.xworkz.xworkzapp.dto.ForestDTO;

public class ForestTester {
	
	public static void main(String[] args) {
		ForestDTO  dto = new ForestDTO();
		  dto.setForestName("Bandipur");
		  dto.setAreaInSqkm("100000sqkm");
		  dto.setType("Dry");
		  System.out.println(dto.getForestName() + " "+ dto.getAreaInSqKm() + " "+ dto.getType());
		  
		  
		  ForestDTO savanna   = new ForestDTO();
		  savanna.setForestName("Savanna");
		  savanna.setAreaInSqkm("120000sqkm");
		  savanna.setType("South Indian subtropical hill savannah (woodland)");
		  System.out.println(savanna.getForestName() + " "+ savanna.getAreaInSqKm() + " "+ savanna.getType());
		
	}

}
