package com.xworkz.xworkzapp.dto;

public class ForestDTO {

	private String forestName;
	private String areaInSqKm;
	private String type;
	
	
	public ForestDTO() {
		System.out.println("ForestDTO Object is created");
	}

	public String getForestName() {
		return forestName;
	}

	public void setForestName(String name) {
		forestName = name;
	}

	public String getAreaInSqKm() {
		return areaInSqKm;
	}

	public void setAreaInSqkm(String area) {
		areaInSqKm = area;
	}

	public String getType() {
		return type;
	}

	public void setType(String tp) {
		type = tp;
	}
}
