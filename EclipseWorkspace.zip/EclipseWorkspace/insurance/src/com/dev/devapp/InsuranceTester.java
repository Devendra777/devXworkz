package com.dev.devapp; 

import com.dev.devapp.insurance.Insurance;

public class InsuranceTester {
	
	
	public static void main(String[] args) {
		Insurance insurance =new Insurance();
		
		Insurance insurance1 =null;
		/*
		 * insurance1.insuranceId=345; insurance1.type="term-insurance";
		 * System.out.println(insurance1.insuranceId + " "+ insurance1.type);
		 * System.out.println(insurance1.hashCode()); System.out.println(insurance);
		 * System.out.println(insurance1);
		 */
		System.out.println(insurance.equals(insurance1));
	}

}
