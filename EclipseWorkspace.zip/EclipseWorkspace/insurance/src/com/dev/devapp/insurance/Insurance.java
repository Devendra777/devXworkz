package com.dev.devapp.insurance;

public class Insurance {

	public int insuranceId;
	public String type;

	public void security() {

		System.out.println("providing security for family");
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return this.insuranceId;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Insurance - [InsuranceId= " + this.insuranceId + " ,type = " + this.type + "  ]";
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		boolean check = false;
		if (obj instanceof Insurance) {
			if (obj != null) {
				System.out.println("inside instanceof");
				if (this.hashCode() == obj.hashCode()) {
					return true;
				}
				 else {
						return check;
					}
			}
			
		}
		return check;
	}

}
