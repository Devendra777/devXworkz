package com.card.cardapp.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.card.cardapp.dto.CreditCardDTO;


@Component
@RequestMapping("/")
public class CreditCardController {
	//process the client request
	
	public CreditCardController() {
		// TODO Auto-generated constructor stub
		System.out.println(this.getClass().getSimpleName()+ " created");
	}
	
	@RequestMapping(value="credit" , method= RequestMethod.POST)
	public String saveCreditCard(@ModelAttribute CreditCardDTO cardDTO) {
		
		System.out.println("Saving Card Details inside Controller");
		if( !cardDTO.getCardNo().isEmpty() && cardDTO.getCardNo() != null  && cardDTO.getExpiryDate() != null) {
			System.out.println("Success");		
			return "/Success.jsp";
		}
		System.out.println("failed...");
		return "/creditcard.jsp";
	}

}
