package com.card.cardapp.dto;


public class CreditCardDTO implements Serializable {

	public CreditCardDTO() {
		// TODO Auto-generated constructor stub
	}

	
	private int cardId;

	@Column(name = "card_no")
	private String cardNo;

	@Column(name = "card_name")
	private String name;

	@Column(name = "card_expiry_date")
	private String expiryDate;

	@Column(name = "card_bank")
	private String bank;

	@Column(name = "card_color")
	private String cardColor;

	public int getCardId() {
		return cardId;
	}

	public void setCardId(int cardId) {
		this.cardId = cardId;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getCardColor() {
		return cardColor;
	}

	public void setCardColor(String cardColor) {
		this.cardColor = cardColor;
	}

}
