package com.xworkz.bluetooth.service;

import java.util.List;

import com.xworkz.bluetooth.dao.BluetoothDAO;
import com.xworkz.bluetooth.dao.BluetoothDAOImpl;
import com.xworkz.bluetooth.dto.BluetoothSpeakerDTO;

// Service layer -  Business logic /Validation
public class BluetoothSpeakerServiceImpl implements BluetoothSpeakerService {

	// Has a Relationship
	private BluetoothDAO bluetoothDAO;

	public BluetoothSpeakerServiceImpl() {
		// TODO Auto-generated constructor stub
		bluetoothDAO = new BluetoothDAOImpl();

	}

	@Override
	public void validateAndSave(BluetoothSpeakerDTO bluetoothSpeakerDTO) {

		if (bluetoothSpeakerDTO != null) {
			if (bluetoothSpeakerDTO.getRange() != null) {
				bluetoothDAO.save(bluetoothSpeakerDTO);
			}

		}

	}

	@Override
	public BluetoothSpeakerDTO getBlueToothById(int id) {
		if (id > 0) {
			return bluetoothDAO.getBlueToothById(id);
		}
		return null;
	}

	@Override
	public void updateCompanyByBluetoothName(String bluetoothName, String company) {
		// TODO Auto-generated method stub
		if (bluetoothName != null && company != null) {
			bluetoothDAO.updateCompanyByBluetoothName(bluetoothName, company);
		}
	}

	@Override
	public List<BluetoothSpeakerDTO> getAllBlueSpeaker() {

		return bluetoothDAO.getAllBluetoothSpeakers();
	}

	@Override
	public BluetoothSpeakerDTO getBlueToothSpeakerByBluetoothId(int id) {
		if (id > 0) {

			return bluetoothDAO.getBlueToothSpeakerByBluetoothId(id);
		}
		return null;
	}

	@Override
	public String getBluetoothCompanyNameByBluetoothName(String bluetoothName) {
		if (bluetoothName != null) {

			return bluetoothDAO.getBluetoothCompanyNameByBluetoothName(bluetoothName);
		}
		return bluetoothName;

	}

	@Override
	public Object[] getNameAndRangeByCompany(String companyName) {
		if (companyName != null) {
			return bluetoothDAO.getNameAndRangeByCompany(companyName);
		}
		return null;
	}

	@Override
	public List<Object[]> getAllNameAndRange() {
		return bluetoothDAO.getAllNameAndRange();
	}

	@Override
	public int updateRangeByBluetoothName(String range, String bluetooth) {
	if(range != null && bluetooth !=null) {
		return bluetoothDAO.updateRangeByBluetoothName(range, bluetooth);
	}
	return 0;
	}

	@Override
	public int deleteBlueToothSpeakerByCompany(String company) {
	if(company != null)
	{
		return bluetoothDAO.deleteBlueToothSpeakerByCompany(company);
	}
	return 0;
	}

}
