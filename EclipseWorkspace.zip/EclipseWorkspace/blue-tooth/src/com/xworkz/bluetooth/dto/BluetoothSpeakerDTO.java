package com.xworkz.bluetooth.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "bluetooth_speaker_table")
@NamedQueries({ @NamedQuery(name = "getAllBlueSpeakerDetails", query = "select dto from BluetoothSpeakerDTO dto"),
	@NamedQuery(name = "getCompanyNameByBName", query = "select dto.companyName from BluetoothSpeakerDTO dto where dto.bluetoothName=:nm"), 
	@NamedQuery(name = "getBNameAndRangeByCompanyName", query = "select dto.bluetoothName, dto.range from BluetoothSpeakerDTO dto where dto.companyName=:cName"), 
	@NamedQuery(name = "getBluetoothNameAndRange", query = "select dto.bluetoothName, dto.range from BluetoothSpeakerDTO dto"),
	@NamedQuery(name = "updateBletoothSpeakerByRangeAndBName", query = "update BluetoothSpeakerDTO dto set dto.range=:rn where dto.bluetoothName=:name"),
	@NamedQuery(name = "deleteBluetoothSpeakerByCompanyName", query = "delete from  BluetoothSpeakerDTO dto where dto.companyName=:compName"), 
  @NamedQuery(name = "getBluetoothSpeakerById",query="select dto from BluetoothSpeakerDTO dto where dto.bluetoothId=:blueId")
})
public class BluetoothSpeakerDTO implements Serializable {

	@Id // Primary Key
	@Column(name = "bluetooth_id")
	@GenericGenerator(name = "ref", strategy = "increment")
	@GeneratedValue(generator = "ref")
	private int bluetoothId;

	@Column(name = "bluetooth_name")
	private String bluetoothName;

	@Column(name = "bluetooth_company")
	private String companyName;

	@Column(name = "bluetooth_range")
	private String range;

	public BluetoothSpeakerDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getBluetoothId() {
		return bluetoothId;
	}

	public void setBluetoothId(int bluetoothId) {
		this.bluetoothId = bluetoothId;
	}

	public String getBluetoothName() {
		return bluetoothName;
	}

	public void setBluetoothName(String bluetoothName) {
		this.bluetoothName = bluetoothName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getRange() {
		return range;
	}

	public void setRange(String range) {
		this.range = range;
	}

	@Override
	public String toString() {
		return "BluetoothSpeakerDTO [bluetoothId=" + bluetoothId + ", bluetoothName=" + bluetoothName + ", companyName="
				+ companyName + ", range=" + range + "]";
	}

}
