package com.xworkz.bluetooth;

import com.xworkz.bluetooth.service.BluetoothSpeakerService;
import com.xworkz.bluetooth.service.BluetoothSpeakerServiceImpl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;

import com.xworkz.bluetooth.dto.BluetoothSpeakerDTO;

public class BluetoothTester {

	public static void main(String[] args) {

		BluetoothSpeakerDTO bluetoothSpeakerDTO = new BluetoothSpeakerDTO();
		bluetoothSpeakerDTO.setBluetoothId(84);
		bluetoothSpeakerDTO.setCompanyName("plantronics");
		bluetoothSpeakerDTO.setBluetoothName("plantronics-79");
		bluetoothSpeakerDTO.setRange("89m");


		BluetoothSpeakerService bluetoothSpeakerService = new BluetoothSpeakerServiceImpl();
		

		BluetoothSpeakerDTO bluetoothSpeakerDTO2 = bluetoothSpeakerService.getBlueToothById(6);
		//System.out.println(bluetoothSpeakerDTO2);
		// bluetoothSpeakerService.validateAndSave(bluetoothSpeakerDTO);

		List<BluetoothSpeakerDTO> bluetoothSpeakerDTOs = bluetoothSpeakerService.getAllBlueSpeaker();
		bluetoothSpeakerDTOs.forEach(System.out::println);

		BluetoothSpeakerDTO speakerDTOFromDB = bluetoothSpeakerService.getBlueToothSpeakerByBluetoothId(6);
		System.out.println(speakerDTOFromDB);
		Object companyName = bluetoothSpeakerService.getBluetoothCompanyNameByBluetoothName("mi-1234");
		System.out.println("The companyName is " + companyName);

		Object[] object = bluetoothSpeakerService.getNameAndRangeByCompany("MI");
		for (Object object2 : object) {
			System.out.println(object2);
		}

		List<Object[]> objects = bluetoothSpeakerService.getAllNameAndRange();
		for (Object[] objects2 : objects) {
			for (Object objects3 : objects2) {
				System.out.print(objects3 + " ");
			}

		}

		/*
		 * int noOfRowsAffected =
		 * bluetoothSpeakerService.updateRangeByBluetoothName("20m", "mi-1234");
		 * System.out.println(noOfRowsAffected);
		 */

		/*
		 * int noOfRowsAffected=
		 * bluetoothSpeakerService.deleteBlueToothSpeakerByCompany("1-plus");
		 * System.out.println(noOfRowsAffected);
		 */

		// bluetoothSpeakerService.updateCompanyByBluetoothName("Oneplus Bullets
		// Wireless" ,"Sony");

	}

}
