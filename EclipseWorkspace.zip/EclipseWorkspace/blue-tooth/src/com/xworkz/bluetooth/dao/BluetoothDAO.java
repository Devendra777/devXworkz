package com.xworkz.bluetooth.dao;

import java.util.List;

import com.xworkz.bluetooth.dto.BluetoothSpeakerDTO;

public interface BluetoothDAO {
	
	
	public void   save(BluetoothSpeakerDTO bluetoothSpeakerDTO);

	public BluetoothSpeakerDTO getBlueToothById(int id);

	public void updateCompanyByBluetoothName(String bluetoothName, String company);

	public List<BluetoothSpeakerDTO> getAllBluetoothSpeakers();

	public BluetoothSpeakerDTO getBlueToothSpeakerByBluetoothId(int id);

	public String getBluetoothCompanyNameByBluetoothName(String bluetoothName);

	public Object[] getNameAndRangeByCompany(String companyName);
	
	public List<Object[]>   getAllNameAndRange();

	public int updateRangeByBluetoothName(String range, String bluetooth);

	public int deleteBlueToothSpeakerByCompany(String company);
	
	

}
