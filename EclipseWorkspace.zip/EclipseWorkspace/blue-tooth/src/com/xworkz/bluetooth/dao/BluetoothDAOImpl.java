package com.xworkz.bluetooth.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;

import com.xworkz.bluetooth.dto.BluetoothSpeakerDTO;
import com.xworkz.singleton.HibernateUtil;

// DAO - write persistence logic - design pattern
public class BluetoothDAOImpl implements BluetoothDAO {

	@Override
	public void save(BluetoothSpeakerDTO bluetoothSpeakerDTO) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			transaction = session.beginTransaction();
			session.saveOrUpdate(bluetoothSpeakerDTO);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (transaction != null) {
				session.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		// factory.close();
	}

	@Override
	public BluetoothSpeakerDTO getBlueToothById(int id) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		BluetoothSpeakerDTO bluetoothSpeakerDTO = session.load(BluetoothSpeakerDTO.class, id);
		System.out.println(bluetoothSpeakerDTO.getBluetoothName());
		session.close();
		// factory.close();
		return bluetoothSpeakerDTO;

	}

	@Override
	public void updateCompanyByBluetoothName(String bluetoothName, String company) {
		// TODO Auto-generated method stub
		SessionFactory factory = HibernateUtil.getSessionFactory();
		System.out.println(factory);
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		BluetoothSpeakerDTO bluetoothSpeakerDTO = session.get(BluetoothSpeakerDTO.class, "");
		if (bluetoothSpeakerDTO != null) {
			if (bluetoothName.equalsIgnoreCase(bluetoothSpeakerDTO.getBluetoothName())) {
				bluetoothSpeakerDTO.setCompanyName(company);
				session.update(bluetoothSpeakerDTO);
			}

		}

		transaction.commit();
		session.close();
		// factory.close();
	}

	@Override
	public List<BluetoothSpeakerDTO> getAllBluetoothSpeakers() {
		System.out.println("inside getAllBluetoothSpeakers()");
		Session session = null;
		List<BluetoothSpeakerDTO> bluetoothSpeakerDTOs = new ArrayList<BluetoothSpeakerDTO>();
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			// 1) Prepare a query
			//Query query = session.getNamedQuery("getAllBlueSpeakerDetails");
			Criteria query = session.createCriteria(BluetoothSpeakerDTO.class);
			query.addOrder(Order.asc("range"));
			// 2) Process a Query
			bluetoothSpeakerDTOs = query.list();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			} else {
				System.out.println("session cannot be closed");
			}

		}
		return bluetoothSpeakerDTOs;
	}

	@Override
	public BluetoothSpeakerDTO getBlueToothSpeakerByBluetoothId(int id) {
		Session session = null;
		BluetoothSpeakerDTO bluetoothSpeakerDTO = new BluetoothSpeakerDTO();
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			Query query = session.getNamedQuery("getBluetoothSpeakerById");
			query.setParameter("blueId", id);
			// 2)
			bluetoothSpeakerDTO = (BluetoothSpeakerDTO) query.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			} else {
				System.out.println("session cannot be closed");
			}

		}
		return bluetoothSpeakerDTO;

	}

	@Override
	public String getBluetoothCompanyNameByBluetoothName(String bluetoothName) {
		Session session = null;
		String companyName = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			Query query = session.getNamedQuery("getCompanyNameByBName");
			query.setParameter("nm", bluetoothName);
			companyName = (String) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			} else {
				System.out.println("session cannot be closed");
			}

		}
		return companyName;
	}

	@Override
	public Object[] getNameAndRangeByCompany(String companyName) {
		Session session = null;
		Object[] bluetoothNameAndRange = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			Query query = session.getNamedQuery("getBNameAndRangeByCompanyName");
			query.setParameter("cName", companyName);
			bluetoothNameAndRange = (Object[]) query.uniqueResult();
			return bluetoothNameAndRange;
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			} else {
				System.out.println("session cannot be closed");
			}

		}
		return null;
	}

	@Override
	public List<Object[]> getAllNameAndRange() {
		Session session = null;
		List<Object[]> bluetoothNameAndRange = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			// 1)Prepare a query
			Query query = session.getNamedQuery("getBluetoothNameAndRange");
			// 2) Process a query
			bluetoothNameAndRange = query.list();
			return bluetoothNameAndRange;
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			} else {
				System.out.println("session cannot be closed");
			}

		}
		return null;
	}

	@Override
	public int updateRangeByBluetoothName(String range, String bluetooth) {
		Session session = null;
		int noOfRowsAffected = 0;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			// 1)Prepare a query
			Query query = session.getNamedQuery("updateBletoothSpeakerByRangeAndBName");
			query.setParameter("rn", range);
			query.setParameter("name", bluetooth);
			noOfRowsAffected = query.executeUpdate();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			} else {
				System.out.println("session cannot be closed");
			}

		}
		return noOfRowsAffected;
	}

	@Override
	public int deleteBlueToothSpeakerByCompany(String company) {
		Session session = null;
		int noOfRowsAffected = 0;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			// 1)Prepare a query
			Query query = session.getNamedQuery("deleteBluetoothSpeakerByCompanyName");
			query.setParameter("compName", company);
			noOfRowsAffected = query.executeUpdate();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			} else {
				System.out.println("session cannot be closed");
			}

		}
		return noOfRowsAffected;
	}

}