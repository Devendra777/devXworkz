package com.dev.devapp.appa;

public class Soda {
	private String name;

	// getter
	public String getName() {
		return name;
	}

	// setter
	public void setName(String name) {
		this.name = name;
	}

}
