package com.dev.devapp.appa;


//parent class
public class Appa {

	//instance variable
	public String name="Janaka";
	
	//constructor
	public Appa() {
		System.out.println(" Appa created");
	}
	

}
