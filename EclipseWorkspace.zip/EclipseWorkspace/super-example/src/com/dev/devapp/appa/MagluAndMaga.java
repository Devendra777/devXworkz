package com.dev.devapp.appa;


//child class
public class MagluAndMaga extends Appa{
	
	//instance variable
	public String name ="ChinnaChintu";

	//
	public MagluAndMaga() {
		
		System.out.println(this.getClass().getSimpleName()+"created");
	}
	
	public void  printingNames()
	{
		// calling current class variable
		System.out.println(this.name);
		// calling parent class variable
		System.out.println(super.name);
	}
	
	
}
