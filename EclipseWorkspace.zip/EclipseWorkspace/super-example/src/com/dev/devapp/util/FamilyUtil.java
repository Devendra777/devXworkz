package com.dev.devapp.util;

import com.dev.devapp.appa.MagluAndMaga;

public class FamilyUtil {

	public static void main(String[] args) {
		
		MagluAndMaga  mandm = new MagluAndMaga();
		mandm.printingNames();
	}

}
