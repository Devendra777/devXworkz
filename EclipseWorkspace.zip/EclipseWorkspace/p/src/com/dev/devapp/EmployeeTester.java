package com.dev.devapp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class EmployeeTester {

	public static void main(String[] args) {

		List<Employee> employees = new ArrayList<Employee>();

		employees.add(null);
		employees.add(null);
		employees.add(new Employee(2,"Rohit"));
		employees.add(new Employee(2,"Rohit"));
		
	List<Employee> e = 	employees.stream().filter(e  -> (e != null).collect(Collectors.toList()));
     for (Employee employee : employees) {
		System.out.println(employee);
	}

	}
	
	
	
	     
	
	

}
