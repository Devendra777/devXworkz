package com.dev.devapp;

//Java implementation of the approach
import java.util.*;

class GFG
{
	 static int findMaximum(int arr[], int n, int k)
	    {
	        int res = 0, index = 0;
	 
	        for (int i = n - 1; i >= index; i--)
	        {
	            // Buy candy with maximum amount
	            res += arr[i];
	 
	            // And get k candies for free from
	            // the starting
	            index += k;
	        }
	        return res;
	    }
	 
	    // Driver code
	    public static void main(String[] args)
	    {
	        int arr[] = {26,20,23};
	        int n = arr.length;
	        int k = 2;
	        Arrays.sort(arr);
	 
	        // Function call
	        System.out.println(
	                           + findMaximum(arr, n, k));
	    }
	 
}

//This code is contributed by PrinciRaj1992

