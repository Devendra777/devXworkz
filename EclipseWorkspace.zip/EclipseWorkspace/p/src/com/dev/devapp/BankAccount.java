package com.dev.devapp;

import java.util.Scanner;

public class BankAccount {

	Scanner s = new Scanner(System.in);
	String name;
	String acctype;
	int accno;

	void getdata() {
		System.out.println("enter name");
		name = s.next();
		System.out.println("enter acctype");
		acctype = s.next();
		System.out.println("enter account no");
		accno = s.nextInt();
	}

	void putdata() {
		System.out.println("name is::" + name);
		System.out.println("acctype is::" + acctype);
		System.out.println("accno is::" + accno);
	}
}
