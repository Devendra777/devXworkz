package com.dev.devapp;

public class SavingsAccount extends BankAccount{
	 void deposit1()
	    {
	        int balance;
	        System.out.println("enter balance");
	        balance=s.nextInt();
	    }
	    
	    void deposit2()
	    {
	        int deposit_amt,savings;
	        System.out.println("enter deposit amt");
	        deposit_amt=s.nextInt();
	        System.out.println("enter savings");
	        savings=s.nextInt();
	        savings=savings+deposit_amt;
	        
	    }
	    void withdraw1()
	    {
	        int withdraw_amt1,saving1;
	        System.out.println("enter withdraw_amt");
	        withdraw_amt1=s.nextInt();
	        System.out.println("enter saving");
	        saving1=s.nextInt();
	        saving1=saving1-withdraw_amt1;
	        if(withdraw_amt1>saving1)
	        {
	            saving1=saving1+withdraw_amt1;
	            System.out.println("you can withdraw");
	        }
	        else
	        {
	            System.out.println("you cannot withdraw");
	        }
	    }
}
