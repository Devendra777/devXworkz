package com.dev.devapp;

public class DeadLockMain {
	
	
	public static void main(String[] args) {
		
		
		DeadLock deadLock = new DeadLock();
		 deadLock.start();
	   
		
		DeadLock1 deadLock1 = new DeadLock1();
		 deadLock1.start();
		
	}

}
