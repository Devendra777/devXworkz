package com.dev.devapp;

public class Employee {
	
	int emplId;
	String name ;
	
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}


	public Employee(int emplId, String name) {
		super();
		this.emplId = emplId;
		this.name = name;
	}


	public int getEmplId() {
		return emplId;
	}


	public void setEmplId(int emplId) {
		this.emplId = emplId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

}
