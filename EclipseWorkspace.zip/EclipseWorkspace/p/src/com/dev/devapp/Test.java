package com.dev.devapp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class Test {
	
	public Test() {

	System.out.println("");
	
	}
	
	public static void main(String[] args) {
		/*
		 * Test test = new Test(); System.out.println(test);
		 * 
		 * String s = "20"; int x = 10; System.out.println(x+s);
		 * 
		 * 
		 * List<Employee> employeeList = new ArrayList<Employee>();
		 * 
		 * employeeList.add(new Employee(111, "Jiya Brein", 32, "Female", "HR", 2011,
		 * 25000.0)); employeeList.add(new Employee(111, "Jiya Brein", 32, "Female",
		 * "HR", 2011, 25000.0)); employeeList.add(new Employee(133, "Martin Theron",
		 * 29, "Male", "Infrastructure", 2012, 18000.0)); employeeList.add(new
		 * Employee(144, "Murali Gowda", 28, "Male", "Product Development", 2014,
		 * 32500.0)); employeeList.add(new Employee(155, "Nima Roy", 27, "Female", "HR",
		 * 2013, 70000.0));
		 * 
		 * Optional<Double> emp = employeeList.stream().map(e ->
		 * e.salary).sorted(Comparator.reverseOrder()).skip(2).findFirst();
		 * System.out.println(emp.get());
		 * 
		 * 
		 * String ar[] = {"abc","2","0","0"}; List<String> list = Arrays.asList(ar);
		 * Collections.sort(list);
		 * 
		 * System.out.println(isNumber("78"));
		 * 
		 * 
		 * 
		 * String str = "Welcome to the world of Java"; int vcount=0 , count=0; str =
		 * str.toLowerCase(); for (int i = 0; i < str.length(); i++) { char ch=
		 * str.charAt(i); if(ch == 'a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' ) {
		 * vcount++;} else if(ch>='a' && ch<='z') { count++; } }
		 * System.out.println(vcount); System.out.println(count);
		 * 
		 * 
		 */
		
		try {
			int i ;
			return ;
			
		}catch(Exception e) {
			System.out.println("iiii");
		}finally {
			System.out.println("finally");
		}
	}
	    
	
	
	 private static  boolean isNumber(String value)
	    {
	        for (int i = 0; i < value.length(); i++)
	            if (Character.isDigit(value.charAt(i)) == false)
	                return false;
	 
	        return true;
	    }
	    

}
