package com.dev.devapp;

public class CurrentAccount extends BankAccount
{
    int balance;
    void deposit()
    {
        
        System.out.println("enter balance");
        balance=super.s.nextInt();
        
        
            int deposit;
            System.out.println("enter deposit");
            deposit=s.nextInt();
            balance=balance+deposit;
    }
    void withdraw()
    {
        int withdraw_amt;
        System.out.println("enter withdraw_amt");
        withdraw_amt=super.s.nextInt();
        balance=balance-withdraw_amt;
        if(withdraw_amt>balance)
        {
            balance=balance+withdraw_amt;
            System.out.println("You can withdraw");
        }
        else
        {
            System.out.println("you cannot withdraw");
        }
    }
    
	

}
