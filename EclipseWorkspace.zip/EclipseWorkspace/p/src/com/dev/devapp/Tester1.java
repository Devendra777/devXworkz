package com.dev.devapp;

public class Tester1
{
	   public static void main(String args[])

	   {

	       int [][] arr = {{5,10},{8,12}};

	       int sum=0,diff=0;

	       for(int i =0;i<arr.length;i++){

	           sum = sum +(arr[i][1]-arr[i][0]);

	           if(i<arr.length-1){

	               if(arr[i][1] > arr[i+1][0] || (arr[i][1] - arr[i+1][0]) == -1){

	                   diff = diff +(arr[i][1] - arr[i+1][0]);

	               }

	           }

	       }

	       System.out.println(sum-diff);

	   }
}
