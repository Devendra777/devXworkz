package com.dev.devapp;// Java implementation of simple
// algorithm to find smaller
// element on left side
import java.io.*;
class Testerrr {

// Prints smaller elements on
// left side of every element
static void printPrevSmaller(int []arr, int n)
{
	
	// Always print empty or '_'
	// for first element
	System.out.print( " -1, ");

	// Start from second element
	for (int i = 1; i < n; i++)
	{
		// look for smaller
		// element on left of 'i'
		int j ;
		for(j = i - 1; j >= 0; j--)
		{
			if (arr[j] < arr[i])
			{
				System.out.print(arr[j] + ", ");
				break;
			}
		}

		// If there is no smaller
		// element on left of 'i'
		if (j == -1)
		System.out.print( " -1, ") ;
	}
}

	// Driver Code
	public static void main (String[] args)
	{
		int []arr = {1 , 5 , 0 , 3, 4,5};
		int n = arr.length;
		printPrevSmaller(arr, n);
	}
}

// This code is contributed by anuj_67.
