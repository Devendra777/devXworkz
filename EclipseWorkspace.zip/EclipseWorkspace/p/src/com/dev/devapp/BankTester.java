package com.dev.devapp;

import java.util.Scanner;

public class BankTester {
	 public static void main(String args[])
	    {
	        Scanner s=new Scanner(System.in);
	        CurrentAccount cr=new CurrentAccount();
	        cr.getdata();
	        cr.putdata();
	        cr.deposit();
	        cr.withdraw();
	        SavingsAccount sr=new SavingsAccount();
	        sr.getdata();
	        sr.putdata();
	        sr.deposit2();
	        sr.withdraw1();
	        int ch;
	        System.out.println("enter ur choice");
	        ch=s.nextInt();
	        System.out.println("Enter 1 for current acc details");
	        System.out.println("Enter 2 for saving acc details");
	        switch(ch)
	        {
	            case 1:
	                    int choice;
	                   
	                    System.out.println("enter the choice");
	                    System.out.println("1.withdraw");
	                    System.out.println("2.deposite");
	                    choice=s.nextInt();
	                    switch(choice)
	                    {
	                        case 1:
	                                cr.withdraw();
	                                break;
	                        case 2:
	                                cr.deposit();
	                                break;
	                        default:
	                                System.out.println("wrong choice");
	                                break;
	                    }
	                break;
	            case 2:
	                    int choice1;
	                    System.out.println("1.withdraw1");
	                    System.out.println("2.deposite2");
	                    System.out.println("enter the choice");
	                    choice1=s.nextInt();
	                    switch(choice1)
	                    {
	                        case 1:
	                                sr.withdraw1();
	                                break;
	                        case 2:
	                                sr.deposit2();
	                                break;
	                        default:
	                                System.out.println("wrong choice");
	                                break;
	                    }
	 
	                break;
	            default:
	                System.out.println("u entered wrong choice");
	        }
	    }

}
