package com.xworkz.restaurantUtil;

import com.xworkz.restaurant.Party;
import com.xworkz.restaurant.Restaurant;

public class RestaurantUtil {

	public static void main(String[] args) {


		// Restaurant.serveFood();
		Restaurant restaurant = new Restaurant();
		restaurant.
	     Party party = new Party();
	    

		  String name = new  String("Stories");
		  name   = "stories 123";// 2 objects 
		  String name1= new String("ashoka");// 2 objects String name2= new String("Indrapastha");// 2 Objects
		  String name3= new String("nice dine");// 2 objects 
		  String name4= new String("old shanthisagar");// 2 objects
		  
		 // 
		  String name5="Stories";// 0 objects
		  String name6="nice dine";
		  String nam="Stories";
		
		

	}

}
