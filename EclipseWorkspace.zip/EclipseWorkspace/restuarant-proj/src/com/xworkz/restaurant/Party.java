package com.xworkz.restaurant;

public class Party {
	
	
	

}
