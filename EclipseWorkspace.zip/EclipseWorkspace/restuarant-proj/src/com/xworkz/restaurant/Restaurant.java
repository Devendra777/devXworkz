package com.xworkz.restaurant;

public class Restaurant {
	
	
	  
	  public static final  int id=90; 
	  //instance block or non-static block or init block orIIB(instance Initialization block) { id = 2345; System.out.println(id); }
	  //static block or class block or SIB (static Initialization block) 
	  static {
	  
	  } public void serveFood() {
	 
	  
	  System.out.println(id + "HiBye"); }
	 
	
	
	
	// literals
	  
	 
	
	
	
	
	
	
	
	
	

}
