package com.dev.devapp;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class DTHServiceProvider {
	// id , name , cost , plan

	public static void main(String[] args) {
		// Driver
		// there are 6 steps in JDBC
		Connection connection = null;
		try {

			// connection =
			// DriverManager.getConnection("jdbc:mysql://localhost:3306/Jokes?user=root&password=Rohith782912");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Jokes", "root", "Rohith782912");
			PreparedStatement stmt = connection.prepareStatement("SELECT * FROM agri_table");
		    ResultSet resultSet    = stmt.executeQuery();
		  DatabaseMetaData rd=  connection.getMetaData();
		  System.out.println(rd.getDriverVersion());
		  ResultSetMetaData metaData  =resultSet.getMetaData();
		  System.out.println(metaData.getColumnName(2));

			stmt.execute();
		} catch (SQLException e) {
		
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

}
