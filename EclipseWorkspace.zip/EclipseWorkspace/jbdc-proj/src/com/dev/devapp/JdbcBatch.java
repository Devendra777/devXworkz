package com.dev.devapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JdbcBatch {

	public static void main(String[] args) {

		// Driver
		// there are 6 steps in JDBC
		Connection connection  = null;
		Statement stmt = null;
		
		String query=" insert into dth values(67888,'hjhjhj',8000,'12 months')";
		String query1="insert into dth values(67889,'hjhjhj',8000,'12 months')";
		String query2="insert into dth values(67890,'hjhjhj',8000,'12 months')";
		String query3="insert into dth values(67891,'hjhjhj',8000,'12 months')";
		
		try {
			
			//connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Jokes?user=root&password=Rohith782912");
			connection=	DriverManager.getConnection("jdbc:mysql://localhost:3306/Jokes", "root", "Rohith782912");
			stmt= connection.createStatement();

			stmt.addBatch(query);
			
			stmt.addBatch(query1);
			stmt.addBatch(query2);
			stmt.addBatch(query3);
		
			stmt.executeBatch();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

}
