package com.dev.devapp;

import java.io.Serializable;
import java.util.List;

public class IPLDTO implements Serializable{

	private int noOfTeams;
	private List<String> listOfTeamNames;
	private int noOfPlypers;
	
	public IPLDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getNoOfTeams() {
		return noOfTeams;
	}

	public void setNoOfTeams(int noOfTeams) {
		this.noOfTeams = noOfTeams;
	}

	public List<String> getListOfTeamNames() {
		return listOfTeamNames;
	}

	public void setListOfTeamNames(List<String> listOfTeamNames) {
		this.listOfTeamNames = listOfTeamNames;
	}

	public int getNoOfPlypers() {
		return noOfPlypers;
	}

	public void setNoOfPlypers(int noOfPlypers) {
		this.noOfPlypers = noOfPlypers;
	}

}
