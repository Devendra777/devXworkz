package com.festival.festivalapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/cookie")
public class CookieServlet extends HttpServlet{
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		  
		  //4)fetching all the Cookie object back from the response header
		Cookie cookie2[]=   req.getCookies();
		
		
		
		//4) Fetch the session object back from the scope
		  HttpSession httpSession=  req.getSession(false);
		  
		String name= (String)  httpSession.getAttribute("name");
		
		PrintWriter printWriter = resp.getWriter();
		
		
		
		resp.setContentType("text/html");
		
		printWriter.print("Cookie Value" +   cookie2[0].getValue() );
		printWriter.print( "Session scope data" + "   " + name+ " "+httpSession.getId());
		  
	}
}
