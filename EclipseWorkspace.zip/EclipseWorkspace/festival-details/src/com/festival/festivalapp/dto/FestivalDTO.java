package com.festival.festivalapp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "festival_table")
public class FestivalDTO

{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "festival_id")
	private int festivalId;
	@Column(name = "festival_name")
	private String festivalName;
	@Column(name = "festival_month")
	private String festivalMonth;
	@Column(name = "no_of_days")
	private int noOfDays;

	public FestivalDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getFestivalId() {
		return festivalId;
	}

	public void setFestivalId(int festivalId) {
		this.festivalId = festivalId;
	}

	public String getFestivalName() {
		return festivalName;
	}

	public void setFestivalName(String festivalName) {
		this.festivalName = festivalName;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	public String getFestivalMonth() {
		return festivalMonth;
	}

	public void setFestivalMonth(String festivalMonth) {
		this.festivalMonth = festivalMonth;
	}

	@Override
	public String toString() {
		return "FestivalDTO [festivalId=" + festivalId + ", festivalName=" + festivalName + ", festivalMonth="
				+ festivalMonth + ", noOfDays=" + noOfDays + "]";
	}

}
