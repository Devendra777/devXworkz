package com.festival.festivalapp.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.festival.festivalapp.dto.FestivalDTO;
import com.xworkz.singleton.HibernateUtil;

public class FestivalDAOImpl implements FestivalDAO {

	@Override
	public void createFestival(FestivalDTO festivalDTO) {

		Session session = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.saveOrUpdate(festivalDTO);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.beginTransaction() != null) {
				session.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

		// TODO Auto-generated method stub

	}

	@Override
	public List<FestivalDTO> getAllFestivals() {
		return HibernateUtil.getSessionFactory().openSession().createCriteria(FestivalDTO.class).list();
	}

}
