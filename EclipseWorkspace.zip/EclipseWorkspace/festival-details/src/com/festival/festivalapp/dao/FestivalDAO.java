package com.festival.festivalapp.dao;

import java.util.List;

import com.festival.festivalapp.dto.FestivalDTO;

public interface FestivalDAO {
	
	
	public void createFestival(FestivalDTO festivalDTO);

	public List<FestivalDTO> getAllFestivals();

}
