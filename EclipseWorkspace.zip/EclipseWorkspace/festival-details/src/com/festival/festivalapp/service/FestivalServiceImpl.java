package com.festival.festivalapp.service;

import java.util.List;

import com.festival.festivalapp.dao.FestivalDAO;
import com.festival.festivalapp.dao.FestivalDAOImpl;
import com.festival.festivalapp.dto.FestivalDTO;

public class FestivalServiceImpl implements FestivalService {
	
	private FestivalDAO festivalDAO;
	
	public FestivalServiceImpl() {
		// TODO Auto-generated constructor stub
		
		festivalDAO = new FestivalDAOImpl();
	}

	@Override
	public void validateAndSave(FestivalDTO festivalDTO) {
		if(festivalDTO != null)
		{
			festivalDAO.createFestival(festivalDTO);
		}
		// TODO Auto-generated method stub

	}

	@Override
	public List<FestivalDTO> getAllFestivals() {
		// TODO Auto-generated method stub
		return festivalDAO.getAllFestivals();
	}

}
