package com.festival.festivalapp.service;

import java.util.List;

import com.festival.festivalapp.dto.FestivalDTO;

public interface FestivalService {

	public void validateAndSave(FestivalDTO festivalDTO);
	
	public List<FestivalDTO> getAllFestivals();
	
	
	

}
