package com.festival.festivalapp;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.festival.festivalapp.dto.FestivalDTO;
import com.festival.festivalapp.service.FestivalService;
import com.festival.festivalapp.service.FestivalServiceImpl;


@WebServlet(urlPatterns="/festival" , loadOnStartup=24)
public class FestivalServlet  extends HttpServlet{
	
	public FestivalServlet() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	
		
		
	String name = 	req.getParameter("festivalName");
	String festivalMonth = 	req.getParameter("festivalMonth");
	String noOfDays=	req.getParameter("noOfDays");
	
	FestivalDTO festivalDTO = new FestivalDTO();
	   festivalDTO.setFestivalName(name);
	   festivalDTO.setFestivalMonth(festivalMonth);
	   festivalDTO.setNoOfDays(Integer.parseInt(noOfDays));
	   
	   FestivalService festivalService = new FestivalServiceImpl();
	   festivalService.validateAndSave(festivalDTO);
	   
	   
	  List<FestivalDTO> dtos =  festivalService.getAllFestivals();
	  dtos.forEach(System.out::println);
	  
	  
	
	  
	  
	  
	  
	  
		//1) Get the reference of Session Object 
		HttpSession httpSession = req.getSession();
		
		//2)Set the age for Session Object 
		httpSession.setMaxInactiveInterval(200);
		
	     //3) Add the session object into the scope
		httpSession.setAttribute("name", name);
	  
		
		
		
		  
		  //Cookie information
		  //1 ) Create an object of Cookie class
		  Cookie cookie = new Cookie("name", httpSession.getId());
		    
		  //2)set the age for a cookie
		  cookie.setMaxAge(5000);
		  
	     //3) Add the cookie into Response Header
		  resp.addCookie(cookie);
		  
	  

	  
	 // req.setAttribute("listOfFestivals", dtos);
	  RequestDispatcher dispatcher = req.getRequestDispatcher("cookie");
	  dispatcher.forward(req, resp);
	
	}

}
