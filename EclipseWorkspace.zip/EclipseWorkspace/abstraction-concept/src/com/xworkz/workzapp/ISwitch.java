package com.xworkz.workzapp;

public interface ISwitch {

	void sOn();

	void sOff();
	
	
}
