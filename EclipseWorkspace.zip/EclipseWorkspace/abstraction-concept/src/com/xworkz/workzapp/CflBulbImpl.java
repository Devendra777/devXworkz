package com.xworkz.workzapp;

//implementation class
public class CflBulbImpl implements ISwitch{

	@Override
	public void sOn() {
		// TODO Auto-generated method stub
		System.out.println("Cfl Bulb turned On");
	}

	@Override
	public void sOff() {
		// TODO Auto-generated method stub
		System.out.println("Cfl Bulb turned off");
	}

}
