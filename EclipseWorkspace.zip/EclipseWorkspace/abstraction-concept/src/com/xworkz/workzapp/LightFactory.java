package com.xworkz.workzapp;


//Factory class - contains object creation logic
public class LightFactory {
	
	
	//factory method / helper method
public static 	ISwitch getLight(String type)
	{
		if(type.equalsIgnoreCase("tubelight"))
		{
			return new TubeLightImpl();
		}
		else if(type.equalsIgnoreCase("cflBulb"))
		{
			return new CflBulbImpl();
		}
		else {
			System.out.println("No light found");
			return null;
		}
	}

}
