package com.xworkz.workzapp;

public class TubeLightImpl implements  ISwitch{

	@Override
	public void sOn() {
		// TODO Auto-generated method stub
		System.out.println("Tube Light turned On");
	}

	@Override
	public void sOff() {
		// TODO Auto-generated method stub
		System.out.println("Tube Light turned off");
	}

	

}
