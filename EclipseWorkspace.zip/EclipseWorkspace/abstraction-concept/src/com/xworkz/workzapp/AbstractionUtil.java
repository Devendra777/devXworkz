package com.xworkz.workzapp;

public class AbstractionUtil {

	public static void main(String[] args) {

		ISwitch iSwitch = LightFactory.getLight("disco");
		if (iSwitch != null) {
			iSwitch.sOn();
			iSwitch.sOff();
		}
	}

}
