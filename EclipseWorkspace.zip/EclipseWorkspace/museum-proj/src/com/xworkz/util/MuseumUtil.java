package com.xworkz.util;

import com.xworkz.museum.Museum;

public class MuseumUtil {

	public static void main(String[] args) {

		Museum museum = new Museum(1,"","");
		Museum museum = new Museum(1,"","");
		Museum museum = new Museum(1,"","");
		Museum museum = new Museum(1,"","");
		Museum museum = new Museum(1,"","");
	
		System.out.println(museum.id + " " + museum.name + " " + museum.address);
	}

}
