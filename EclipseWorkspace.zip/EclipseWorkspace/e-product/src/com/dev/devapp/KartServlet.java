package com.dev.devapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/kart")
public class KartServlet extends HttpServlet{
	
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	   
	// get back the data from the req scope
 String productName = (String) req.getAttribute("pn");
 String productQty = (String) req.getAttribute("pQty");
 String price = (String) req.getAttribute("pc");
 
       double totalSum = Double.parseDouble(price) * Integer.parseInt(productQty);
       
       
       PrintWriter printWriter = resp.getWriter();
       resp.setContentType("text/html");
       printWriter.print("Product Details " + productName +"    "   +  totalSum);
       
       
       
 
}

}
