package com.dev.devapp;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/product", loadOnStartup = 90)
public class ProductServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String productName = req.getParameter("productName");
		String productQty = req.getParameter("productQty");
		String price = req.getParameter("price");
		
		// Adding data into the request scope
		   req.setAttribute("pn",productName );
		   req.setAttribute("pQty", productQty);
		   req.setAttribute("pc", price);
		
		//servlet chaining
		RequestDispatcher dispatcher  = req.getRequestDispatcher("kart");
	//	dispatcher.forward(req, resp);
		dispatcher.include(req, resp);
		
	
        //sendRedirect
	}

}
