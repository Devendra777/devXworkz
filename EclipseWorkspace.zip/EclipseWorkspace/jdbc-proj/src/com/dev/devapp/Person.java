package com.dev.devapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Person {
	
	
	


	// id , name , age , gender

	public static void main(String[] args) {
				/*
		 * String sql = "insert into person_details values(34, 'Tintin', '67','M')";
		 * String update =
		 * "update person_details set person_gender='28' where person_id=6"; String
		 * delete = "delete from  person_details where person_id=2";
		 */
		String sqlQuery = "select * from person_details";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "Rohith782912");

			Statement stmt = con.createStatement();
			/*
			 * stmt.addBatch(sql); stmt.addBatch(update); stmt.addBatch(delete);
			 */
			ResultSet resultSet = stmt.executeQuery(sqlQuery);
			while (resultSet.next()) {
				int personId = resultSet.getInt("person_id");
				String name = resultSet.getString("person_name");
				String address = resultSet.getString("person_age");
				String gender = resultSet.getString("person_gender");
				System.out.println(personId + " " + name + " " + address + " " + gender);
			}

			stmt.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}

	}
}
