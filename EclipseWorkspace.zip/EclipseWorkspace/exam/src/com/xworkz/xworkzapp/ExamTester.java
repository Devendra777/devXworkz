package com.xworkz.xworkzapp;

import com.xworkz.xworkzapp.exam.Exam;
import com.xworkz.xworkzapp.exam.HallTicket;
import com.xworkz.xworkzapp.exam.SupplementaryExam;

public class ExamTester {

	public static void main(String[] args) {

		Exam exam = new Exam();
		exam.setExamCode("15CS53");
		exam.setFees(1000);
		System.out.println(Exam.universityName);

		HallTicket hallTicket = 
				new HallTicket("Ranjitha", "1RR16CS121", "155CSC");
        hallTicket.displayInfo();
		//exam.allow(hallTicket);
		
        // polymorphism
		Exam exam2 = new SupplementaryExam();
		exam2.allow(hallTicket);
		
		
		
	}

}
