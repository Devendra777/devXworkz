package com.xworkz.xworkzapp.exam;


// child class or derived class or sub class
public class SupplementaryExam extends Exam{

	
	@Override
	public void allow(HallTicket ticket) {

	this.allow(ticket);

	}

}
