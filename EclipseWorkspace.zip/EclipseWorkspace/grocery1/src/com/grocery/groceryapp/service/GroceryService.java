package com.grocery.groceryapp.service;

import com.grocery.groceryapp.dto.GroceryDTO;

public interface GroceryService {
	
	public boolean validateAndCreateGrocery(GroceryDTO groceryDTO);

}
