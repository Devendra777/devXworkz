package com.grocery.groceryapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.groceryapp.dao.GroceryDAO;
import com.grocery.groceryapp.dto.GroceryDTO;

@Service
public class GroceryServiceImpl implements GroceryService{
	

	@Autowired
	private GroceryDAO dao;
	
	public GroceryServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean validateAndCreateGrocery(GroceryDTO groceryDTO) {
	return dao.saveGrocery(groceryDTO);
	}

}
