package com.grocery.groceryapp.dao;

import com.grocery.groceryapp.dto.GroceryDTO;

public interface GroceryDAO {
	
	
	public boolean saveGrocery(GroceryDTO dto);
	}
