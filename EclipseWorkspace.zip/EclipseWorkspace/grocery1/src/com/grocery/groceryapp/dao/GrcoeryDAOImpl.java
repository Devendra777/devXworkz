package com.grocery.groceryapp.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.grocery.groceryapp.dto.GroceryDTO;

@Repository
public class GrcoeryDAOImpl implements GroceryDAO{
	
	
	private SessionFactory factory;

	@Override
	public boolean saveGrocery(GroceryDTO dto) {
		// TODO Auto-generated method stub
		return false;
	}

}
