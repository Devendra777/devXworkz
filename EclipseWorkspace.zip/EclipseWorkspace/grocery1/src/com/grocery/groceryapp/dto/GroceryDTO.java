package com.grocery.groceryapp.dto;



public class GroceryDTO {

	private String groceryName;
	private String groceryQuantity;
	private String groceryPrice;
	private String mfgDate;

	public String getGroceryName() {
		return groceryName;
	}

	public void setGroceryName(String groceryName) {
		this.groceryName = groceryName;
	}

	public String getGroceryQuantity() {
		return groceryQuantity;
	}

	public void setGroceryQuantity(String groceryQuantity) {
		this.groceryQuantity = groceryQuantity;
	}

	public String getGroceryPrice() {
		return groceryPrice;
	}

	public void setGroceryPrice(String groceryPrice) {
		this.groceryPrice = groceryPrice;
	}

	public String getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(String mfgDate) {
		this.mfgDate = mfgDate;
	}
}
