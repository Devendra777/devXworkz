package com.xworkz.bloodbank.dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import static com.xworkz.bloodbank.constants.Constants.DRIVER_CLASS_NAME;
import static com.xworkz.bloodbank.constants.Constants.URL;
import static com.xworkz.bloodbank.constants.Constants.INSERT_QUERY;
import static com.xworkz.bloodbank.constants.Constants.UPDATE_AGE_BY_DONOR_NAME;
import com.xworkz.bloodbank.dto.BloodBankDTO;

public class BloodBankDAOImpl implements BloodBankDAO {

	// global
	private static Connection con = null;

	private Connection getConnection() {

		try {
			Class.forName(DRIVER_CLASS_NAME);
			con = DriverManager.getConnection(URL);
			con.setAutoCommit(false);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	private void closeConnection() {
		System.out.println("Closing out the connection");
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/// ACID - Atomicity , COnsistence , Isolation , Durability
	@Override
	public void createBloodBank(BloodBankDTO bankDTO) throws ClassNotFoundException, SQLException {
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = getConnection().prepareStatement(INSERT_QUERY);
         
			preparedStatement.setInt(1, bankDTO.getBloodBankId());
			preparedStatement.setString(2, bankDTO.getDonorName());
			preparedStatement.setInt(3, bankDTO.getDonorAge());
			preparedStatement.setLong(4, bankDTO.getContactNo());
			preparedStatement.setBoolean(5, bankDTO.isSmoker());
			preparedStatement.setString(6, bankDTO.getBloodBankLocation());
			preparedStatement.executeUpdate();

			con.commit();
		} catch (Exception e) {
			con.rollback();
		} finally {
			preparedStatement.close();
			closeConnection();
		}

	}

	@Override
	public void updateAgeByName(int age, String donorName) throws ClassNotFoundException, SQLException {
		PreparedStatement preparedStatement = null;
		try {
			System.out.println("inside updateAgeByName() method");
			preparedStatement = getConnection().prepareStatement(UPDATE_AGE_BY_DONOR_NAME);
			preparedStatement.setInt(1, age);
			preparedStatement.setString(2, donorName);
			preparedStatement.executeUpdate();
			con.commit();
		} catch (Exception e) {
			con.rollback();
		} finally {
			preparedStatement.close();
			closeConnection();
		}

	}

}
