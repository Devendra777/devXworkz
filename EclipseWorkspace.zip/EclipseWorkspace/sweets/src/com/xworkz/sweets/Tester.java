package com.xworkz.sweets;

import com.xworkz.sweets.dto.SweetsDTO;
import com.xworkz.sweets.service.SweetsService;
import com.xworkz.sweets.service.SweetsServiceImpl;

public class Tester {
	
	
	public static void main(String[] args) {
		
		SweetsDTO sweetsDTO = new SweetsDTO();
		sweetsDTO.setSweetsId(1);
		sweetsDTO.setSweetsName("Kaaju Barfi");
		sweetsDTO.setShape("diamond");
		sweetsDTO.setPrice(800.00);
		sweetsDTO.setColor("milky white");
		
		
	SweetsService	sweetsService = new SweetsServiceImpl();
		sweetsService.validateAndCreateSweets(sweetsDTO);
	}

}
