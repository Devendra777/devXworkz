package com.xworkz.sweets.service;

import com.xworkz.sweets.dao.SweetsDAO;
import com.xworkz.sweets.dao.SweetsDAOImpl;
import com.xworkz.sweets.dto.SweetsDTO;

public class SweetsServiceImpl implements SweetsService {
	
	private SweetsDAO sweetsDAO;
	
	public SweetsServiceImpl() {
		// TODO Auto-generated constructor stub
		sweetsDAO = new SweetsDAOImpl();
	}

	@Override
	public void validateAndCreateSweets(SweetsDTO sweetsDTO) {
		// TODO Auto-generated method stub
		if(sweetsDTO !=null) {
			sweetsDAO.createSweets(sweetsDTO);
			
		}
		
		
		

	}

}
