package com.xworkz.sweets.service;

import com.xworkz.sweets.dto.SweetsDTO;

public interface SweetsService {
	
	public void validateAndCreateSweets(SweetsDTO sweetsDTO ) ;

}
