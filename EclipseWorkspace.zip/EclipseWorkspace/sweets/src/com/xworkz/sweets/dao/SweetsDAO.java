package com.xworkz.sweets.dao;

import com.xworkz.sweets.dto.SweetsDTO;

public interface SweetsDAO {
	
	
	public void createSweets(SweetsDTO sweetsDTO);

}
