package com.xworkz.sweets.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.xworkz.sweets.dto.SweetsDTO;

public class SweetsDAOImpl implements SweetsDAO {

	public SweetsDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createSweets(SweetsDTO sweetsDTO) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;
		try {
			Configuration configuration = new Configuration();
			configuration.configure("resources/dev.xml");
			configuration.addAnnotatedClass(SweetsDTO.class);
			factory = configuration.buildSessionFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(sweetsDTO);
			transaction.commit();
		} catch (HibernateException e) {
			if (transaction != null) {
			}
			transaction.rollback();
		} finally {
			if (session != null) {
			session.close();
		    }
		  if (factory != null) {
		factory.close();
		  }

	}
	}
}
