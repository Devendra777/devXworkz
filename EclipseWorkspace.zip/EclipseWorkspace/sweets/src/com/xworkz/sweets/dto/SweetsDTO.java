package com.xworkz.sweets.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="sweets_table")
public class SweetsDTO implements Serializable {

	@Id
	@Column(name="sweets_id")
	private int sweetsId;
	@Column(name="sweets_name")
	private String sweetsName;
	@Column(name="sweets_color")
	private String color;
	@Column(name="sweets_price")
	private double price;
	@Column(name="sweets_shape")
	private String shape;

	public SweetsDTO() {
		System.out.println(this.getClass().getSimpleName()+" created");
		// TODO Auto-generated constructor stub
	}

	public int getSweetsId() {
		return sweetsId;
	}

	public void setSweetsId(int sweetsId) {
		this.sweetsId = sweetsId;
	}

	public String getSweetsName() {
		return sweetsName;
	}

	public void setSweetsName(String sweetsName) {
		this.sweetsName = sweetsName;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getShape() {
		return shape;
	}

	public void setShape(String shape) {
		this.shape = shape;
	}

}
