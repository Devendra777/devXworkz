package org.dev.devapp;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/ep")
public class ElectronicServlet extends GenericServlet{

	
	
	@Override
	public  void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
	
	Product pro = new Product();
	pro.id=23445;
	pro.name="Ear phone";
	pro.price=100.00;
	pro.brand="majestic";
	
  ServletOutputStream servletOutputStream=	resp.getOutputStream();
  servletOutputStream.print("welcome " + pro.name);
	
	
	}


	
}
