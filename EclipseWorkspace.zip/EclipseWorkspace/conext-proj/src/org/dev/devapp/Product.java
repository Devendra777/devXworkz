package org.dev.devapp;

public class Product {
	
	public int id;
	public String name;
	public String brand;
	public double price;
	

}
