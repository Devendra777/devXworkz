package com.dev.devapp;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

public class Song {
	
	
	public static void main(String[] args) {
		Connection connection = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection= 	DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=Rohith782912");
		DatabaseMetaData data = connection.getMetaData();
		  System.out.println(data.g);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
