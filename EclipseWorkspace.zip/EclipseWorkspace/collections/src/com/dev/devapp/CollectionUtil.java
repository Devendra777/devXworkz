package com.dev.devapp;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class CollectionUtil {

	public static void main(String[] args) {
		
		
		List<String> list = new LinkedList<String>();
		list.add("baba");
		list.add("wolf");
		list.add("farm");
		list.add("resort");
		list.add("wonderla");
		
		list.forEach(System.out::println);
		System.out.println("--------------------------");
		Collections.sort(list);
		
		list.forEach(System.out::println);
		
		System.out.println("----------------------------");
		Collections.reverse(list);
		list.forEach(System.out::println);
		
	
		// Abtraction
	/*	Set<BookDTO> collection = new HashSet<BookDTO>();
	
		List<BookDTO> collection1 = new LinkedList<BookDTO>();
		collection1.addAll(collection);
		collection.removeAll(collection);
		// Abstraction
		Iterator<BookDTO> itr = collection.iterator();

		while (itr.hasNext()) {
			Object object = itr.next();
			System.out.println(object);
		}

		Iterator<BookDTO> itr1 = collection1.iterator();

		while (itr1.hasNext()) {
			Object object = itr1.next();
			System.out.println(object);
		}
	}*/
	}

}
