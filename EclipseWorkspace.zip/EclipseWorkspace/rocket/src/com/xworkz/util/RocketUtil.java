package com.xworkz.util;

import java.util.Date;
import com.xworkz.rocket.*;

public class RocketUtil {

	public static void main(String[] args) {

		Rocket rocket = new Rocket();
	
		rocket.setName("PSLV");
		rocket.setId(23456);
		rocket.setDate(new Date());
		System.out.println(rocket.getName() + " " + rocket.getDate() + " " + rocket.getId());

	}
}