package com.xworkz.rocket;

public class Jet {
	
	
	public static void main(String[] args) {
		
		
		Rocket  rocket = new Rocket();
	
	}

}
