package com.xworkz.rocket;

import java.util.Date;

 public class Rocket {

	 String name;
	 int id;
	 Date date;

	public Rocket() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
