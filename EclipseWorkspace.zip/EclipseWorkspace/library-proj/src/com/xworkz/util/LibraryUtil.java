package com.xworkz.util;

import com.xworkz.library.Library;

public class LibraryUtil {
	
	
	
	public static void main(String[] args) {
		
		String [] sectionsByAuthors = {"Abdul Kalam","Sudamurti"};
		
		Library library = new Library("Gnanagangotri", sectionsByAuthors, "private");
		for (String sectionsByAuthor : sectionsByAuthors) {
			System.out.println(sectionsByAuthor);
		}
		System.out.println(library.name + " "+ library.type);
	}

}
