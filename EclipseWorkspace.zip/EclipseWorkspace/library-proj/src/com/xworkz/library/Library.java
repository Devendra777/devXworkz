package com.xworkz.library;

public class Library {

	public String name;
	public String[] sectionsByAuthor;
	public String type;

	public Library(String name, String[] sectionsByAuthor, String type) {
		this.name = name;
		this.sectionsByAuthor = sectionsByAuthor;
		this.type = type;
	}

}
