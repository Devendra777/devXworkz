package com.xworkz.xworkzapp.icecream;

public class IceCream {

	private String type;
	private double cost;
	

	public void setType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public double getCost() {
		return cost;
	}

}
