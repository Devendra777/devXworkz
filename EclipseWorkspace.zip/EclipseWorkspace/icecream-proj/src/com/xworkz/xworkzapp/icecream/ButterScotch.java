package com.xworkz.xworkzapp.icecream;

public class ButterScotch extends IceCream{

}
