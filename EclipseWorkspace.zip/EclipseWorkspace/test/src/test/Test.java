package test;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

public class Test  {

	private static final SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
           
	
	
	public static void main(String[] args) {
		
		
	
		int i =10;
		
		 String s1 ="null";
		String s2 ="null";
		System.out.println(s1 == s2);  
		
		
		
		
		
		Set<String> st = new HashSet<String>();
		st.add("");
		
		
		/*
		 * String ds1 = "2018-01-25"; SimpleDateFormat sdf1 = new
		 * SimpleDateFormat("yyyy-MM-dd"); SimpleDateFormat sdf2 = new
		 * SimpleDateFormat("MM-dd-yyyy"); String ds2; try { ds2 =
		 * sdf2.format(sdf1.parse(ds1)); System.out.println(ds2); } catch
		 * (ParseException e) { // TODO Auto-generated catch block e.printStackTrace();
		 * } // will be 30/06/2007 String phNm = "9988776655";
		 * 
		 * long i = Long.valueOf(phNm); System.out.println(i);
		 */
		
	
	}

}
