package com.wolken.wolkenapp.iswitch;

public interface ISwitch {

	//abstract methods
	// void sOn();

	 void sOff();
	  void sOn();
	

}
