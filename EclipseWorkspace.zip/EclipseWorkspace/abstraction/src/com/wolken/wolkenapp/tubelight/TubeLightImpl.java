package com.wolken.wolkenapp.tubelight;

import com.wolken.wolkenapp.iswitch.ISwitch;
// Implementation class - contains Implementation logic
public class TubeLightImpl implements ISwitch{

	@Override
	public void sOn() {
		// TODO Auto-generated method stub
		System.out.println("Tube Light is turned On");
	}

	@Override
	public void sOff() {
		// TODO Auto-generated method stub
		System.out.println("Tube Light is turned Off");
	}

}
