package com.wolken.wolkenapp.led;

import com.wolken.wolkenapp.iswitch.ISwitch;

public class LedLightImpl  implements ISwitch{

	@Override
	public void sOff() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sOn() {
		// TODO Auto-generated method stub
		
	}


}
