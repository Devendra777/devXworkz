package com.wolken.wolkenapp.led;

import com.wolken.wolkenapp.iswitch.ISwitch;

public abstract class LedLight implements ISwitch{

	
}
