package com.wolken.wolkenapp;

import java.util.Scanner;

import com.wolken.wolkenapp.factory.LightFactory;
import com.wolken.wolkenapp.iswitch.ISwitch;
import com.wolken.wolkenapp.led.LedLight;
import com.wolken.wolkenapp.led.LedLightImpl;

public class LightUtil {
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the light");
	String type=	scanner.next();
	
		//Abstraction
		ISwitch iSwitch =LightFactory.getLight(type);
		if(iSwitch != null)
		{
		iSwitch.sOn();
		iSwitch.sOff();
		}
		
		//partial Abstraction
		ISwitch led  =new LedLightImpl();
	}

}
