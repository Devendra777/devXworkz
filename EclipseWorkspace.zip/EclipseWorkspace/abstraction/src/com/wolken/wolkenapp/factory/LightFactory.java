package com.wolken.wolkenapp.factory;

import com.wolken.wolkenapp.iswitch.ISwitch;
import com.wolken.wolkenapp.led.LedLightImpl;
import com.wolken.wolkenapp.tubelight.TubeLightImpl;

//Factory class  --- Object creation logic
public class LightFactory {

	// factory methods
	public static ISwitch getLight(String type) {

		if (type.equalsIgnoreCase("tubelight")) {
			return new TubeLightImpl();

		} else if (type.equalsIgnoreCase("ledlight")) {
			return new LedLightImpl();
		} else {
			System.out.println("No Light Found");
		}
		return null;

	}

}
