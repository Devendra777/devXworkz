package com.workz.workzapp.movies;

public class MovieDTO {

	private int movieId;
	private String movieName;

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	
	public int getMovieId() {
		return movieId;
	}
	
	public String getMovieName() {
		return movieName;
	}
}
