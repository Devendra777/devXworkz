package com.workz.workzapp;

import com.workz.workzapp.movies.MovieDTO;
import com.workz.workzapp.movies.MovieOperation;

public class MovieTesterr {

	public static void main(String[] args) {

		MovieOperation movieOperation = new MovieOperation(2);
		MovieDTO hudugaru = new MovieDTO();
		hudugaru.setMovieId(1);
		hudugaru.setMovieName("Hudugaru");
		
		MovieDTO master = new MovieDTO();
		master.setMovieId(2);
		master.setMovieName("Master");

		movieOperation.addMovie(hudugaru);
		movieOperation.addMovie(master);

		movieOperation.getMovie();
		
		
		 

	}

}
