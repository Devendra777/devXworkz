package com.wolken.wolkenapp;

import com.wolken.wolkenapp.dto.ElectronicProductsDTO;

public class ElecronicTester {
	
	
	public static void main(String[] args) {
	
		ElectronicProductsDTO dto = new ElectronicProductsDTO();
		
		dto.setProductId(123);
		dto.setProductName("Grinder");
		dto.setPrice(1000.00);
		dto.setRatings(3.0);
		dto.setType("Home Appliances");
		System.out.println(dto);
		
		ElectronicProductsDTO dto1 = new ElectronicProductsDTO();
		
		dto1.setProductId(123);
		dto1.setProductName("Mixxer");
		dto1.setPrice(3000.00);
		dto1.setRatings(4.0);
		dto1.setType("Home Appliances");
		System.out.println(dto1);
		System.out.println(dto.hashCode());
		System.out.println(dto1.hashCode());
		System.out.println(dto.equals(dto1));

	}

}
