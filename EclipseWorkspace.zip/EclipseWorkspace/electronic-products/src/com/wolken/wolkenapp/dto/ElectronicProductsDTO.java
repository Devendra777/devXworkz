package com.wolken.wolkenapp.dto;

public class ElectronicProductsDTO {

	private Integer productId;
	private String productName;
	public Double price;
	private String type;
	private Double ratings;

	public ElectronicProductsDTO() { // TODO Auto-generated constructor stub
		System.out.println(this.getClass().getSimpleName() + " Object is created");

	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setRatings(Double ratings) {
		this.ratings = ratings;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Double getPrice() {
		return price;
	}

	public String getProductName() {
		return productName;
	}

	public Double getRatings() {
		return ratings;
	}

	public String getType() {
		return type;
	}

	@Override
	public String toString() {
		return "ElectronicProductsDTO [productId=" + productId + ", productName=" + productName + ", price=" + price
				+ ", type=" + type + ", ratings=" + ratings + "]";
	}

	@Override
	public boolean equals(Object obj) { // down casting
		ElectronicProductsDTO dto = (ElectronicProductsDTO) obj;
		if (obj == null) {
			return false;
		} else {
			if (obj != null) {
				if (obj instanceof ElectronicProductsDTO) {
					if (this.hashCode() == dto.hashCode() && this.price.equals(dto.price)) {
						return true;
					}
				}
			}
		}
		return false;

	}

	@Override
	public int hashCode() {
		return productId;
	}

}
