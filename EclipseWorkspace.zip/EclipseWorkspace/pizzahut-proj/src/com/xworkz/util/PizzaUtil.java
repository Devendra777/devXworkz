package com.xworkz.util;

import java.util.Scanner;


import com.xworkz.pizza.PizzaHut;

public class PizzaUtil {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the address");
		String address=sc.next();
		System.out.println("Enter the type Of Pizzas");
		String typeOfPizzas=sc.next();
		System.out.println("Enter the Price");
		double price=sc.nextDouble();
		sc.close();
		PizzaHut pizzaHut = new PizzaHut(address,typeOfPizzas, price);
		System.out.println(pizzaHut.address);
		
	}

}
