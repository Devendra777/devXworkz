package com.xworkz.pizza;

public class PizzaHut {

	// instance variables(states or attributes or properties)
	public String address;
	public String typeOfPizzas;
	public double price;

	public PizzaHut(String address, String typeOfPizzas, double price) {

		System.out.println("inside two parametrized const");
		this.address = address;
		this.typeOfPizzas = typeOfPizzas;
		System.out.println("ending with  two parametrized const");

	}

}
