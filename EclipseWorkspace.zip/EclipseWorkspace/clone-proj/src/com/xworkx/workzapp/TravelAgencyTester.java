package com.xworkx.workzapp;

import com.xworkx.workzapp.cloning.TravelAgency;

public class TravelAgencyTester {

	public static void main(String[] args) throws CloneNotSupportedException {

		TravelAgency agency = new TravelAgency(1, "Sanjana Travel Agency", "Navrang");
		System.out.println(agency);
		TravelAgency agency2 = (TravelAgency) agency.clone();
		agency2.setAddress("Vijayanagar");
		agency2.setId(4);
		agency2.setName("Mama");
		System.out.println(agency2);
	}
}
