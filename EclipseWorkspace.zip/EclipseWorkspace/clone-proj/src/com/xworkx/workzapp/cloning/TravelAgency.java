package com.xworkx.workzapp.cloning;

public  class TravelAgency  implements CustomClonable  {
	
	private int id;
	private String name;
	private String address;

	public TravelAgency(int id , String name , String address)
	{
		this.id =id;
		this.name=name;
		this.address= address;
	}
	
	
	public void setAddress(String address) {
		this.address = address;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getAddress() {
		return address;
	}
	
	public String getName() {
		return name;
	}
	
	public int getId() {
		return id;
	}


	@Override
	public String toString() {
		return "TravelAgency [id=" + id + ", name=" + name + ", address=" + address + "]";
	}

@Override
public Object clone() throws CloneNotSupportedException {
	// TODO Auto-generated method stub
	return super.clone();
}
	

}
