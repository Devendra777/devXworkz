package com.xworkx.workzapp.cloning;

public interface CustomClonable extends Cloneable{

}
