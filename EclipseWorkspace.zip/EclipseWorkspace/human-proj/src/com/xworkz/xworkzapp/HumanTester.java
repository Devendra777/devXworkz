package com.xworkz.xworkzapp;

public class HumanTester {
	
	public static void main(String[] args) {
		
		
		Human avatar  = new Human();
		avatar.setAdharNumber(101);
		avatar.setAge(34);
		avatar.setName("Avatar");
		

		Human agastya  = new Human();
		agastya.setAdharNumber(102);
		agastya.setAge(34);
		agastya.setName("Agastya");

		Human arjun  = new Human();
		arjun.setAdharNumber(103);
		arjun.setAge(34);
		arjun.setName("Arjun");

		Human seema  = new Human();
		seema.setAdharNumber(104);
		seema.setAge(9);
		seema.setName("Seema");

		Human emma  = new Human();
		emma.setAdharNumber(105);
		emma.setAge(25);
		emma.setName("Emma watson");
		
		System.out.println(avatar.toString());
		System.out.println(arjun.toString());
		System.out.println(agastya.toString());
		System.out.println(seema.toString());
		System.out.println(emma.toString());
		
		Object pandu="Pandu";
		
		System.out.println(avatar.equals(pandu));
		
		
		// memorylocation *31 +1
	}

	
	
}
