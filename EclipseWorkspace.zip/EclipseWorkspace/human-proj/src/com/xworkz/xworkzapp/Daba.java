package com.xworkz.xworkzapp;

public class Daba {
	
	public static void main(String[] args) {
		Daba object  = new Daba();
		System.out.println(object.toString());
	}

	
}
