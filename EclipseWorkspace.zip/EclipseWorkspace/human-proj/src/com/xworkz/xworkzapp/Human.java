package com.xworkz.xworkzapp;

public class Human {

	private String name;
	private int age;
	private long adharNumber;

	public Human() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public  String toString() {
		return "Human [name=" + name + ", age=" + age + "]";
	}

	public long getAdharNumber() {
		return adharNumber;
	}

	public void setAdharNumber(long adharNumber) {
		this.adharNumber = adharNumber;
	}
	/*
	 * @Override public int hashCode() { // TODO Auto-generated method stub return
	 * return (int) adharNumber; }
	 */

	@Override
	public boolean equals(Object obj) {

		if (obj instanceof Human) {
			return true;
		}
		return false;

	}

}
