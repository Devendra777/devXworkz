package com.dev.devapp.industry;

public class SteelIndustry extends Industry{

	public SteelIndustry(String type, int noOfWorkers, String area) {
		super(type, noOfWorkers, area);
		// TODO Auto-generated constructor stub
	}
	
	
	
	/*
	 * public SteelIndustry(String type, int noOfWorkers, String area) { super(type
	 * , 11 , area); }
	 */
		
      

}
