package com.dev.devapp.util;

import com.dev.devapp.industry.SteelIndustry;

public class IndustryUtil {

	public static void main(String[] args) {
		
		SteelIndustry industry = new SteelIndustry();
		industry.setArea("HSR Layout");
		industry.setNoOfWorkers(34);
		industry.setType("sales");
	
		System.out.println(industry.getType() +  " "+ industry.getNoOfWorkers()
				+ " "+ industry.getArea());
	}
}
