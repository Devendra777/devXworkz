package com.dev.devapp;

public class MovieOperation {

	private Movie[] movie;
	private int index;

	public MovieOperation(int size) {

		movie = new Movie[size];

	}

	public void addMovie(Movie movie) {

		this.movie[index++] = movie;

	}

	public void showAllMovie() {
		for (Movie movie2 : movie) {
			if (movie2 != null)
				System.out.println(movie2.getMovieId() + "\t" + movie2.getName());
		}

	}
	public Movie findMovieByMovieId(int movieId) {
		Movie finalMovie = null;
		for (int i = 0; i < movie.length; i++) {
			
		
			if(movie[i] !=null)
			{
				if(movie[i].getMovieId() == movieId)
				{
					finalMovie=movie[i];
				}
			}
		}
		return finalMovie;
	}

	public Movie findMovieByName(String name) {
		Movie finalMovie = null;
		for (int i = 0; i < movie.length; i++) {
			if(movie[i] !=null)
			{
				if(movie[i].getName().equals(name))
				{
					finalMovie=movie[i];
				}
			}
		}
		return finalMovie;
	}
	
}
