package com.dev.devapp;

import java.util.Scanner;

public class Mainnn {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Movie");
		int size = sc.nextInt();
		MovieOperation movieOperation = new MovieOperation(size);
		System.out.println("Enter the Movie details :");
		for (int i = 0; i < size; i++) {
			Movie movie = new Movie();
			System.out.println("Enter " + (i + 1) + " Movie name ");
			String name = sc.next();
			System.out.println("Enter " + (i + 1) + " Movie id");
			int id = sc.nextInt();
			movie.setMovieId(id);
			movie.setName(name);
			movieOperation.addMovie(movie);
		}
		String text = "";
		do {
			System.out.println("Press 1 for finding Movie By Id");
			System.out.println("Press 2 for finding Movie By name");
			System.out.println("Press 3 for show all the movie");
			System.out.println("Enter the choice:");
			int choice = sc.nextInt();
			Movie movie = null;
			switch (choice) {
			case 1:
				System.out.println("Enter  Movie ID  to find");
				movie = movieOperation.findMovieByMovieId(sc.nextInt());
				if (movie != null) {
					System.out.println(movie.getMovieId() + "\t" + movie.getName());
				} else {
					System.out.println("this movie Id does not exist");
				}
				break;
			case 2:
				System.out.println("Enter  Movie name  to find");
				movie = movieOperation.findMovieByName(sc.next());
				if (movie != null) {
					System.out.println(movie.getMovieId() + "\t" + movie.getName());
				} else {
					System.out.println("this movie name does not exist");
				}
				break;
			case 3:movieOperation.showAllMovie();
				break;
			case 4 :
				System.out.println("Enter the id to delete ");
				if(mo)
			default:
				System.out.println("Wrong choice");
			}
			System.out.println("Do you want to continue y/n");
			text = sc.next();

		} while (text.equalsIgnoreCase("y"));
	}
}
