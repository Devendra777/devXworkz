package com.xworkz.xworkzapp.river;

public class Yamuna extends River{

}
