package com.xworkz.xworkzapp.river;

public class Ganga extends River{

}
