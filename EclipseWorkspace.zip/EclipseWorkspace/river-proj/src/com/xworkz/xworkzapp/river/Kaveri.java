package com.xworkz.xworkzapp.river;

public class Kaveri extends River{

}
