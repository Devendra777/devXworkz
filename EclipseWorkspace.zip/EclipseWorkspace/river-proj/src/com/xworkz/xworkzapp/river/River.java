package com.xworkz.xworkzapp.river;

public class River {

	private String birthPlace;
	private String riverType;
	private String endPlace;

	public void setBirthPlace(String birthPlace) {
		this.birthPlace = birthPlace;
	}

	public String getBirthPlace() {
		return birthPlace;
	}

	public void setRiverType(String riverType) {
		this.riverType = riverType;
	}

	public String getRiverType() {
		return riverType;
	}

	public void setEndPlace(String endPlace) {
		this.endPlace = endPlace;
	}

	public String getEndPlace() {
		return endPlace;
	}

}
