package com.xworkz.xworkzapp.util;

import com.xworkz.xworkzapp.river.Ganga;

public class RiverUtil {

	public static void main(String[] args) {
		
		Ganga ganga = new Ganga();
		ganga.setBirthPlace("Gangotri");
		ganga.setRiverType("long");
		ganga.setEndPlace("BayOfBengal");
		System.out.println(ganga.getBirthPlace() + " " + ganga.getRiverType() + " "+ ganga.getEndPlace());
	}
}
