package com.dev.devapp.contract;

import java.io.Serializable;
import java.util.Date;

public interface RebBusContract extends Serializable {

	public int minBooking();

	boolean busWarrenty();

	default public  void printDate() {
		System.out.println(new Date());
	}

}
