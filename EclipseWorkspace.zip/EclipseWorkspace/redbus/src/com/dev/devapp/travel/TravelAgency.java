package com.dev.devapp.travel;

import java.io.Serializable;

import com.dev.devapp.contract.RebBusContract;

public class TravelAgency implements Serializable{
	
	
	private String agencyName= new String("Madhu Shree Travel Agency");
	//has a relationship
	private RebBusContract  contract;
	
	
	
	public TravelAgency(RebBusContract contract) {
		this.contract = contract;
	}
	
	
	public void acceptBooking()
	{
		boolean warrenty =    contract.busWarrenty();
		if(warrenty)
		{
			int min =contract.minBooking();
			if(min > 0 && min <=20) {
				System.out.println("can accept booking");
			}
			else {
				System.out.println("cannot accept booking");
			}
		}
		else {
			System.out.println("bus is not have  warrenty");
		}
	}

}
