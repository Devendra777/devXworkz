package com.dev.devapp;

import com.dev.devapp.contract.RebBusContract;
import com.dev.devapp.srs.RedBusContractImpl;
import com.dev.devapp.travel.TravelAgency;

public class AgencyTester {
	
	
	public static void main(String[] args) {
		
		RebBusContract contract = new RedBusContractImpl();
		
		//
		TravelAgency  agency = new TravelAgency(contract);
		
		agency.acceptBooking();
		
	}

}
