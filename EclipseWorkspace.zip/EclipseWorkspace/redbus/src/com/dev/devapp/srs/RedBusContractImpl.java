package com.dev.devapp.srs;

import com.dev.devapp.contract.RebBusContract;

public class RedBusContractImpl implements RebBusContract{

	@Override
	public int minBooking() {
		System.out.println("invoked minbooking");
		return 20;
	}

	@Override
	public boolean busWarrenty() {
		System.out.println("invoked buswarrenty");
		return true;
	}

}
