package org.dev.devapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/myServlet")
public class MyServlet extends HttpServlet{  
public synchronized  void doGet(HttpServletRequest request, HttpServletResponse response)  
    throws ServletException, IOException {  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
          
		out.print("welcome");  
    try{Thread.sleep(1000);}catch(Exception e){e.printStackTrace();}  
    out.print(" to servlet");  
    out.close();  
    }  
}  
