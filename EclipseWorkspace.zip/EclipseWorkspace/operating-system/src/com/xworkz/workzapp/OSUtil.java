package com.xworkz.workzapp;

import com.xworkz.workzapp.os.Linux;
import com.xworkz.workzapp.os.Os;
import com.xworkz.workzapp.os.Windows;

public class OSUtil {
	
	
	public static void main(String[] args) {
		
		//up casting 
		Os windows =new Windows();
		windows.bit = "64-bit OS";
		windows.version = "10";
		windows.openSource = false;
		windows.runApp();
		System.out.println(windows.bit + " " + windows.version);
		
		
   		Linux linux2   = (Linux) new Os();
		linux.openSource=true;
	    linux.bit="128-bit";
	    linux.version = "7";
	    System.out.println(linux.bit + " "+ linux.version + " "+ linux.openSource);
			
	}

}
