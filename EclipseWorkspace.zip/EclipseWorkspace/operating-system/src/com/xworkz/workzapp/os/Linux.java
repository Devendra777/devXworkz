package com.xworkz.workzapp.os;

public class Linux extends Os{
	
	public String bit ;
	public String version ; 
	
	public void providesSecurity()
	{
		System.out.println("providing security");
	}
	

}
