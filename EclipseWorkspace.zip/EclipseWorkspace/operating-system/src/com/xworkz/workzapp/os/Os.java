package com.xworkz.workzapp.os;

//parent class
public class Os {

	public String bit;
	public String version;

	public boolean openSource;

	public void runApp() {
		System.out.println("Running Most wanted app");
	}

}
