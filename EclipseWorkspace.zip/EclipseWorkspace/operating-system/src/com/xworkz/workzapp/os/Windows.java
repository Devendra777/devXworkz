package com.xworkz.workzapp.os;

//child class
public class Windows  extends Os{
	
	public String version ;
	public String bit;
	

}
