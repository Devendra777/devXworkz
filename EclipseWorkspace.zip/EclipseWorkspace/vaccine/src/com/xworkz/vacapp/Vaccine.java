//  Standard Package
package com.xworkz.vacapp;

import com.xworkz.vacapp.dto.VaccineDTO;

public class Vaccine {
	
	
	public static void main(String[] args) {
		
		   VaccineDTO dto  =  new VaccineDTO();
		   dto.setMfgDate("Jan 2021");
		   dto.setName( "CovidShield");
		   dto.setQuantity(5);
		   
		   System.out.println(dto.getMfgDate() + "  "+ dto.getName() +  " "+ dto.getQuantity());
	
	}

}
