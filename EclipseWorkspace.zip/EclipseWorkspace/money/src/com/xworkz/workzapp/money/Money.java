package com.xworkz.workzapp.money;

public class Money {

	public String searialNo;
	public String type;
	public static final int NO_OF_LANGUAGES = 15;

	public Money() {
		// TODO Auto-generated constructor stub
		System.out.println("Moeny Object is created with 0 parameters");
	}

	public Money(String searialNo) {
		this();
		System.out.println("Money Object is created with 1 parameters");
		this.searialNo = searialNo;
	}

	public Money(String searialNo, String type) {
		this(searialNo);
		System.out.println("Money Object is created with 2  parameters");
		
		this.searialNo = searialNo;
		this.type = type;
	}

	public void spend() {
		this.spend(type);
		System.out.println("Spending on mom");
	}

	public void spend(String type) {

		System.out.println("Spending on mom on " + type);
	}
}
