package com.xworkz.workzapp;

import com.xworkz.workzapp.money.Money;

public class MoneyUtil {
	
	
	public static void main(String[] args) {
		
		
		Money money = new Money("2EL89900" ,"note");
				System.out.println(money.searialNo + " "+ money.type);
		

}
	

}
